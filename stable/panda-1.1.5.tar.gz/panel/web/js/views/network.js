// Network & friends: PandA Tunnel / router forwarding, friends on Tailscale, Wi-Fi, opening the panel from a phone.
import { html, useState, useEffect } from '../lib/h.js';
import { api } from '../lib/api.js';
import { useStore, toast, update } from '../lib/store.js';
import { cls, copyText, hostPort, ago } from '../lib/util.js';
import { Icon } from '../ui/icons.js';
import { Btn, Modal, Loading, confirm, Field } from '../ui/kit.js';

function Signal({ v }) {
  const bars = v > 75 ? 4 : v > 50 ? 3 : v > 25 ? 2 : 1;
  return html`<span class="sig" aria-label=${`Signal ${v}%`}>${[1, 2, 3, 4].map((b) => html`<i class=${cls(b <= bars && 'on')} style=${`height:${b * 3 + 2}px`}></i>`)}</span>`;
}

export function WifiPicker({ onConnected }) {
  const [nets, setNets] = useState(null);
  const [pick, setPick] = useState(null);
  const [pw, setPw] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const scan = () => { setNets(null); api.get('/network/wifi/scan').then((r) => setNets(r.networks)).catch(() => setNets([])); };
  useEffect(() => { scan(); }, []);
  const connect = async () => {
    setBusy(true); setErr('');
    try { await api.post('/network/wifi/connect', { ssid: pick.ssid, password: pw }); toast('success', `Connected to ${pick.ssid}`); setPick(null); setPw(''); onConnected && onConnected(); scan(); } catch (e) { setErr(e.message); }
    setBusy(false);
  };
  return html`<div>
    <div class="row between mb-8"><span class="lbl"><${Icon} name="wifi" size=${15} />Wi-Fi networks</span><${Btn} size="xs" kind="ghost" icon="restart" onClick=${scan}>Scan<//></div>
    <div class="wifi-list">
      ${nets === null ? html`<${Loading} text="Looking for networks…" />` : !nets.length ? html`<div class="small muted" style="padding:16px">No networks found.</div>` : nets.map((n) => html`<button class=${cls('wifi-item', n.active && 'act')} onClick=${() => { setPick(n); setErr(''); }}>
        <${Signal} v=${n.signal} /><span class="grow" style="font-weight:650">${n.ssid}</span>
        ${n.active ? html`<span class="chip sm g">Connected</span>` : null}${n.secure ? html`<${Icon} name="lock" size=${14} class="muted" />` : null}
      </button>`)}
    </div>
    ${pick ? html`<${Modal} title=${`Join “${pick.ssid}”`} icon="wifi" onClose=${() => setPick(null)} footer=${html`<${Btn} kind="ghost" onClick=${() => setPick(null)}>Cancel<//><${Btn} kind="g" loading=${busy} onClick=${connect}>Connect<//>`}>
      ${pick.secure ? html`<${Field} label="Wi-Fi password"><input class="input big" type="password" autofocus value=${pw} onInput=${(e) => setPw(e.currentTarget.value)} onKeyDown=${(e) => e.key === 'Enter' && connect()} /><//>` : html`<p class="dim">This network has no password.</p>`}
      ${err ? html`<div class="err-text mt-12">${err}</div>` : null}
    <//>` : null}
  </div>`;
}

function CopyRow({ value, label }) {
  const [ok, setOk] = useState(false);
  return html`<div class="row" style="background:var(--ink-0);border:1px solid var(--line-2);padding:6px 6px 6px 12px">
    <span class="mono grow ellipsis" title=${value}>${value}</span>
    <${Btn} size="xs" kind=${ok ? 'g' : ''} icon=${ok ? 'check' : 'copy'} onClick=${async () => { if (await copyText(value)) { setOk(true); setTimeout(() => setOk(false), 1500); } }}>${ok ? 'Copied' : label || 'Copy'}<//>
  </div>`;
}

function Provider({ id, title, icon, desc, tags, current, onPick, busy, rec, pink, unavailable }) {
  const on = current === id;
  const isPink = pink !== undefined ? pink : id === 'playit';
  return html`<button class=${cls('flavor', on && 'on', isPink && 'pack')} style=${`min-height:0${unavailable ? ';opacity:.55' : ''}`} onClick=${() => !on && !unavailable && onPick(id)} disabled=${busy || !!unavailable}>
    ${rec ? html`<span class="rec stamp p">Recommended</span>` : null}
    <span class="c-icon" style=${on ? `background:${isPink ? 'var(--blossom)' : 'var(--bamboo)'};color:var(--ink-0);border:0` : ''}><${Icon} name=${icon} size=${22} /></span>
    <span class="fl-t" style="font-size:15.5px">${title}</span>
    <span class="fl-d">${desc}</span>
    <span class="fl-tags">${tags.map((t) => html`<span class="chip sm">${t}</span>`)}${on ? html`<span class="chip sm solid-g">On</span>` : null}${unavailable ? html`<span class="chip sm">${unavailable}</span>` : null}</span>
  </button>`;
}

// A link (sign in / allow) the user opens on any device, with a QR for phones.
function LinkTicket({ kicker, title, steps, url, waiting, green }) {
  return html`<div class=${cls('ticket mt-24', green && 'green')} style="min-height:0">
    <div class="main-part">
      <div class="t-k"><${Icon} name="link" size=${13} />${kicker}</div>
      <div style="font-family:var(--f-display);font-weight:700;font-size:22px;margin-top:10px">${title}</div>
      <ol style="margin:10px 0 0;padding-left:20px;font-weight:600;line-height:1.8">${steps.map((s) => html`<li>${s}</li>`)}</ol>
      <div class="row wrap mt-16">
        <a class="btn" style="--bg:var(--ink-0);--fg:var(--text);--bd:var(--ink-0)" href=${url} target="_blank" rel="noopener"><${Icon} name="external" size=${16} />Open link</a>
        <span class="mono small" style="opacity:.8;word-break:break-all">${url}</span>
      </div>
      ${waiting ? html`<div class="note mt-12">${waiting}</div>` : null}
    </div>
    <div class="stub"><div class="qr" style="width:110px;height:110px;padding:6px"><img src=${`/api/system/qr?text=${encodeURIComponent(url)}`} alt="QR code" /></div></div>
  </div>`;
}

// Turning on something that lets other people reach this box asks for the panel password
// (it's the lock) and swaps a short one for a longer one first.
function UnlockModal({ body, onSubmit, onClose }) {
  const [pw, setPw] = useState('');
  const [pw2, setPw2] = useState('');
  const [weak, setWeak] = useState(false);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    setBusy(true); setErr('');
    try {
      await onSubmit(pw, weak ? pw2 : undefined);
      setBusy(false);
      onClose();
      return;
    } catch (e) {
      if (e.code === 'WEAK') setWeak(true);
      setErr(e.message);
    }
    setBusy(false);
  };
  return html`<${Modal} title="Lock it with your password" icon="lock" onClose=${onClose} footer=${html`<${Btn} kind="ghost" onClick=${onClose}>Cancel<//><${Btn} kind="g" loading=${busy} disabled=${!pw || (weak && pw2.length < 8)} onClick=${submit}>${weak ? 'Save password & turn on' : 'Turn on'}<//>`}>
    <p class="dim">${body}</p>
    <${Field} label="Your panel password" class="mt-12"><input class="input big" type="password" autocomplete="current-password" autofocus value=${pw} onInput=${(e) => setPw(e.currentTarget.value)} onKeyDown=${(e) => e.key === 'Enter' && !weak && pw && submit()} /><//>
    ${weak ? html`<${Field} label="New, longer password (8+ characters)" hint="You'll use this one on your phone from now on." class="mt-12"><input class="input big" type="password" autocomplete="new-password" value=${pw2} onInput=${(e) => setPw2(e.currentTarget.value)} onKeyDown=${(e) => e.key === 'Enter' && pw2.length >= 8 && submit()} /><//>` : null}
    ${err ? html`<div class=${cls(weak && /short/.test(err) ? 'note' : 'err-text', 'mt-12')}>${err}</div>` : null}
  <//>`;
}

function RemoteAccess({ local }) {
  const r = useStore((s) => s.remote);
  const [busy, setBusy] = useState(false);
  const [ask, setAsk] = useState(null);
  const [showLog, setShowLog] = useState(false);
  const [copied, setCopied] = useState(false);
  useEffect(() => { api.get('/network/remote').then((x) => update((s) => { s.remote = x.remote; })).catch(() => {}); }, []);
  if (!r) return html`<div class="panel corners mb-16"><div class="panel-h"><h2><${Icon} name="globe" size=${18} />Your panel from anywhere</h2></div><div class="panel-b"><${Loading} /></div></div>`;

  const set = (x) => update((s) => { s.remote = x.remote; });
  const pick = async (provider) => {
    if (provider !== 'none') { setAsk(provider); return; }
    if (!(await confirm({ title: 'Close the panel to the internet?', body: 'The link stops working. Phones and PCs on your Wi-Fi can still open the panel.', ok: 'Turn off' }))) return;
    setBusy(true);
    try { set(await api.put('/network/remote', { provider: 'none' })); } catch (e) { toast('error', 'Couldn\'t turn it off', e.message); }
    setBusy(false);
  };
  const act = async (url, msg) => {
    setBusy(true);
    try { set(await api.post(url)); if (msg) toast('info', msg); } catch (e) { toast('error', 'That didn\'t work', e.message); }
    setBusy(false);
  };
  const copy = async () => { if (await copyText(r.url)) { setCopied(true); setTimeout(() => setCopied(false), 1500); } };

  const on = r.provider !== 'none';
  const chip = !on ? ['', 'offline', 'Off — Wi-Fi only'] : r.status === 'online' && r.verified ? ['g', 'online', 'Working'] : r.status === 'error' ? ['r', 'crashed', 'Problem'] : r.status === 'needs-login' || r.status === 'needs-enable' ? ['a', 'starting', 'Waiting for you'] : ['a', 'starting', 'Starting'];
  const quick = r.provider === 'cloudflare';

  return html`<div class="panel corners mb-16">
    <div class="panel-h"><h2><${Icon} name="globe" size=${18} />Your panel from anywhere</h2><span class=${cls('chip', chip[0])}><span class=${cls('sq', chip[1])}></span>${chip[2]}</span></div>
    <div class="panel-b">
      <p class="small dim mb-16" style="max-width:720px">Open this panel on your phone using mobile data, at school, at a friend's house — not just on your Wi-Fi. The link is private and encrypted (HTTPS), and everyone who opens it still needs your panel password.</p>
      <div class="grid g3">
        <${Provider} id="cloudflare" title="Quick link" icon="bolt" rec pink=${false} current=${r.provider} onPick=${pick} busy=${busy}
          desc="Works in seconds — no accounts, nothing to install. The link changes when this box restarts; PandA always shows the newest one here." tags=${['Free', 'No sign-up', 'HTTPS']} />
        <${Provider} id="tailscale" title="Permanent link" icon="link" pink current=${r.provider} onPick=${pick} busy=${busy} unavailable=${r.tailscaleSupported ? null : 'PandA OS only'}
          desc="Sign in once with a free Tailscale account (Google, Microsoft, GitHub or Apple). The link never changes — bookmark it on your phone." tags=${['Free', 'Never changes', 'HTTPS']} />
        <${Provider} id="none" title="Off" icon="lock" current=${r.provider} onPick=${pick} busy=${busy}
          desc="Only phones and computers on your Wi-Fi can open the panel." tags=${['Private']} />
      </div>

      ${r.status === 'needs-login' && r.loginUrl ? html`<${LinkTicket} kicker="ONE-TIME SIGN-IN" title="Sign in to Tailscale" url=${r.loginUrl}
        steps=${[html`Press <b>Open link</b> (or scan the code with your phone).`, 'Sign in with Google, Microsoft, GitHub or Apple — it\'s free.', html`Press <b>Connect</b>. PandA does the rest by itself.`]} waiting="Waiting for you to sign in…" />` : null}
      ${r.status === 'needs-enable' && r.enableUrl ? html`<${LinkTicket} kicker="ONE MORE CLICK" title="Allow the public link" url=${r.enableUrl}
        steps=${[html`Press <b>Open link</b>.`, html`Press <b>Enable</b> on the Tailscale page.`, 'Come back — PandA continues by itself.']} waiting="Waiting for you to press Enable…" />` : null}

      ${on && r.url ? html`<div class="ticket green mt-24" style="min-height:0">
        <div class="main-part">
          <div class="t-k"><${Icon} name="globe" size=${13} />${quick ? 'QUICK LINK' : 'PERMANENT LINK'}</div>
          <div class="t-addr" style="font-size:clamp(16px,2.2vw,26px)">${r.url.replace(/^https:\/\//, '')}</div>
          <div class="row wrap mt-12">
            <a class="btn" style="--bg:var(--ink-0);--fg:var(--text);--bd:var(--ink-0)" href=${r.url} target="_blank" rel="noopener"><${Icon} name="external" size=${16} />Open</a>
            <button class="btn" style="--bg:var(--ink-0);--fg:var(--text);--bd:var(--ink-0)" onClick=${copy}><${Icon} name=${copied ? 'check' : 'copy'} size=${16} />${copied ? 'Copied' : 'Copy link'}</button>
          </div>
          <div class="note mt-12">${r.verified ? html`<b>✓ Checked from the internet${r.checkedAt ? ` ${ago(r.checkedAt)}` : ''}.</b> ` : 'Checking that it opens from the internet… '}${quick ? 'This link changes when the box restarts — come back here (or look at the box\'s screen) for the new one.' : 'This link never changes — bookmark it.'}</div>
        </div>
        <div class="stub"><div class="qr" style="width:110px;height:110px;padding:6px"><img src=${`/api/system/qr?text=${encodeURIComponent(r.url)}`} alt="QR code for the link" /></div><div class="small" style="font-weight:700;opacity:.8">Scan with your phone</div></div>
      </div>` : null}

      ${on && r.message ? html`<div class=${cls('alert mt-16', r.status === 'error' ? 'error' : 'info')}><span class="ai"><${Icon} name=${r.status === 'error' ? 'warn' : 'info'} /></span><div class="grow"><div class="ab" style="margin:0;color:var(--text)">${r.message}</div></div>${r.status === 'error' ? html`<${Btn} size="sm" loading=${busy} onClick=${() => act('/network/remote/refresh')}>Try again<//>` : null}</div>` : null}

      ${on ? html`<div class="row wrap mt-16">
        ${quick && r.status !== 'starting' ? html`<${Btn} size="sm" kind="ghost" icon="restart" loading=${busy} onClick=${() => act('/network/remote/refresh', 'Making a new link…')}>Make a new link<//>` : null}
        ${r.provider === 'tailscale' ? html`<a class="btn sm ghost" href="https://login.tailscale.com/admin/machines" target="_blank" rel="noopener"><${Icon} name="external" size=${14} />Tailscale dashboard</a><${Btn} size="sm" kind="ghost" loading=${busy} onClick=${async () => { if (await confirm({ title: 'Sign out of Tailscale?', body: 'The permanent link stops working until you sign in again.', ok: 'Sign out', danger: true })) act('/network/remote/logout'); }}>Sign out of Tailscale<//>` : null}
        <${Btn} size="sm" kind="ghost" icon="terminal" onClick=${() => setShowLog(!showLog)}>${showLog ? 'Hide' : 'Show'} link log<//>
      </div>` : null}
      ${on && showLog ? html`<pre class="console mt-8" style="max-height:220px;margin:0;padding:10px 14px;border:1px solid var(--line)">${(r.log || []).join('\n') || 'Nothing yet.'}</pre>` : null}

      ${ask ? html`<${UnlockModal} onClose=${() => setAsk(null)}
        body=${`Anyone who gets the link only sees the sign-in page. Your panel password is the lock${local ? ' — this screen stays password-free' : ''}.`}
        onSubmit=${async (pw, pw2) => set(await api.put('/network/remote', { provider: ask, password: pw, newPassword: pw2 }))} />` : null}
    </div>
  </div>`;
}

const RELAY_CITY = { dbi: 'Dubai', fra: 'Frankfurt', lhr: 'London', ams: 'Amsterdam', par: 'Paris', waw: 'Warsaw', nue: 'Nuremberg', hel: 'Helsinki', mad: 'Madrid', blr: 'Bengaluru', sin: 'Singapore', hkg: 'Hong Kong', tok: 'Tokyo', syd: 'Sydney', jnb: 'Johannesburg', nai: 'Nairobi', nyc: 'New York', sfo: 'San Francisco', lax: 'Los Angeles', sea: 'Seattle', ord: 'Chicago', dfw: 'Dallas', den: 'Denver', mia: 'Miami', tor: 'Toronto', sao: 'São Paulo', hnl: 'Honolulu', iad: 'Ashburn' };

// A friend's connection, from the last "Test" (or what Tailscale already knows).
function linkInfo(p) {
  const r = p.ping;
  if (r && r.ok && r.direct) return ['g', `Direct · ${r.ms} ms`];
  if (r && r.ok) return ['a', `Through a Tailscale relay${r.relay && r.relay !== 'peer' ? ` in ${RELAY_CITY[r.relay] || r.relay.toUpperCase()}` : ''} · ${r.ms} ms`];
  if (r) return ['r', 'No answer — is Tailscale on there?'];
  if (!p.online) return ['', 'Offline'];
  return p.direct ? ['g', 'Direct'] : ['', 'Online'];
}

// Friends with the Tailscale app join the Minecraft servers straight from their PC.
function FriendsTailscale({ local }) {
  const r = useStore((s) => s.remote);
  const [ask, setAsk] = useState(false);
  const [busy, setBusy] = useState(false);
  const [testing, setTesting] = useState(null);
  const [copied, setCopied] = useState(false);
  // Always a frame, never null (Preact can drop a component that starts out as null).
  if (!r) return html`<div class="panel corners mb-16"><div class="panel-h"><h2><${Icon} name="users" size=${18} />Friends with Tailscale — lowest ping</h2></div><div class="panel-b"><${Loading} /></div></div>`;
  const f = r.friends || { on: false, status: 'off', peers: [] };
  const set = (x) => update((s) => { s.remote = x.remote; });
  const turnOff = async () => {
    if (!(await confirm({ title: 'Turn off Tailscale for friends?', body: 'Friends who use Tailscale can\'t join until you turn it back on. The PandA Tunnel keeps working.', ok: 'Turn off' }))) return;
    setBusy(true);
    try { set(await api.put('/network/remote/friends', { on: false })); } catch (e) { toast('error', 'Couldn\'t turn it off', e.message); }
    setBusy(false);
  };
  const test = async (p) => {
    setTesting(p.id);
    try { set(await api.post('/network/remote/friends/ping', { ip: p.ip })); } catch (e) { toast('error', 'Test didn\'t work', e.message); }
    setTesting(null);
  };
  const addr = f.name || f.ip;
  const copy = async () => { if (await copyText(addr)) { setCopied(true); setTimeout(() => setCopied(false), 1500); } };
  const chip = !f.on ? ['', 'offline', 'Off'] : f.status === 'online' ? ['g', 'online', 'Working'] : f.status === 'error' ? ['r', 'crashed', 'Problem'] : f.status === 'needs-login' ? ['a', 'starting', 'Waiting for you'] : ['a', 'starting', 'Starting'];

  return html`<div class="panel corners mb-16">
    <div class="panel-h"><h2><${Icon} name="users" size=${18} />Friends with Tailscale — lowest ping</h2><span class=${cls('chip', chip[0])}><span class=${cls('sq', chip[1])}></span>${chip[2]}</span></div>
    <div class="panel-b">
      <p class="small dim mb-16" style="max-width:720px">Friends who install the free Tailscale app connect straight to this box — even through 5G or CGNAT, with no detour through a tunnel in another country. They only get your Minecraft servers: this panel still needs your password. Everyone else keeps using the PandA Tunnel.</p>

      ${!f.on ? html`<div class="row wrap">
        <${Btn} kind="p" icon="users" disabled=${!r.tailscaleSupported} onClick=${() => setAsk(true)}>Turn on<//>
        ${r.tailscaleSupported ? html`<span class="small muted">Uses a free Tailscale account (Google, Microsoft, GitHub or Apple).</span>` : html`<span class="chip sm">PandA OS only</span>`}
      </div>` : null}

      ${f.on && f.status === 'needs-login' && r.loginUrl ? html`<${LinkTicket} kicker="ONE-TIME SIGN-IN" title="Sign in to Tailscale" url=${r.loginUrl}
        steps=${[html`Press <b>Open link</b> (or scan the code with your phone).`, 'Sign in with Google, Microsoft, GitHub or Apple — it\'s free.', html`Press <b>Connect</b>. PandA does the rest by itself.`]} waiting="Waiting for you to sign in…" />` : null}
      ${f.on && f.message && f.status !== 'needs-login' ? html`<div class=${cls('alert mt-16', f.status === 'error' ? 'error' : 'info')}><span class="ai"><${Icon} name=${f.status === 'error' ? 'warn' : 'info'} /></span><div class="grow"><div class="ab" style="margin:0;color:var(--text)">${f.message}</div></div></div>` : null}

      ${f.on && f.status === 'online' && addr ? html`
        <div class="ticket green" style="min-height:0">
          <div class="main-part">
            <div class="t-k"><${Icon} name="gamepad" size=${13} />FRIENDS TYPE THIS IN MINECRAFT</div>
            <div class="t-addr" style="font-size:clamp(16px,2.2vw,26px)">${addr}</div>
            <div class="note mt-8">${f.ip && f.name ? html`If that doesn't work, use <b class="mono">${f.ip}</b>. ` : null}A server on another port needs <b class="mono">:port</b> at the end — its page shows the exact address.</div>
          </div>
          <div class="stub"><button class=${cls('copy', copied && 'done')} onClick=${copy} aria-label="Copy address"><${Icon} name=${copied ? 'check' : 'copy'} size=${26} />${copied ? 'COPIED' : 'COPY'}</button></div>
        </div>

        <h3 class="mt-24 mb-8">Invite a friend</h3>
        <ol style="margin:0;padding-left:20px;font-weight:600;line-height:1.9">
          <li>Press <b>Open Tailscale</b>, find <b>${f.name ? f.name.split('.')[0] : 'this box'}</b>, press <b>⋯ → Share…</b>, then <b>Copy share link</b>. Send the link to your friend.</li>
          <li>Your friend installs Tailscale from <a href="https://tailscale.com/download" target="_blank" rel="noopener">tailscale.com/download</a>, signs in for free, opens your link and presses <b>Accept</b>.</li>
          <li>In Minecraft: <b>Multiplayer → Add Server</b> → <b class="mono">${addr}</b></li>
        </ol>
        <div class="row wrap mt-12"><a class="btn sm" href="https://login.tailscale.com/admin/machines" target="_blank" rel="noopener"><${Icon} name="external" size=${14} />Open Tailscale</a></div>

        <h3 class="mt-24 mb-8">Who can connect</h3>
        <div class="panel">
          ${!f.peers.length ? html`<div class="small muted" style="padding:16px">Nobody yet. When your friend accepts the invite and opens Tailscale, their PC shows up here.</div>` : f.peers.map((p) => {
            const [c, text] = linkInfo(p);
            return html`<div class="content-row">
              <span class=${cls('sq', p.online ? 'online' : 'offline')}></span>
              <div class="grow" style="min-width:0">
                <div class="c-name">${p.user || p.device}${p.friend ? null : html` <span class="chip sm">You</span>`}</div>
                <div class="c-sub"><span class="mono">${p.device}</span> · <span class=${cls('chip sm', c)}>${text}</span></div>
              </div>
              ${p.online && p.ip ? html`<${Btn} size="xs" icon="bolt" loading=${testing === p.id} onClick=${() => test(p)}>Test<//>` : null}
            </div>`;
          })}
        </div>
        <div class="note mt-12">Press <b>Test</b> while your friend has Tailscale open. <b>Direct</b> is the lowest ping. If it says <b>relay</b>, the connection takes a detour — your friend can close and reopen Tailscale, then test again.</div>
      ` : null}

      ${f.on ? html`<div class="row wrap mt-16"><${Btn} size="sm" kind="ghost" loading=${busy} onClick=${turnOff}>Turn off<//></div>` : null}

      ${ask ? html`<${UnlockModal} onClose=${() => setAsk(false)}
        body=${`Friends get your Minecraft servers only. If anyone tries to open this panel through Tailscale, they need your password${local ? ' — this screen stays password-free' : ''}.`}
        onSubmit=${async (pw, pw2) => set(await api.put('/network/remote/friends', { on: true, password: pw, newPassword: pw2 }))} />` : null}
    </div>
  </div>`;
}

export function NetworkPage() {
  const me = useStore((s) => s.me);
  const tunnel = useStore((s) => s.tunnel);
  const servers = useStore((s) => Object.values(s.servers));
  const [net, setNet] = useState(null);
  const [sys, setSys] = useState(null);
  const [busy, setBusy] = useState(false);
  const [showLog, setShowLog] = useState(false);
  const load = () => { api.get('/network').then(setNet).catch(() => {}); api.get('/system').then(setSys).catch(() => {}); };
  useEffect(() => { load(); }, []);
  const t = tunnel || (net && net.tunnel);
  const pick = async (provider) => {
    setBusy(true);
    try { await api.put('/network/tunnel', { provider }); } catch (e) { toast('error', 'Couldn\'t switch', e.message); }
    setBusy(false);
  };
  const unlink = async () => {
    if (!(await confirm({ title: 'Unlink playit.gg?', body: 'Public addresses stop working until you link an account again.', ok: 'Unlink', danger: true }))) return;
    try { await api.post('/network/tunnel/unlink'); } catch (e) { toast('error', 'Couldn\'t unlink', e.message); }
  };
  const panelUrl = sys ? sys.panelUrl : '';

  return html`<div class="page">
    <div class="page-head"><div><div class="kicker">Network</div><h1>Network & friends</h1><div class="dim mt-8">Let friends join from anywhere, and open this panel from your phone.</div></div></div>

    <div class="panel corners mb-16">
      <div class="panel-h"><h2><${Icon} name="tunnel" size=${18} />Friends outside your home</h2>
        ${t ? html`<span class=${cls('chip', t.status === 'online' ? 'g' : t.status === 'error' ? 'r' : t.provider === 'none' ? '' : 'a')}><span class=${cls('sq', t.status === 'online' ? 'online' : t.status === 'error' ? 'crashed' : t.provider === 'none' ? 'offline' : 'starting')}></span>${t.provider === 'none' ? 'Off — same Wi-Fi only' : t.status === 'online' ? 'Working' : t.status === 'needs-claim' || t.status === 'claiming' ? 'Waiting for you' : t.status === 'error' ? 'Problem' : 'Starting'}</span>` : null}
      </div>
      <div class="panel-b">
        <div class="grid g3">
          <${Provider} id="playit" title="PandA Tunnel" icon="tunnel" rec current=${t && t.provider} onPick=${pick} busy=${busy}
            desc="A free tunnel by playit.gg. Works with every internet provider — even ones that block port forwarding (CGNAT). Each server gets its own address." tags=${['Free', 'No router setup', 'Java + Bedrock']} />
          <${Provider} id="upnp" title="Router (UPnP)" icon="network" current=${t && t.provider} onPick=${pick} busy=${busy}
            desc="PandA asks your router to open the ports automatically. Friends join with your home's public IP. Needs UPnP turned on in the router." tags=${['Fastest', 'Shows your IP']} />
          <${Provider} id="none" title="Off" icon="wifi" current=${t && t.provider} onPick=${pick} busy=${busy}
            desc="Only people on your Wi-Fi (or LAN cable) can join." tags=${['Private']} />
        </div>

        ${t && t.provider === 'playit' && (t.status === 'needs-claim' || t.status === 'claiming') && t.claimUrl ? html`<div class="ticket mt-24" style="min-height:0">
          <div class="main-part">
            <div class="t-k"><${Icon} name="link" size=${13} />ONE-TIME LINK</div>
            <div style="font-family:var(--f-display);font-weight:700;font-size:22px;margin-top:10px">Connect a free playit.gg account</div>
            <ol style="margin:10px 0 0;padding-left:20px;font-weight:600;line-height:1.8">
              <li>Press <b>Open link</b> (or scan the code with your phone).</li>
              <li>Sign up or log in — it's free.</li>
              <li>Press <b>Accept</b>. PandA does the rest by itself.</li>
            </ol>
            <div class="row wrap mt-16">
              <a class="btn" style="--bg:var(--ink-0);--fg:var(--text);--bd:var(--ink-0)" href=${t.claimUrl} target="_blank" rel="noopener"><${Icon} name="external" size=${16} />Open link</a>
              <span class="mono small" style="opacity:.8;word-break:break-all">${t.claimUrl}</span>
            </div>
            ${t.status === 'claiming' ? html`<div class="note mt-12">Waiting for you to press Accept…</div>` : null}
          </div>
          <div class="stub"><div class="qr" style="width:110px;height:110px;padding:6px"><img src=${`/api/system/qr?text=${encodeURIComponent(t.claimUrl)}`} alt="QR code" /></div></div>
        </div>` : null}

        ${t && t.message && !(t.status === 'needs-claim' || t.status === 'claiming') ? html`<div class=${cls('alert mt-16', t.status === 'error' ? 'error' : 'info')}><span class="ai"><${Icon} name=${t.status === 'error' ? 'warn' : 'info'} /></span><div class="grow"><div class="ab" style="margin:0;color:var(--text)">${t.message}</div></div>${t.status === 'error' && t.provider === 'upnp' && t.cgnat ? html`<${Btn} kind="p" size="sm" onClick=${() => pick('playit')}>Use the PandA Tunnel<//>` : null}</div>` : null}
        ${t && t.setupHint ? html`<div class="alert warn mt-16"><span class="ai"><${Icon} name="info" /></span><div class="grow"><div class="at">One manual step</div><div class="ab">${t.setupHint.text}</div></div><a class="btn sm" href=${t.setupHint.url} target="_blank" rel="noopener">Open playit.gg</a></div>` : null}

        ${t && t.provider !== 'none' ? html`<div class="mt-24">
          <h3 class="mb-12">Public addresses</h3>
          <div class="panel">
            ${!servers.length ? html`<div class="small muted" style="padding:16px">Make a server first.</div>` : servers.map((s) => {
              const a = t.addresses && t.addresses[s.id];
              return html`<div class="content-row">
                <span class=${cls('sq', s.status)}></span>
                <div class="grow" style="min-width:0">
                  <div class="c-name">${s.name}</div>
                  <div class="c-sub">${a && a.java ? html`<span class="mono" style="color:var(--text)">${a.java.srv ? a.java.host : hostPort(a.java)}</span>` : a && a.error ? html`<span class="red">${a.error}</span>` : a && a.pending ? 'Getting an address…' : 'Start the server to get an address.'}${a && a.bedrock ? html` · Bedrock <span class="mono">${a.bedrock.host}</span> port <span class="mono">${a.bedrock.port}</span>` : null}</div>
                </div>
                ${a && a.java ? html`<${Btn} size="xs" icon="copy" onClick=${async () => { await copyText(a.java.srv ? a.java.host : hostPort(a.java)); toast('success', 'Copied'); }}>Copy<//>` : null}
              </div>`;
            })}
          </div>
          <div class="row wrap mt-12">
            ${t.provider === 'playit' && t.hasSecret ? html`<a class="btn sm ghost" href="https://playit.gg/account/tunnels" target="_blank" rel="noopener"><${Icon} name="external" size=${14} />playit.gg dashboard</a><${Btn} size="sm" kind="ghost" onClick=${unlink}>Unlink account<//>` : null}
            <${Btn} size="sm" kind="ghost" icon="terminal" onClick=${() => setShowLog(!showLog)}>${showLog ? 'Hide' : 'Show'} tunnel log<//>
          </div>
          ${showLog ? html`<pre class="console mt-8" style="max-height:220px;margin:0;padding:10px 14px;border:1px solid var(--line)">${(t.log || []).join('\n') || 'Nothing yet.'}</pre>` : null}
        </div>` : null}
      </div>
    </div>

    <${FriendsTailscale} local=${me && me.local} />
    <${RemoteAccess} local=${me && me.local} />

    <div class="grid g2">
      <div class="panel">
        <div class="panel-h"><h2><${Icon} name="phone" size=${18} />Open the panel on your phone</h2></div>
        <div class="panel-b">
          <div class="row top gap-18 wrap">
            ${panelUrl ? html`<div class="qr"><img src=${`/api/system/qr?text=${encodeURIComponent(panelUrl)}`} alt="QR code for the panel" /></div>` : null}
            <div class="grow" style="min-width:220px">
              <p class="small dim">Any phone, tablet or computer on the same Wi-Fi can open this panel. Scan the code or type the address. You'll need your panel password.</p>
              <div class="col gap-6 mt-12">
                ${panelUrl ? html`<${CopyRow} value=${panelUrl} />` : null}
                ${sys && sys.localName ? html`<${CopyRow} value=${sys.localName} />` : null}
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="panel">
        <div class="panel-h"><h2><${Icon} name="wifi" size=${18} />Internet connection</h2></div>
        <div class="panel-b">
          ${!net ? html`<${Loading} />` : html`
            <div class=${cls('alert', net.wifi.connected ? 'ok' : 'error')}><span class="ai"><${Icon} name=${net.wifi.connected ? 'check' : 'warn'} /></span><div><div class="at">${net.wifi.connected ? `Online${net.wifi.ethernet ? ' (cable)' : net.wifi.ssid ? ` · ${net.wifi.ssid}` : ''}` : 'Not connected'}</div><div class="ab">${net.wifi.note || (net.wifi.supported ? 'Pick a network below to switch.' : '')}</div></div></div>
            ${net.wifi.supported ? html`<div class="mt-16"><${WifiPicker} onConnected=${load} /></div>` : null}
            <h3 class="mt-24 mb-8">This machine's addresses</h3>
            <dl class="kv">${(net.lan || []).map((l) => html`<dt>${l.iface}</dt><dd>${l.address}</dd>`)}</dl>
          `}
        </div>
      </div>
    </div>
  </div>`;
}
