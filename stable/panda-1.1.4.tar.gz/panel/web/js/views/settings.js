// System settings: device, password, CurseForge, defaults for new servers, power.
import { html, useState, useEffect } from '../lib/h.js';
import { api } from '../lib/api.js';
import { toast, refreshInfo, useStore, update } from '../lib/store.js';
import { gb, bytes, ago, cls } from '../lib/util.js';
import { Icon } from '../ui/icons.js';
import { Btn, Field, Toggle, Range, Seg, Loading, Bar, confirm } from '../ui/kit.js';
import { CurseForgeKey } from './browse.js';

const myTimeZone = () => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch { return ''; } };

// PandA OS updates: what's installed, what's new, and one button.
function UpdatesCard() {
  const u = useStore((s) => s.updates);
  const [busy, setBusy] = useState('');
  const set = (x) => update((s) => { s.updates = x.updates; });
  useEffect(() => { api.get('/updates').then(set).catch(() => {}); }, []);
  // Always render the frame: a component that switches from nothing to something can be
  // left out of the page by the renderer when it has siblings after it.
  if (!u) return html`<section class="panel"><div class="panel-h"><h3><${Icon} name="download" size=${16} />Updates</h3></div><div class="panel-b"><${Loading} /></div></section>`;

  const run = async (key, fn) => {
    setBusy(key);
    try { set(await fn()); } catch (e) { toast('error', 'That didn\'t work', e.message); }
    setBusy('');
  };
  const install = async (force = false) => {
    setBusy('install');
    try { set(await api.post('/updates/install', { force })); } catch (e) {
      if (e.code === 'PLAYERS') {
        setBusy('');
        if (await confirm({ title: 'Update now?', body: `${e.message} PandA warns them in chat first, then saves every world.`, ok: 'Update now' })) install(true);
        return;
      }
      toast('error', 'Couldn\'t update', e.message);
    }
    setBusy('');
  };
  const working = ['checking', 'downloading', 'installing'].includes(u.status);
  const rolledBack = u.last && u.last.state === 'rolled-back';

  return html`<section class="panel">
    <div class="panel-h"><h3><${Icon} name="download" size=${16} />Updates</h3>${u.supported ? html`<span class=${cls('chip', u.available ? 'p' : 'g')}>${u.available ? 'Update ready' : 'Up to date'}</span>` : null}</div>
    <div class="panel-b">
      ${!u.supported ? html`<p class="small dim">PandA OS updates itself from here. This copy runs as an app on ${navigator.platform.startsWith('Win') ? 'Windows' : 'this computer'}, so it updates when you get the new version of its folder.</p>` : html`
        <div class="row gap-18 wrap">
          <div><div class="kicker">Installed</div><div style="font-family:var(--f-display);font-weight:700;font-size:20px">${u.current}</div></div>
          ${u.available ? html`<${Icon} name="chevR" class="muted" /><div><div class="kicker">New</div><div style="font-family:var(--f-display);font-weight:700;font-size:20px;color:var(--blossom)">${u.latest}</div></div>` : null}
        </div>
        ${u.available && u.notes ? html`<div class="mt-12 small" style="white-space:pre-wrap;background:var(--ink-0);border:1px solid var(--line-2);padding:10px 12px;max-height:180px;overflow:auto">${u.notes}</div>` : null}
        ${!u.available ? html`<p class="small dim mt-8">${u.checkedAt ? `You have the newest PandA. Checked ${ago(u.checkedAt)}.` : 'PandA checks for updates by itself every few hours.'}</p>` : null}
        ${u.status === 'downloading' ? html`<div class="mt-12"><${Bar} value=${u.progress} busy=${u.progress == null} /><div class="small muted mt-4">Downloading${u.size ? ` ${bytes(u.size)}` : ''}…</div></div>` : null}
        ${u.message && !working ? html`<div class="small mt-8" style="color:var(--amber)">${u.message}</div>` : null}
        ${rolledBack ? html`<div class="alert warn mt-12"><span class="ai"><${Icon} name="warn" /></span><div class="grow"><div class="at">Update to ${u.last.version} was undone</div><div class="ab">${u.last.message || 'It didn\'t start properly, so PandA went back by itself. Nothing was lost.'}</div></div></div>` : null}
        <div class="btn-row mt-16">
          ${u.available ? html`<${Btn} kind="g" icon="download" loading=${busy === 'install' || u.status === 'installing'} disabled=${working && u.status !== 'downloading'} onClick=${() => install(false)}>${u.status === 'ready' ? 'Install now' : 'Update now'}${u.size && u.status !== 'ready' ? ` · ${bytes(u.size)}` : ''}<//>` : null}
          <${Btn} kind="ghost" icon="restart" loading=${busy === 'check' || u.status === 'checking'} disabled=${working} onClick=${() => run('check', () => api.post('/updates/check'))}>Check now<//>
        </div>
        <div class="switch-row mt-12"><div class="txt"><div class="t">Update automatically</div><div class="d">Downloads new versions by itself and installs them between 3 and 5 at night — only when nobody is playing.</div></div><${Toggle} checked=${u.auto} onChange=${(v) => run('auto', () => api.put('/updates/settings', { auto: v, tz: myTimeZone() }))} label="Automatic updates" /></div>
        <p class="small muted mt-8">No reinstalling: worlds, settings and links stay. If a new version doesn't start properly, PandA goes back to the old one by itself.</p>
      `}
    </div>
  </section>`;
}

export function SettingsPage() {
  const [sys, setSys] = useState(null);
  const [name, setName] = useState('');
  const [pw, setPw] = useState({ current: '', next: '', again: '' });
  const [showCf, setShowCf] = useState(false);
  const me = useStore((s) => s.me);
  const remoteOn = useStore((s) => !!(s.remote && s.remote.provider !== 'none'));
  const load = () => api.get('/system').then((s) => { setSys(s); setName(s.settings.deviceName); }).catch((e) => toast('error', 'Couldn\'t load settings', e.message));
  useEffect(() => { load(); }, []);
  if (!sys) return html`<div class="page"><${Loading} /></div>`;
  const st = sys.settings;
  const total = Math.floor(sys.info.memTotal / 1048576);

  const save = async (body, msg = 'Saved') => {
    try { await api.put('/settings', body); toast('success', msg); load(); refreshInfo(); return true; } catch (e) { toast('error', 'Not saved', e.message); return false; }
  };
  const changePw = async () => {
    const min = remoteOn ? 8 : 4;
    if (pw.next.length < min) return toast('error', 'Too short', `Use at least ${min} characters${remoteOn ? ' — the panel is open to the internet' : ''}.`);
    if (pw.next !== pw.again) return toast('error', 'The new passwords don\'t match');
    if (await save({ password: { current: pw.current, next: pw.next } }, 'Password changed')) setPw({ current: '', next: '', again: '' });
  };
  const power = async (action) => {
    if (!(await confirm({ title: action === 'reboot' ? 'Restart PandA?' : 'Shut down PandA?', body: 'All servers are stopped safely first.', ok: action === 'reboot' ? 'Restart' : 'Shut down', danger: true }))) return;
    try { await api.post('/system/power', { action }); toast('info', action === 'reboot' ? 'Restarting…' : 'Shutting down…'); } catch (e) { toast('error', 'Couldn\'t do that', e.message); }
  };
  const d = st.defaults || {};

  return html`<div class="page">
    <div class="page-head"><div><div class="kicker">System</div><h1>Settings</h1></div></div>
    <div class="grid g2" style="align-items:start">
      <div class="col gap-18">
        <section class="panel">
          <div class="panel-h"><h3><${Icon} name="server" size=${16} />This device</h3></div>
          <div class="panel-b">
            <${Field} label="Device name" hint=${sys.info.mode === 'os' ? 'Also used as the network name (name.local).' : 'Shown in the panel.'}><div class="row"><input class="input" maxlength="40" value=${name} onInput=${(e) => setName(e.currentTarget.value)} /><${Btn} kind="g" disabled=${!name.trim() || name === st.deviceName} onClick=${() => save({ deviceName: name })}>Save<//></div><//>
            <div class="switch-row mt-12"><div class="txt"><div class="t">No password on this screen</div><div class="d">The screen plugged into this machine opens the panel without signing in. Phones and other computers always need the password.</div></div><${Toggle} checked=${st.trustLocal} onChange=${(v) => save({ trustLocal: v })} label="Trust this screen" /></div>
          </div>
        </section>

        <section class="panel">
          <div class="panel-h"><h3><${Icon} name="lock" size=${16} />Panel password</h3></div>
          <div class="panel-b">
            <div class="grid g2">
              <${Field} label="Current password" class="span-2"><input class="input" type="password" autocomplete="current-password" placeholder=${st.trustLocal && me && me.local ? 'Not needed on this screen' : ''} value=${pw.current} onInput=${(e) => setPw({ ...pw, current: e.currentTarget.value })} /><//>
              <${Field} label="New password"><input class="input" type="password" autocomplete="new-password" value=${pw.next} onInput=${(e) => setPw({ ...pw, next: e.currentTarget.value })} /><//>
              <${Field} label="Again"><input class="input" type="password" autocomplete="new-password" value=${pw.again} onInput=${(e) => setPw({ ...pw, again: e.currentTarget.value })} /><//>
            </div>
            <div class="row between mt-16"><span class="small muted">Signs out every other device.</span><${Btn} kind="p" disabled=${!pw.next} onClick=${changePw}>Change password<//></div>
          </div>
        </section>

        <section class="panel">
          <div class="panel-h"><h3><${Icon} name="key" size=${16} />Integrations</h3></div>
          <div class="panel-b">
            <div class="switch-row" style="padding-top:0"><div class="txt"><div class="t">Modrinth</div><div class="d">Built in, nothing to set up.</div></div><span class="chip g">Ready</span></div>
            <div class="switch-row"><div class="txt"><div class="t">CurseForge</div><div class="d">${st.curseforgeKeySet ? 'Connected. You can browse and install from CurseForge.' : 'Needs a free key from CurseForge (one time).'}</div></div>${st.curseforgeKeySet ? html`<div class="row"><span class="chip g">Connected</span><${Btn} size="xs" kind="ghost" onClick=${() => setShowCf(!showCf)}>Change<//></div>` : html`<${Btn} size="sm" kind="p" onClick=${() => setShowCf(true)}>Connect<//>`}</div>
            ${showCf || !st.curseforgeKeySet ? html`<div class="mt-12"><${CurseForgeKey} onSaved=${() => { setShowCf(false); load(); }} /></div>` : null}
          </div>
        </section>
      </div>

      <div class="col gap-18">
        <${UpdatesCard} />
        <section class="panel">
          <div class="panel-h"><h3><${Icon} name="plus" size=${16} />Defaults for new servers</h3></div>
          <div class="panel-b">
            <${Field} label=${html`Memory <span class="mono pink" style="margin-left:auto">${gb(d.memoryMb || 4096)}</span>`}><${Range} pink value=${d.memoryMb || 4096} min=${1024} max=${Math.max(2048, Math.floor((total * 0.85) / 512) * 512)} step=${512} onInput=${(v) => setSys({ ...sys, settings: { ...st, defaults: { ...d, memoryMb: v } } })} /><//>
            <div class="row mt-8" style="justify-content:flex-end"><${Btn} size="sm" onClick=${() => save({ defaults: { memoryMb: d.memoryMb } })}>Save memory<//></div>
            <div class="switch-row"><div class="txt"><div class="t">Start with PandA</div></div><${Toggle} checked=${d.autoStart !== false} onChange=${(v) => save({ defaults: { autoStart: v } })} label="Auto start" /></div>
            <div class="switch-row"><div class="txt"><div class="t">Restart after crashes</div></div><${Toggle} checked=${d.autoRestart !== false} onChange=${(v) => save({ defaults: { autoRestart: v } })} label="Auto restart" /></div>
            <div class="switch-row"><div class="txt"><div class="t">Fix missing libraries automatically</div></div><${Toggle} checked=${d.autoFixDeps !== false} onChange=${(v) => save({ defaults: { autoFixDeps: v } })} label="Auto fix" /></div>
            <${Field} label="Automatic backups to keep" class="mt-12"><${Seg} value=${d.backupKeep || 5} onChange=${(v) => save({ defaults: { backupKeep: v } })} options=${[3, 5, 10, 20].map((n) => ({ value: n, label: String(n) }))} /><//>
          </div>
        </section>

        <section class="panel">
          <div class="panel-h"><h3><${Icon} name="cpu" size=${16} />Machine</h3></div>
          <div class="panel-b">
            <dl class="kv">
              <dt>Processor</dt><dd title=${sys.info.cpuModel}>${sys.info.cpuModel}</dd>
              <dt>Cores</dt><dd>${sys.info.cores}</dd>
              <dt>Memory</dt><dd>${bytes(sys.info.memTotal)}</dd>
              ${sys.info.disk ? html`<dt>Storage free</dt><dd>${bytes(sys.info.disk.free)} of ${bytes(sys.info.disk.total)}</dd>` : null}
              <dt>Mode</dt><dd>${sys.info.mode === 'os' ? 'PandA OS' : `App on ${sys.info.platform === 'win32' ? 'Windows' : sys.info.platform}`}</dd>
              <dt>Java installed</dt><dd>${sys.java.length ? sys.java.map((j) => j.major).join(', ') : 'auto when needed'}</dd>
              <dt>Data folder</dt><dd title=${sys.info.dataDir}>${sys.info.dataDir}</dd>
              <dt>PandA version</dt><dd>${sys.version}</dd>
            </dl>
          </div>
        </section>

        ${sys.info.mode === 'os' ? html`<section class="panel">
          <div class="panel-h"><h3><${Icon} name="power" size=${16} />Power</h3></div>
          <div class="panel-b"><div class="btn-row"><${Btn} icon="restart" onClick=${() => power('reboot')}>Restart PandA<//><${Btn} kind="danger" icon="power" onClick=${() => power('poweroff')}>Shut down<//></div></div>
        </section>` : null}
      </div>
    </div>
  </div>`;
}
