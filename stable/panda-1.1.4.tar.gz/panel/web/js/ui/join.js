// The big "Join Address" ticket with a copy button.
import { html, useState, useEffect } from '../lib/h.js';
import { cls, copyText, hostPort } from '../lib/util.js';
import { Icon } from './icons.js';
import { toast } from '../lib/store.js';

export function JoinTicket({ server, pink = true, title }) {
  const j = server && server.join;
  const [mode, setMode] = useState(null);
  const [copied, setCopied] = useState(false);
  const modes = [];
  if (j) {
    modes.push({ id: 'public', label: 'Friends anywhere', ok: !!j.public });
    modes.push({ id: 'lan', label: 'Same Wi-Fi', ok: true });
    if (j.bedrock) modes.push({ id: 'bedrock', label: 'Phone / console', ok: true });
  }
  const current = mode || (j && j.public ? 'public' : 'lan');
  useEffect(() => { setCopied(false); }, [current]);

  if (!j) return html`<div class="ticket ${pink ? '' : 'green'}"><div class="main-part"><div class="t-k">JOIN ADDRESS</div><div class="t-addr">…</div></div><div class="stub"></div></div>`;

  let addr = ''; let portLine = ''; let note = null; let copyValue = '';
  if (current === 'public') {
    if (j.public) {
      addr = j.public.srv ? j.public.host : hostPort(j.public);
      copyValue = addr;
      portLine = j.public.srv ? 'Paste into Multiplayer → Add Server' : '';
      note = html`Works from anywhere in the world.`;
    } else if (j.publicPending || (j.tunnelProvider !== 'none' && j.tunnelStatus !== 'error' && j.tunnelStatus !== 'needs-claim')) {
      addr = 'Getting your address…';
      note = html`The PandA Tunnel is setting things up. This takes a moment the first time.`;
    } else {
      addr = 'Not set up yet';
      note = html`Friends outside your home can't join yet. <a href="#/network">Turn on the PandA Tunnel →</a>`;
    }
  } else if (current === 'lan') {
    addr = hostPort(j.lan);
    copyValue = addr;
    note = j.local ? html`Or use <b class="mono">${hostPort(j.local)}</b>. Only works on your home network.` : html`Only works for people on your home network.`;
  } else {
    const b = j.bedrock.public || j.bedrock.lan;
    addr = b.host;
    copyValue = b.host;
    portLine = `Port ${b.port}`;
    note = j.bedrock.public ? html`Bedrock: Play → Servers → Add Server. Use this address and port.` : html`Same Wi-Fi only. <a href="#/network">Turn on the PandA Tunnel</a> for friends anywhere.`;
  }

  const copy = async () => {
    if (!copyValue) return;
    const ok = await copyText(copyValue);
    if (ok) { setCopied(true); setTimeout(() => setCopied(false), 1800); }
    else toast('error', 'Couldn\'t copy', 'Select the address and copy it by hand.');
  };

  return html`<div class=${cls('ticket', !pink && 'green')}>
    <div class="main-part">
      <div class="t-k"><${Icon} name="link" size=${13} /> ${title || 'JOIN ADDRESS'}</div>
      <div class="t-addr" style=${copyValue ? '' : 'opacity:.55;font-size:22px'}>${addr}</div>
      ${portLine ? html`<div class="t-port">${portLine}</div>` : null}
      <div class="note mt-8">${note}</div>
      <div class="t-tabs" role="tablist">
        ${modes.map((m) => html`<button role="tab" aria-selected=${current === m.id} class=${cls(current === m.id && 'on')} onClick=${() => setMode(m.id)}>${m.label}</button>`)}
      </div>
    </div>
    <div class="stub">
      <button class=${cls('copy', copied && 'done')} disabled=${!copyValue} onClick=${copy} aria-label="Copy address">
        <${Icon} name=${copied ? 'check' : 'copy'} size=${26} />${copied ? 'COPIED' : 'COPY'}
      </button>
      <span class="pixel tiny" style="opacity:.65">${current === 'bedrock' ? 'BEDROCK' : 'JAVA'}</span>
    </div>
  </div>`;
}
