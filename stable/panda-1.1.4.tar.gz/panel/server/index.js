// PandA Hosting — panel server. Serves the web UI + API, and streams live updates over a websocket.
const http = require('http');
const path = require('path');
const fs = require('fs');
const express = require('express');
const { WebSocketServer } = require('ws');

const paths = require('./lib/paths');
const { settings } = require('./lib/settings');
const auth = require('./lib/auth');
const { bus } = require('./lib/bus');
const system = require('./lib/system');
const manager = require('./lib/servers');
const tunnel = require('./lib/tunnel');
const remote = require('./lib/remote');
const updates = require('./lib/updates');
const content = require('./lib/content');
const { router, VERSION } = require('./routes');

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '2mb' }));

// Same-origin guard for state-changing requests (stops other websites poking the panel).
app.use((req, res, next) => {
  if (req.method === 'GET' || req.method === 'HEAD') return next();
  const origin = req.headers.origin;
  if (!origin) return next();
  try {
    const host = new URL(origin).host;
    if (host === req.headers.host) return next();
    if (req.socket.pandaRemote && host === remote.publicHost()) return next();
  } catch {}
  res.status(403).json({ error: 'Cross-site request blocked.' });
});

app.use('/api', router);

// Hosted resource packs (players' game clients download these, so no login).
app.get('/rp/:id/:file', (req, res) => {
  try {
    const srv = manager.get(req.params.id);
    const file = path.join(content.folderFor(srv, 'resourcepack'), content.safeName(req.params.file));
    if (!fs.existsSync(file)) return res.status(404).end();
    res.sendFile(file);
  } catch { res.status(404).end(); }
});

// Frontend + vendored libraries (no build step, works offline).
const vendor = {
  '/vendor/preact.mjs': 'preact/dist/preact.mjs',
  '/vendor/hooks.mjs': 'preact/hooks/dist/hooks.mjs',
  '/vendor/htm.mjs': 'htm/dist/htm.mjs',
  '/fonts/unbounded-500.woff2': '@fontsource/unbounded/files/unbounded-latin-500-normal.woff2',
  '/fonts/unbounded-700.woff2': '@fontsource/unbounded/files/unbounded-latin-700-normal.woff2',
  '/fonts/unbounded-900.woff2': '@fontsource/unbounded/files/unbounded-latin-900-normal.woff2',
  '/fonts/bricolage.woff2': '@fontsource-variable/bricolage-grotesque/files/bricolage-grotesque-latin-wght-normal.woff2',
  '/fonts/jetbrains-400.woff2': '@fontsource/jetbrains-mono/files/jetbrains-mono-latin-400-normal.woff2',
  '/fonts/jetbrains-700.woff2': '@fontsource/jetbrains-mono/files/jetbrains-mono-latin-700-normal.woff2',
  '/fonts/silkscreen-400.woff2': '@fontsource/silkscreen/files/silkscreen-latin-400-normal.woff2',
  '/fonts/silkscreen-700.woff2': '@fontsource/silkscreen/files/silkscreen-latin-700-normal.woff2',
};
for (const [url, file] of Object.entries(vendor)) {
  app.get(url, (req, res) => res.set('Cache-Control', 'public, max-age=604800').sendFile(path.join(paths.modules, file)));
}
app.use(express.static(paths.web, { index: false, maxAge: 0 }));
app.get(/^\/(?!api\/|ws).*/, (req, res) => res.sendFile(path.join(paths.web, 'index.html')));

app.use((err, req, res, next) => {
  void next;
  const status = err.status || 500;
  if (status >= 500) console.error('[api]', req.method, req.path, err);
  res.status(status).json({ error: err.message || 'Something went wrong.', code: err.status ? err.code : undefined });
});

// ------------------------------------------------------------------ websocket

const server = http.createServer(app);
// The door for "open the panel from anywhere": only reachable from this machine (the tunnel
// programs connect here), and everything arriving through it counts as the internet.
const remoteServer = http.createServer(app);
remoteServer.on('connection', (s) => { s.pandaRemote = true; });
const wss = new WebSocketServer({ noServer: true });

function onUpgrade(req, socket, head) {
  if (!req.url.startsWith('/ws')) return socket.destroy();
  if (settings.get('setupDone') && !auth.isAuthed(req)) {
    // A complete reply (then close), so tunnels pass a clean 401 on instead of an error.
    const body = '{"error":"Please sign in.","code":"AUTH"}';
    return socket.end(`HTTP/1.1 401 Unauthorized\r\nContent-Type: application/json\r\nContent-Length: ${body.length}\r\nConnection: close\r\n\r\n${body}`);
  }
  wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req));
}
server.on('upgrade', onUpgrade);
remoteServer.on('upgrade', onUpgrade);

wss.on('connection', (ws) => {
  ws.subs = new Set();
  ws.isAlive = true;
  ws.on('pong', () => { ws.isAlive = true; });
  ws.on('message', (raw) => {
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (m.t === 'sub' && m.id) ws.subs.add(m.id);
    if (m.t === 'unsub' && m.id) ws.subs.delete(m.id);
  });
  ws.send(JSON.stringify({ t: 'hello', version: VERSION, tunnel: tunnel.publicState(), remote: remote.publicState(), updates: updates.publicState() }));
});

const heartbeat = setInterval(() => {
  for (const ws of wss.clients) {
    if (!ws.isAlive) { ws.terminate(); continue; }
    ws.isAlive = false;
    try { ws.ping(); } catch {}
  }
}, 30000);
heartbeat.unref();

function sendAll(msg, filter) {
  const data = JSON.stringify(msg);
  for (const ws of wss.clients) if (ws.readyState === 1 && (!filter || filter(ws))) ws.send(data);
}

bus.on('broadcast', (msg) => sendAll(msg));

// Console lines are batched per server and only sent to pages watching that server.
const pendingLogs = new Map();
let flushTimer = null;
bus.on('log', (id, line) => {
  if (!pendingLogs.has(id)) pendingLogs.set(id, []);
  pendingLogs.get(id).push(line);
  if (!flushTimer) {
    flushTimer = setTimeout(() => {
      flushTimer = null;
      for (const [sid, lines] of pendingLogs) sendAll({ t: 'log', id: sid, lines }, (ws) => ws.subs.has(sid));
      pendingLogs.clear();
    }, 80);
  }
});

// ------------------------------------------------------------------ boot

// PANDA_PORT (set by the launcher / OS service) wins over the saved setting.
if (process.env.PANDA_PORT) settings.set('panelPort', Number(process.env.PANDA_PORT));
const port = Number(settings.get('panelPort')) || 8080;
const host = process.env.PANDA_HOST || '0.0.0.0';

server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') {
    console.error(`\n  PandA Hosting can't start: port ${port} is already in use.\n  Is PandA already running? Close it first, or set PANDA_PORT to another port.\n`);
    process.exit(2);
  }
  throw e;
});

// Loopback only. If the usual port is taken (a second PandA on this PC), any free port works.
function listenRemote(cb) {
  const want = Number(settings.get('remotePort')) || 8098;
  remoteServer.once('error', (e) => {
    if (e.code !== 'EADDRINUSE') throw e;
    remoteServer.listen(0, '127.0.0.1', () => cb(remoteServer.address().port));
  });
  remoteServer.listen(want, '127.0.0.1', () => cb(remoteServer.address().port));
}

server.listen(port, host, () => {
  system.startSampling();
  manager.startLoops();
  tunnel.init(manager);
  listenRemote((p) => remote.init(p));
  updates.init(manager);
  const ip = system.primaryIp();
  console.log('');
  console.log('  +----------------------------------------------+');
  console.log('  |   PandA Hosting  -  by Alien & Patrko        |');
  console.log('  +----------------------------------------------+');
  console.log(`  Panel on this computer : http://localhost:${port}`);
  console.log(`  Panel on your network  : http://${ip}:${port}`);
  console.log(`  Data folder            : ${paths.data}`);
  console.log('');
  setTimeout(() => manager.autoStartAll(), 1500);
});

let shuttingDown = false;
async function shutdown(sig) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`\n  ${sig} — stopping servers safely…`);
  try { tunnel.shutdown(); } catch {}
  try { remote.shutdown(); } catch {}
  try { await manager.stopAll(); } catch {}
  settings.flush();
  process.exit(0);
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGHUP', () => shutdown('SIGHUP'));
process.on('unhandledRejection', (e) => console.error('[unhandled]', e));
// Keep the panel (and the servers it watches) alive if one background job blows up.
process.on('uncaughtException', (e) => {
  console.error('[uncaught]', e);
  try { require('./lib/bus').notify('error', 'PandA hit an unexpected problem', e.message || String(e)); } catch {}
});
