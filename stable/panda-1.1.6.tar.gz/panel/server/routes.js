// REST API for the PandA panel.
const fs = require('fs');
const path = require('path');
const os = require('os');
const express = require('express');
const multer = require('multer');
const QRCode = require('qrcode');
const { execFile } = require('child_process');

const paths = require('./lib/paths');
const { settings, publicSettings } = require('./lib/settings');
const auth = require('./lib/auth');
const manager = require('./lib/servers');
const installers = require('./lib/installers');
const java = require('./lib/java');
const props = require('./lib/properties');
const content = require('./lib/content');
const modrinth = require('./lib/sources/modrinth');
const curseforge = require('./lib/sources/curseforge');
const players = require('./lib/players');
const backups = require('./lib/backups');
const roles = require('./lib/roles');
const tasks = require('./lib/tasks');
const system = require('./lib/system');
const wifi = require('./lib/wifi');
const tunnel = require('./lib/tunnel');
const remote = require('./lib/remote');
const updates = require('./lib/updates');
const world = require('./lib/world');
const net = require('./lib/net');
const { PROPERTIES, PROPERTY_MAP } = require('./lib/meta');
const { notify } = require('./lib/bus');

const VERSION = require('../package.json').version;
const upload = multer({ dest: paths.tmp, limits: { fileSize: 4 * 1024 * 1024 * 1024, files: 200 } });
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const bad = (msg, status = 400) => Object.assign(new Error(msg), { status });

const r = express.Router();

// ------------------------------------------------------------------ public

r.get('/state', (req, res) => {
  res.json({
    name: 'PandA Hosting',
    version: VERSION,
    setupDone: !!settings.get('setupDone'),
    authed: auth.isAuthed(req),
    local: auth.isLocal(req),
    remote: auth.isRemote(req),
    deviceName: settings.get('deviceName'),
    mode: paths.mode,
    platform: process.platform,
  });
});

r.post('/setup', wrap(async (req, res) => {
  if (settings.get('setupDone')) throw bad('Setup is already finished.', 409);
  const { deviceName, password, trustLocal, curseforgeKey } = req.body || {};
  if (!password || String(password).length < 4) throw bad('Pick a password with at least 4 characters.');
  settings.patch({
    deviceName: String(deviceName || 'PandA').trim().slice(0, 40) || 'PandA',
    trustLocal: trustLocal !== false,
    curseforgeKey: curseforgeKey ? curseforge.cleanKey(curseforgeKey) : settings.get('curseforgeKey'),
  });
  auth.setPassword(password);
  // The box runs on UTC; night-time updates use the owner's own clock.
  if ((req.body || {}).tz) updates.setPrefs({ tz: req.body.tz });
  settings.set('setupDone', true);
  settings.flush();
  applyHostname(settings.get('deviceName'));
  auth.login(req, res);
  res.json({ ok: true });
}));

r.post('/login', wrap(async (req, res) => {
  if (!auth.allowAttempt(req)) throw bad('Too many tries. Wait a few minutes.', 429);
  if (!auth.checkPassword((req.body || {}).password || '')) throw bad('Wrong password.', 401);
  auth.login(req, res);
  res.json({ ok: true });
}));

r.post('/logout', (req, res) => { auth.logout(req, res); res.json({ ok: true }); });

// Everything below needs a signed-in user (or the local screen).
r.use((req, res, next) => {
  // Before setup only what the wizard needs is reachable (Wi-Fi, versions, machine info).
  const preSetupOk = req.path === '/network' || req.path.startsWith('/network/wifi') || req.path.startsWith('/versions') || req.path === '/system' || req.path.startsWith('/system/qr');
  if (!settings.get('setupDone') && !preSetupOk) {
    return res.status(409).json({ error: 'Finish setup first.', code: 'SETUP' });
  }
  if (!settings.get('setupDone')) return next();
  return auth.middleware(req, res, next);
});

// ------------------------------------------------------------------ system

r.get('/system', wrap(async (req, res) => {
  res.json({
    version: VERSION,
    info: system.info(),
    history: system.history,
    settings: publicSettings(),
    java: java.installedJava(),
    panelUrl: `http://${system.primaryIp()}:${settings.get('panelPort')}`,
    localName: paths.mode === 'os' ? `http://${hostnameSlug(settings.get('deviceName'))}.local` : null,
  });
}));

r.get('/system/qr', wrap(async (req, res) => {
  const text = String(req.query.text || '').slice(0, 300);
  const svg = await QRCode.toString(text || 'PandA Hosting', { type: 'svg', margin: 1, color: { dark: '#0b0d0b', light: '#00000000' } });
  res.type('image/svg+xml').send(svg);
}));

r.put('/settings', wrap(async (req, res) => {
  const b = req.body || {};
  if (b.deviceName !== undefined) { settings.set('deviceName', String(b.deviceName).trim().slice(0, 40) || 'PandA'); applyHostname(settings.get('deviceName')); }
  if (b.trustLocal !== undefined) settings.set('trustLocal', !!b.trustLocal);
  if (b.curseforgeKey !== undefined) settings.set('curseforgeKey', curseforge.cleanKey(b.curseforgeKey));
  if (b.defaults) settings.set('defaults', { ...settings.get('defaults'), ...b.defaults });
  if (b.password) {
    // The trusted local screen can reset a forgotten password.
    const trustedScreen = auth.isLocal(req) && settings.get('trustLocal');
    if (settings.get('auth') && !trustedScreen && !auth.checkPassword(b.password.current || '')) throw bad('Your current password is wrong.', 401);
    const min = remote.exposed() ? 8 : 4;
    if (!b.password.next || String(b.password.next).length < min) throw bad(`The new password needs at least ${min} characters${min > 4 ? ' while other people can reach this box' : ''}.`);
    auth.setPassword(b.password.next);
    auth.logoutEverywhere();
    auth.login(req, res);
  }
  settings.flush();
  res.json({ ok: true, settings: publicSettings() });
}));

// Tests a CurseForge key and (with save) stores it. force saves even when CurseForge
// can't be reached or is blocked — but never a key CurseForge itself rejected.
r.post('/settings/curseforge/test', wrap(async (req, res) => {
  const b = req.body || {};
  const key = curseforge.cleanKey(b.key || settings.get('curseforgeKey'));
  if (!key) throw bad('Paste a key first.');
  const out = await curseforge.testKey(key);
  if (b.save && (out.ok || (b.force && out.reason !== 'rejected'))) {
    settings.set('curseforgeKey', key);
    settings.flush();
    out.saved = true;
  }
  res.json(out);
}));

// ---- PandA OS updates
r.get('/updates', (req, res) => res.json({ updates: updates.publicState() }));
r.post('/updates/check', wrap(async (req, res) => res.json({ updates: await updates.check() })));
r.post('/updates/download', wrap(async (req, res) => {
  updates.download().catch(() => {});
  res.json({ updates: updates.publicState() });
}));
r.post('/updates/install', wrap(async (req, res) => res.json({ updates: await updates.install({ force: !!(req.body || {}).force }) })));
r.put('/updates/settings', wrap(async (req, res) => res.json({ updates: updates.setPrefs(req.body || {}) })));

r.post('/system/power', wrap(async (req, res) => {
  const action = (req.body || {}).action;
  if (paths.mode !== 'os' || process.platform !== 'linux') throw bad('Power controls only work on PandA OS.');
  if (!['reboot', 'poweroff'].includes(action)) throw bad('Unknown action');
  res.json({ ok: true });
  await manager.stopAll();
  execFile('systemctl', [action], () => {});
}));

function hostnameSlug(name) { return String(name).toLowerCase().replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 30) || 'panda'; }
function applyHostname(name) {
  if (paths.mode !== 'os' || process.platform !== 'linux') return;
  execFile('hostnamectl', ['set-hostname', hostnameSlug(name)], () => {});
}

// ------------------------------------------------------------------ network

r.get('/network', wrap(async (req, res) => {
  res.json({
    wifi: await wifi.status().catch((e) => ({ supported: false, error: e.message })),
    lan: system.lanAddresses(),
    primaryIp: system.primaryIp(),
    panelPort: settings.get('panelPort'),
    tunnel: tunnel.publicState(),
    remote: remote.publicState(),
    mode: paths.mode,
  });
}));
r.get('/network/wifi/scan', wrap(async (req, res) => res.json({ networks: await wifi.scan() })));
r.post('/network/wifi/connect', wrap(async (req, res) => {
  const { ssid, password } = req.body || {};
  if (!ssid) throw bad('Pick a network.');
  res.json({ status: await wifi.connect(ssid, password) });
}));
r.put('/network/tunnel', wrap(async (req, res) => {
  const provider = (req.body || {}).provider;
  if (!['none', 'playit', 'upnp'].includes(provider)) throw bad('Unknown option');
  res.json({ tunnel: await tunnel.setProvider(provider) });
}));
r.post('/network/tunnel/unlink', wrap(async (req, res) => res.json({ tunnel: await tunnel.unlinkPlayit() })));

// Opening the panel from anywhere, or letting friends reach this box over Tailscale. Turning
// either on asks for the panel password (it becomes the lock), and a short password must be
// replaced by a longer one first.
function unlock(req, res) {
  const { password, newPassword } = req.body || {};
  if (!auth.allowAttempt(req)) throw bad('Too many tries. Wait a few minutes.', 429);
  if (!auth.checkPassword(password || '')) throw Object.assign(bad('That\'s not your panel password.', 403), { code: 'PASSWORD' });
  if (String(password).length < 8) {
    if (!newPassword) throw Object.assign(bad('Your password is short. Once other people can reach this box it\'s the only lock, so pick one with at least 8 characters.'), { code: 'WEAK' });
    if (String(newPassword).length < 8) throw Object.assign(bad('The new password needs at least 8 characters.'), { code: 'WEAK' });
    auth.setPassword(newPassword);
    auth.logoutEverywhere();
    auth.login(req, res);
  }
}
r.get('/network/remote', (req, res) => res.json({ remote: remote.publicState() }));
r.put('/network/remote', wrap(async (req, res) => {
  const { provider } = req.body || {};
  if (provider !== 'none') unlock(req, res);
  res.json({ remote: await remote.setProvider(provider) });
}));
r.post('/network/remote/refresh', (req, res) => res.json({ remote: remote.refresh() }));
r.post('/network/remote/logout', wrap(async (req, res) => res.json({ remote: await remote.logoutTailscale() })));
r.put('/network/remote/friends', wrap(async (req, res) => {
  const on = (req.body || {}).on === true;
  if (on) unlock(req, res);
  res.json({ remote: await remote.setFriends(on) });
}));
r.post('/network/remote/friends/ping', wrap(async (req, res) => {
  const ping = await remote.pingFriend(String((req.body || {}).ip || ''));
  res.json({ ping, remote: remote.publicState() });
}));

// ------------------------------------------------------------------ versions

r.get('/versions/:type', wrap(async (req, res) => {
  const list = await installers.listVersions(req.params.type);
  res.json({ versions: list.slice(0, 400) });
}));
r.get('/versions/:type/:mc/loaders', wrap(async (req, res) => {
  res.json({ loaders: await installers.listLoaders(req.params.type, req.params.mc) });
}));
r.get('/java/required/:mc', wrap(async (req, res) => res.json({ major: await java.requiredJava(req.params.mc) })));

// ------------------------------------------------------------------ tasks

r.get('/tasks', (req, res) => res.json({ tasks: tasks.list() }));
r.get('/tasks/:id', (req, res) => {
  const t = tasks.get(req.params.id);
  if (!t) return res.status(404).json({ error: 'Task not found' });
  res.json({ task: t });
});

// ------------------------------------------------------------------ servers

function joinInfo(srv) {
  const ip = system.primaryIp();
  const t = tunnel.addressesFor(srv.id);
  const pub = tunnel.publicState();
  return {
    lan: { host: ip, port: srv.meta.port },
    local: paths.mode === 'os' ? { host: `${hostnameSlug(settings.get('deviceName'))}.local`, port: srv.meta.port } : null,
    public: t && t.java ? t.java : null,
    publicPending: !!(t && t.pending),
    publicError: t && t.error ? t.error : null,
    bedrock: srv.meta.bedrock && srv.meta.bedrock.enabled ? { lan: { host: ip, port: srv.meta.bedrock.port }, public: t && t.bedrock ? t.bedrock : null } : null,
    tunnelProvider: pub.provider,
    tunnelStatus: pub.status,
  };
}

function serverDetail(srv) {
  const p = props.read(path.join(srv.dir, 'server.properties'));
  const fix = content.autoFixLog(srv);
  return {
    server: srv.summary(),
    meta: {
      javaMajor: srv.meta.javaMajor, javaOverride: srv.meta.javaOverride || null, jvmFlags: srv.meta.jvmFlags || 'aikar',
      customJvmArgs: srv.meta.customJvmArgs || '', reserveMemory: !!srv.meta.reserveMemory,
      autoStart: !!srv.meta.autoStart, autoRestart: srv.meta.autoRestart !== false, autoFixDeps: srv.meta.autoFixDeps !== false,
      publicAccess: srv.meta.publicAccess !== false, schedule: srv.meta.schedule || {}, build: srv.meta.build || null,
      launch: srv.meta.launch || null, installed: !!srv.meta.installed, pendingGamerules: srv.meta.pendingGamerules || {},
      lastAutoBackup: srv.meta.lastAutoBackup || null,
    },
    quick: { motd: p.motd || '', maxPlayers: Number(p['max-players'] || 20), whitelist: p['white-list'] === 'true', onlineMode: p['online-mode'] !== 'false', difficulty: p.difficulty || 'easy', gamemode: p.gamemode || 'survival' },
    join: joinInfo(srv),
    contentKind: content.contentKindFor(srv),
    autofix: { unseen: fix.entries.filter((e) => !e.seen).length, latest: fix.entries[0] || null },
    stats: srv.stats,
    findings: srv.findings,
    totalMemMb: Math.floor(os.totalmem() / 1048576),
  };
}

r.get('/servers', (req, res) => {
  res.json({ servers: manager.list().map((s) => ({ ...s.summary(), join: joinInfo(s) })) });
});

r.post('/servers', wrap(async (req, res) => {
  const b = req.body || {};
  if (!b.modpack && !installers.types[b.type]) throw bad('Pick a server type.');
  if (!b.modpack && !b.mcVersion) throw bad('Pick a Minecraft version.');
  res.json(await manager.create(b));
}));

const S = (req) => manager.get(req.params.id);

r.get('/servers/:id', (req, res) => res.json(serverDetail(S(req))));

r.patch('/servers/:id', wrap(async (req, res) => {
  const srv = S(req);
  const result = await manager.updateSettings(srv, req.body || {});
  res.json({ ...result, detail: serverDetail(srv) });
}));

r.delete('/servers/:id', wrap(async (req, res) => {
  await manager.remove(S(req), { deleteBackups: req.query.backups === '1' });
  res.json({ ok: true });
}));

r.post('/servers/:id/icon', wrap(async (req, res) => {
  manager.setIcon(S(req), (req.body || {}).dataUrl);
  res.json({ ok: true });
}));
r.get('/servers/:id/icon', (req, res) => {
  const f = path.join(S(req).dir, 'server-icon.png');
  if (!fs.existsSync(f)) return res.status(404).end();
  res.set('Cache-Control', 'no-cache').sendFile(f);
});

r.post('/servers/:id/power', wrap(async (req, res) => {
  const srv = S(req);
  const action = (req.body || {}).action;
  if (action === 'start') await srv.start();
  else if (action === 'stop') srv.stop();
  else if (action === 'restart') srv.restart().catch(() => {});
  else if (action === 'kill') srv.kill();
  else throw bad('Unknown action');
  res.json({ ok: true, status: srv.status });
}));

r.post('/servers/:id/reinstall', wrap(async (req, res) => {
  const b = req.body || {};
  res.json({ taskId: manager.reinstall(S(req), { mcVersion: b.mcVersion, loaderVersion: b.loaderVersion }) });
}));

r.post('/servers/:id/bedrock', wrap(async (req, res) => {
  res.json({ taskId: manager.setBedrock(S(req), !!(req.body || {}).enabled) });
}));

// ---- console

r.get('/servers/:id/console', (req, res) => {
  const srv = S(req);
  res.json({ lines: srv.lines.slice(-800), findings: srv.findings });
});

r.post('/servers/:id/command', wrap(async (req, res) => {
  const cmd = String((req.body || {}).command || '').trim();
  if (!cmd) throw bad('Type a command.');
  S(req).send(cmd);
  res.json({ ok: true });
}));

// ---- players + chat

r.get('/servers/:id/players', (req, res) => {
  const srv = S(req);
  const known = players.knownPlayers(srv.dir);
  const p = props.read(path.join(srv.dir, 'server.properties'));
  res.json({
    online: [...srv.online.values()],
    known,
    whitelistOn: p['white-list'] === 'true',
    onlineMode: p['online-mode'] !== 'false',
    max: srv.maxPlayers(),
    running: srv.status === 'online',
  });
});

const ONLINE_ONLY = new Set(['kick', 'msg', 'gamemode', 'kill', 'tp-spawn']);
r.post('/servers/:id/players/action', wrap(async (req, res) => {
  const srv = S(req);
  const { action, name, reason, value } = req.body || {};
  if (!/^[.*]?[A-Za-z0-9_]{1,16}$/.test(String(name || ''))) throw bad('That doesn\'t look like a Minecraft name.');
  const why = String(reason || '').replace(/[\r\n]/g, ' ').slice(0, 200);
  const running = srv.status === 'online';
  if (ONLINE_ONLY.has(action) && !running) throw bad('The server needs to be running for that.');
  if (running) {
    const cmds = {
      kick: `kick ${name} ${why || 'Kicked by an operator'}`,
      ban: `ban ${name} ${why || 'Banned by an operator'}`,
      pardon: `pardon ${name}`,
      op: `op ${name}`,
      deop: `deop ${name}`,
      'whitelist-add': `whitelist add ${name}`,
      'whitelist-remove': `whitelist remove ${name}`,
      msg: `tell ${name} ${String(value || '').slice(0, 200)}`,
      gamemode: `gamemode ${['survival', 'creative', 'adventure', 'spectator'].includes(value) ? value : 'survival'} ${name}`,
      kill: `kill ${name}`,
    };
    if (!cmds[action]) throw bad('Unknown action');
    srv.send(cmds[action]);
  } else {
    const onlineMode = props.read(path.join(srv.dir, 'server.properties'))['online-mode'] !== 'false';
    await players.offlineAction(srv.dir, action, name, { onlineMode, reason: why });
  }
  res.json({ ok: true });
}));

r.post('/servers/:id/whitelist', wrap(async (req, res) => {
  const srv = S(req);
  const on = !!(req.body || {}).enabled;
  props.update(path.join(srv.dir, 'server.properties'), { 'white-list': String(on) });
  if (srv.status === 'online') srv.send(`whitelist ${on ? 'on' : 'off'}`);
  res.json({ ok: true });
}));

r.get('/servers/:id/chat', (req, res) => res.json({ chat: S(req).chat }));

r.post('/servers/:id/broadcast', wrap(async (req, res) => {
  const srv = S(req);
  const { message, style = 'chat' } = req.body || {};
  const text = String(message || '').replace(/[\r\n]+/g, ' ').trim().slice(0, 256);
  if (!text) throw bad('Write a message first.');
  if (srv.status !== 'online') throw bad('The server isn\'t running.');
  const json = (o) => JSON.stringify(o);
  if (style === 'title') {
    srv.send(`title @a subtitle ${json({ text: 'Server announcement', color: 'gray' })}`, { echo: false });
    srv.send(`title @a title ${json({ text, color: 'light_purple' })}`, { echo: false });
  } else if (style === 'actionbar') {
    srv.send(`title @a actionbar ${json({ text, color: 'green' })}`, { echo: false });
  } else {
    srv.send(`tellraw @a ${json([{ text: '[', color: 'dark_gray' }, { text: 'PandA', color: 'light_purple' }, { text: '] ', color: 'dark_gray' }, { text, color: 'white' }])}`, { echo: false });
  }
  srv.addChat({ type: 'broadcast', name: 'You', message: text, style });
  res.json({ ok: true });
}));

// ---- server.properties

r.get('/servers/:id/properties', (req, res) => {
  const srv = S(req);
  const values = props.read(path.join(srv.dir, 'server.properties'));
  const generated = fs.existsSync(path.join(srv.dir, 'logs'));
  const known = PROPERTIES.filter((p) => !generated || p.key in values || !p.advanced);
  const unknown = Object.keys(values).filter((k) => !PROPERTY_MAP[k]).map((k) => ({ key: k, group: 'Other', type: /^(true|false)$/.test(values[k]) ? 'bool' : 'string', def: '', label: k, help: 'A setting from this Minecraft version or a mod. PandA doesn\'t have a description for it yet.' }));
  const masked = { ...values };
  if (masked['rcon.password']) masked['rcon.password'] = '••••••••';
  res.json({ values: masked, meta: [...known, ...unknown], generated, running: srv.status === 'online' });
});

r.put('/servers/:id/properties', wrap(async (req, res) => {
  const srv = S(req);
  const changes = (req.body || {}).changes || {};
  const clean = {};
  for (const [k, v] of Object.entries(changes)) {
    const m = PROPERTY_MAP[k];
    if (m && m.managed) continue;
    if (!/^[a-z0-9.\-_]+$/i.test(k)) continue;
    let val = String(v ?? '');
    if (m && m.type === 'int') {
      if (!/^-?\d+$/.test(val)) throw bad(`${m.label} must be a whole number.`);
      const n = Number(val);
      if (m.min !== undefined && n < m.min) throw bad(`${m.label} can't be lower than ${m.min}.`);
      if (m.max !== undefined && n > m.max) throw bad(`${m.label} can't be higher than ${m.max}.`);
    }
    if (m && m.type === 'bool') val = val === 'true' ? 'true' : 'false';
    // Mods add their own world types (e.g. skyblockbuilder:skyblock), so any "namespace:id" is fine there.
    const modWorldType = k === 'level-type' && /^[a-z0-9_.-]+:[a-z0-9_./-]+$/.test(val);
    if (m && m.type === 'enum' && !modWorldType && !m.options.some((o) => o.value === val)) throw bad(`Pick a valid option for ${m.label}.`);
    clean[k] = val;
  }
  props.update(path.join(srv.dir, 'server.properties'), clean);
  if ('white-list' in clean && srv.status === 'online') srv.send(`whitelist ${clean['white-list'] === 'true' ? 'on' : 'off'}`, { echo: false });
  if ('difficulty' in clean && srv.status === 'online') srv.send(`difficulty ${clean.difficulty}`, { echo: false });
  res.json({ ok: true, restartNeeded: srv.status === 'online' });
}));

// ---- the world itself

r.get('/servers/:id/world', (req, res) => res.json(world.info(S(req))));
r.post('/servers/:id/world/reset', wrap(async (req, res) => {
  const srv = S(req);
  if (['installing', 'starting', 'stopping'].includes(srv.status)) throw bad('Wait until the server has finished starting or stopping.');
  const b = req.body || {};
  const seed = b.seed !== undefined && b.seed !== null ? String(b.seed).trim().slice(0, 64) : undefined;
  const levelType = typeof b.levelType === 'string' && /^[a-z0-9_.-]+:[a-z0-9_./-]+$/.test(b.levelType) ? b.levelType : undefined;
  const id = tasks.run(`New world for ${srv.meta.name}`, { serverId: srv.id, kind: 'reset' }, (task) =>
    world.reset(srv, { seed, levelType, useModpack: b.useModpack !== false }, task));
  res.json({ taskId: id });
}));

// ---- gamerules

r.get('/servers/:id/gamerules', wrap(async (req, res) => res.json(await manager.gamerules(S(req)))));
r.put('/servers/:id/gamerules', wrap(async (req, res) => {
  const { key, value } = req.body || {};
  res.json(await manager.setGamerule(S(req), String(key), value));
}));

// ---- roles

r.get('/servers/:id/roles', (req, res) => {
  const srv = S(req);
  const data = roles.load(srv);
  res.json({ roles: data.roles, dirty: !!data.dirty, catalog: roles.CATALOG, luckperms: roles.hasLuckPerms(srv), players: players.knownPlayers(srv.dir).map((p) => p.name), running: srv.status === 'online', canLuckPerms: !!content.contentKindFor(srv) });
});
r.put('/servers/:id/roles', wrap(async (req, res) => {
  const srv = S(req);
  const list = (req.body || {}).roles;
  if (!Array.isArray(list)) throw bad('Bad roles');
  const data = roles.load(srv);
  data.roles = list.slice(0, 30).map((x, i) => ({
    id: roles.slug(x.id || x.name || `role${i}`),
    name: String(x.name || 'Role').slice(0, 24),
    color: /^#[0-9a-f]{6}$/i.test(x.color) ? x.color : '#7dfc58',
    prefix: String(x.prefix || '').slice(0, 32),
    opLevel: Math.max(0, Math.min(4, Number(x.opLevel) || 0)),
    weight: Math.max(0, Math.min(1000, Number(x.weight) || 0)),
    permissions: [...new Set((x.permissions || []).map(String).filter((p) => /^[a-z0-9*._\-]+$/i.test(p)))].slice(0, 200),
    members: [...new Set((x.members || []).map(String).filter((n) => /^[.*]?[A-Za-z0-9_]{1,16}$/.test(n)))].slice(0, 500),
  }));
  data.dirty = true;
  roles.save(srv, data);
  const result = await manager.applyRoles(srv);
  res.json({ ok: true, result });
}));
r.post('/servers/:id/roles/luckperms', wrap(async (req, res) => {
  const srv = S(req);
  const kind = content.contentKindFor(srv);
  if (!kind) throw bad('LuckPerms needs a Paper, Purpur, Fabric, Forge or NeoForge server.');
  const id = tasks.run('Installing LuckPerms', { serverId: srv.id, kind: 'install' }, async (task) => {
    const p = await modrinth.project('luckperms');
    return content.install(srv, { source: 'modrinth', projectId: p.id, kind }, { onProgress: (x) => task.progress(x) });
  });
  res.json({ taskId: id });
}));

// ---- content (mods / plugins / datapacks / resource packs)

const KINDS = new Set(['mod', 'plugin', 'datapack', 'resourcepack']);
function kindParam(req) {
  const k = req.params.kind;
  if (!KINDS.has(k)) throw bad('Unknown content type');
  return k;
}

r.get('/servers/:id/content/:kind', wrap(async (req, res) => {
  const srv = S(req);
  const kind = kindParam(req);
  const items = content.listInstalled(srv, kind);
  const extra = {};
  if (kind === 'resourcepack') {
    const p = props.read(path.join(srv.dir, 'server.properties'));
    extra.active = srv.meta.resourcePack || null;
    extra.url = p['resource-pack'] || '';
    extra.required = p['require-resource-pack'] === 'true';
    extra.prompt = p['resource-pack-prompt'] || '';
  }
  res.json({ items, autofix: content.autoFixLog(srv), ...extra });
}));

r.post('/servers/:id/content/:kind/install', wrap(async (req, res) => {
  const srv = S(req);
  const kind = kindParam(req);
  const { source = 'modrinth', projectId, versionId, name } = req.body || {};
  if (!projectId) throw bad('Nothing to install.');
  const id = tasks.run(`Installing ${name || 'content'}`, { serverId: srv.id, kind: 'install' }, async (task) => {
    const result = await content.install(srv, { source, projectId, versionId, kind }, { onProgress: (p) => task.progress(p) });
    if (result.dependencies.length) {
      notify('success', `Auto-installed ${result.dependencies.length} ${result.dependencies.length === 1 ? 'dependency' : 'dependencies'}`, result.dependencies.map((d) => d.name).join(', '), { serverId: srv.id, autofix: true });
    }
    return { ...result, restartNeeded: srv.status === 'online' };
  });
  res.json({ taskId: id });
}));

r.post('/servers/:id/content/:kind/upload', upload.array('files', 200), wrap(async (req, res) => {
  const srv = S(req);
  const kind = kindParam(req);
  const dir = content.folderFor(srv, kind);
  fs.mkdirSync(dir, { recursive: true });
  const okExt = kind === 'mod' || kind === 'plugin' ? /\.jar$/i : /\.zip$/i;
  const added = [];
  const rejected = [];
  for (const f of req.files || []) {
    const name = content.safeName(Buffer.from(f.originalname, 'latin1').toString('utf8'));
    if (!okExt.test(name)) { rejected.push(name); fs.rmSync(f.path, { force: true }); continue; }
    const dest = path.join(dir, name);
    fs.copyFileSync(f.path, dest);
    fs.rmSync(f.path, { force: true });
    content.record(srv, kind, name, { source: 'upload', name: name.replace(/\.(jar|zip)$/i, ''), installedAt: Date.now() });
    added.push(name);
  }
  let taskId = null;
  if (added.length && (kind === 'mod' || kind === 'plugin') && srv.meta.autoFixDeps !== false) {
    taskId = tasks.run('Checking for missing libraries', { serverId: srv.id, kind: 'deps' }, async (task) => {
      const r2 = await content.scanAndFix(srv, { onProgress: (p) => task.progress(p) });
      if (r2.fixed.length) notify('success', `Auto-installed ${r2.fixed.length} missing ${r2.fixed.length === 1 ? 'library' : 'libraries'}`, r2.fixed.map((x) => x.name).join(', '), { serverId: srv.id, autofix: true });
      return r2;
    });
  }
  res.json({ added, rejected, taskId });
}));

r.post('/servers/:id/content/:kind/toggle', wrap(async (req, res) => {
  const srv = S(req);
  res.json({ file: content.toggle(srv, kindParam(req), String((req.body || {}).file || '')) });
}));

r.delete('/servers/:id/content/:kind', wrap(async (req, res) => {
  const srv = S(req);
  const kind = kindParam(req);
  const file = String(req.query.file || '');
  if (kind === 'resourcepack' && srv.meta.resourcePack === file) await setResourcePack(srv, null, {});
  content.remove(srv, kind, file);
  res.json({ ok: true });
}));

r.post('/servers/:id/content/scan', wrap(async (req, res) => {
  const srv = S(req);
  const id = tasks.run('Checking for missing libraries', { serverId: srv.id, kind: 'deps' }, async (task) => {
    const r2 = await content.scanAndFix(srv, { onProgress: (p) => task.progress(p) });
    if (r2.fixed.length) notify('success', `Auto-installed ${r2.fixed.length} missing ${r2.fixed.length === 1 ? 'library' : 'libraries'}`, r2.fixed.map((x) => x.name).join(', '), { serverId: srv.id, autofix: true });
    return r2;
  });
  res.json({ taskId: id });
}));

r.get('/servers/:id/content/:kind/updates', wrap(async (req, res) => {
  res.json({ updates: await content.checkUpdates(S(req), kindParam(req)) });
}));

r.post('/servers/:id/autofix/seen', (req, res) => { content.markAutoFixSeen(S(req)); res.json({ ok: true }); });

// Resource pack hosting: PandA serves the zip so you don't need a download link.
async function setResourcePack(srv, file, { required, prompt, url }) {
  const p = path.join(srv.dir, 'server.properties');
  if (!file && !url) {
    srv.meta.resourcePack = null;
    props.update(p, { 'resource-pack': '', 'resource-pack-sha1': '', 'require-resource-pack': 'false' });
    manager.saveIndex();
    return;
  }
  let link = url;
  let sha1 = '';
  if (file) {
    const full = path.join(content.folderFor(srv, 'resourcepack'), content.safeName(file));
    if (!fs.existsSync(full)) throw bad('That resource pack is missing.');
    sha1 = await net.hashFile(full, 'sha1');
    link = `http://${system.primaryIp()}:${settings.get('panelPort')}/rp/${srv.id}/${encodeURIComponent(content.safeName(file))}`;
  }
  srv.meta.resourcePack = file || null;
  props.update(p, {
    'resource-pack': link,
    'resource-pack-sha1': sha1,
    'require-resource-pack': required ? 'true' : 'false',
    'resource-pack-prompt': prompt ? JSON.stringify({ text: String(prompt).slice(0, 120) }) : '',
  });
  manager.saveIndex();
}

r.post('/servers/:id/resourcepack', wrap(async (req, res) => {
  const srv = S(req);
  const b = req.body || {};
  await setResourcePack(srv, b.file || null, { required: !!b.required, prompt: b.prompt, url: b.url });
  res.json({ ok: true, restartNeeded: srv.status === 'online' });
}));

// ---- browse Modrinth / CurseForge

const SRC = { modrinth, curseforge };
function source(req) {
  const s = SRC[req.params.source];
  if (!s) throw bad('Unknown source');
  return s;
}

r.get('/browse/:source/search', wrap(async (req, res) => {
  const s = source(req);
  const q = req.query;
  let mc = q.mc || undefined;
  let loaders = q.loaders ? String(q.loaders).split(',') : undefined;
  if (q.serverId) {
    const srv = manager.get(q.serverId);
    if (q.compatible !== '0') { mc = srv.meta.mcVersion; loaders = content.loadersFor(srv, q.kind || 'mod'); }
  }
  try {
    res.json(await s.search({ query: q.q || '', kind: q.kind || 'mod', mc, loaders, offset: Number(q.offset) || 0, limit: Math.min(Number(q.limit) || 24, 50), sort: q.sort || 'relevance' }));
  } catch (e) {
    if (e.code === 'NO_CF_KEY') return res.status(412).json({ error: e.message, code: e.code });
    throw e;
  }
}));

r.get('/browse/:source/project/:pid', wrap(async (req, res) => {
  try { res.json({ project: await source(req).project(req.params.pid) }); } catch (e) {
    if (e.code === 'NO_CF_KEY') return res.status(412).json({ error: e.message, code: e.code });
    throw e;
  }
}));

r.get('/browse/:source/project/:pid/versions', wrap(async (req, res) => {
  const s = source(req);
  let mc; let loaders;
  if (req.query.serverId) {
    const srv = manager.get(req.query.serverId);
    mc = srv.meta.mcVersion;
    loaders = content.loadersFor(srv, req.query.kind || 'mod');
  }
  if (req.query.all === '1') { mc = undefined; loaders = undefined; }
  try { res.json({ versions: (await s.versions(req.params.pid, { mc, loaders })).slice(0, 60) }); } catch (e) {
    if (e.code === 'NO_CF_KEY') return res.status(412).json({ error: e.message, code: e.code });
    throw e;
  }
}));

// ---- files

function safePath(srv, rel) {
  const root = path.resolve(srv.dir);
  const full = path.resolve(root, String(rel || '').replace(/^[/\\]+/, ''));
  if (full !== root && !full.startsWith(root + path.sep)) throw bad('That path is outside the server.');
  return full;
}

r.get('/servers/:id/files', wrap(async (req, res) => {
  const srv = S(req);
  const full = safePath(srv, req.query.path);
  if (!fs.existsSync(full)) throw bad('Folder not found.', 404);
  const entries = fs.readdirSync(full, { withFileTypes: true }).map((e) => {
    let st = null; try { st = fs.statSync(path.join(full, e.name)); } catch {}
    return { name: e.name, dir: e.isDirectory(), size: st && st.isFile() ? st.size : null, mtime: st ? st.mtimeMs : null };
  }).sort((a, b) => (b.dir - a.dir) || a.name.localeCompare(b.name));
  res.json({ path: path.relative(srv.dir, full).split(path.sep).join('/'), entries });
}));

const TEXT_EXT = /\.(txt|properties|json|json5|yml|yaml|toml|cfg|conf|ini|log|md|mcmeta|mcfunction|js|zs|sh|bat|csv|xml|lang|snbt|secret|list|options)$/i;
r.get('/servers/:id/files/read', wrap(async (req, res) => {
  const full = safePath(S(req), req.query.path);
  const st = fs.statSync(full);
  if (st.size > 3 * 1024 * 1024) throw bad('That file is too big to edit here. Download it instead.');
  const buf = fs.readFileSync(full);
  const binary = !TEXT_EXT.test(full) && buf.subarray(0, 8000).includes(0);
  if (binary) throw bad('That isn\'t a text file. Download it instead.');
  res.json({ content: buf.toString('utf8'), size: st.size });
}));

r.put('/servers/:id/files/write', wrap(async (req, res) => {
  const { path: rel, content: text } = req.body || {};
  const full = safePath(S(req), rel);
  fs.mkdirSync(path.dirname(full), { recursive: true });
  fs.writeFileSync(full, String(text ?? ''));
  res.json({ ok: true });
}));

r.post('/servers/:id/files/upload', upload.array('files', 200), wrap(async (req, res) => {
  const srv = S(req);
  const dir = safePath(srv, req.query.path);
  fs.mkdirSync(dir, { recursive: true });
  const added = [];
  for (const f of req.files || []) {
    const name = content.safeName(Buffer.from(f.originalname, 'latin1').toString('utf8'));
    fs.copyFileSync(f.path, path.join(dir, name));
    fs.rmSync(f.path, { force: true });
    added.push(name);
  }
  res.json({ added });
}));

r.post('/servers/:id/files/mkdir', wrap(async (req, res) => {
  fs.mkdirSync(safePath(S(req), (req.body || {}).path), { recursive: true });
  res.json({ ok: true });
}));

r.post('/servers/:id/files/rename', wrap(async (req, res) => {
  const srv = S(req);
  const { from, to } = req.body || {};
  fs.renameSync(safePath(srv, from), safePath(srv, to));
  res.json({ ok: true });
}));

r.post('/servers/:id/files/delete', wrap(async (req, res) => {
  const srv = S(req);
  for (const p of (req.body || {}).paths || []) {
    const full = safePath(srv, p);
    if (full === path.resolve(srv.dir)) throw bad('You can\'t delete the whole server here.');
    fs.rmSync(full, { recursive: true, force: true });
  }
  res.json({ ok: true });
}));

r.get('/servers/:id/files/download', wrap(async (req, res) => {
  const full = safePath(S(req), req.query.path);
  if (!fs.existsSync(full) || fs.statSync(full).isDirectory()) throw bad('Not a file.', 404);
  res.download(full);
}));

// ---- backups

r.get('/servers/:id/backups', (req, res) => {
  const srv = S(req);
  res.json({ backups: backups.list(srv), schedule: srv.meta.schedule || {} });
});

r.post('/servers/:id/backups', wrap(async (req, res) => {
  const srv = S(req);
  const note = String((req.body || {}).note || '').slice(0, 80);
  const id = tasks.run(`Backing up ${srv.meta.name}`, { serverId: srv.id, kind: 'backup' }, (task) =>
    backups.create(srv, { reason: 'manual', note, onProgress: (g, t) => task.progress({ stage: 'Zipping world', got: g, total: t }) }));
  res.json({ taskId: id });
}));

r.post('/servers/:id/backups/restore', wrap(async (req, res) => {
  const srv = S(req);
  const file = String((req.body || {}).file || '');
  if (!['offline', 'crashed'].includes(srv.status)) throw bad('Stop the server before restoring.');
  const id = tasks.run(`Restoring ${srv.meta.name}`, { serverId: srv.id, kind: 'restore' }, async (task) => {
    task.stage('Restoring files');
    await backups.restore(srv, file, { onProgress: (n) => task.progress({ stage: `Restoring files (${n})` }) });
    return { restored: file };
  });
  res.json({ taskId: id });
}));

r.post('/servers/:id/backups/upload', upload.array('files', 1), wrap(async (req, res) => {
  const srv = S(req);
  const f = (req.files || [])[0];
  if (!f) throw bad('Pick a backup .zip file.');
  try { res.json(await backups.importZip(srv, f.path, f.originalname)); } finally { fs.rmSync(f.path, { force: true }); }
}));

r.delete('/servers/:id/backups', (req, res) => { backups.remove(S(req), String(req.query.file || '')); res.json({ ok: true }); });

r.get('/servers/:id/backups/download', (req, res) => {
  const f = backups.filePath(S(req), String(req.query.file || ''));
  if (!f) return res.status(404).json({ error: 'Backup not found' });
  res.download(f);
});

module.exports = { router: r, VERSION };
