// PandA icon set: blocky line icons (square caps, right angles) + pixel-art bitmaps.
import { html } from '../lib/h.js';
import { hash } from '../lib/util.js';

const P = {
  grid: 'M4 4h7v7H4z M13 4h7v7h-7z M4 13h7v7H4z M13 13h7v7h-7z',
  server: 'M3 4h18v7H3z M3 13h18v7H3z M6 8h3 M6 17h3 M15 8h3 M15 17h3',
  plus: 'M12 5v14 M5 12h14',
  terminal: 'M3 4h18v16H3z M7 9l3 3-3 3 M12 15h5',
  users: 'M5 4h6v6H5z M2 20v-6h12v6 M15 6h5v5h-5 M16 14h6v6',
  user: 'M9 3h6v7H9z M5 21v-7h14v7',
  userPlus: 'M7 4h6v6H7z M3 20v-6h14v6 M20 6v6 M17 9h6',
  puzzle: 'M4 8h4V5h4v3h4v4h3v4h-3v4H4z',
  box: 'M12 3l8 4v10l-8 4-8-4V7z M4 7l8 4 8-4 M12 11v10',
  sliders: 'M4 6h9 M17 6h3 M13 4v4 M4 12h3 M11 12h9 M7 10v4 M4 18h11 M19 18h1 M15 16v4',
  list: 'M4 5h3v3H4z M10 6h10 M4 11h3v3H4z M10 12h10 M4 17h3v3H4z M10 18h10',
  crown: 'M3 19h18 M4 7l4 5 4-7 4 7 4-5-1 9H5z',
  folder: 'M3 5h7l2 2h9v13H3z',
  file: 'M5 3h9l5 5v13H5z M14 3v5h5',
  archive: 'M3 4h18v5H3z M5 9v11h14V9 M10 13h4',
  gear: 'M10 2h4v3h-4z M10 19h4v3h-4z M2 10h3v4H2z M19 10h3v4h-3z M7 7h10v10H7z M10 10h4v4h-4z M5 5l2 2 M17 17l2 2 M19 5l-2 2 M5 19l2-2',
  network: 'M10 3h4v4h-4z M3 17h4v4H3z M17 17h4v4h-4z M12 7v5 M5 17v-5h14v5',
  wifi: 'M11 18h2v2h-2z M8 15l4-3 4 3 M5 12l7-5 7 5 M2 9l10-7 10 7',
  power: 'M12 2v9 M7 5L4 8v7l4 5h8l4-5V8l-3-3',
  play: 'M7 4l12 8-12 8z',
  stop: 'M6 6h12v12H6z',
  restart: 'M4 12V7h12 M13 4l3 3-3 3 M20 12v5H8 M11 20l-3-3 3-3',
  copy: 'M8 8h12v12H8z M4 16V4h12',
  check: 'M4 12l5 5L20 6',
  x: 'M6 6l12 12 M18 6L6 18',
  warn: 'M12 3l10 18H2z M12 10v5 M12 17v2',
  info: 'M3 3h18v18H3z M12 10v7 M12 6v2',
  search: 'M4 4h11v11H4z M15 15l5 5',
  download: 'M12 3v12 M7 10l5 5 5-5 M4 20h16',
  upload: 'M12 16V4 M7 9l5-5 5 5 M4 20h16',
  trash: 'M4 6h16 M9 6V3h6v3 M6 6l1 15h10l1-15 M10 10v7 M14 10v7',
  edit: 'M4 20h4L20 8l-4-4L4 16z M14 6l4 4',
  eye: 'M2 12l5-6h10l5 6-5 6H7z M10 10h4v4h-4z',
  external: 'M14 4h6v6 M20 4l-9 9 M18 14v6H4V6h6',
  chat: 'M3 4h18v12H9l-5 4v-4H3z',
  bolt: 'M13 2L5 14h6l-1 8 8-12h-6z',
  cpu: 'M6 6h12v12H6z M9 9h6v6H9z M9 2v4 M15 2v4 M9 18v4 M15 18v4 M2 9h4 M2 15h4 M18 9h4 M18 15h4',
  ram: 'M2 7h20v9H2z M5 10h2v3H5z M9 10h2v3H9z M13 10h2v3h-2z M17 10h2v3h-2z M5 16v3 M19 16v3',
  disk: 'M3 4h18v16H3z M3 14h18 M16 17h2',
  bell: 'M6 17V9l3-4h6l3 4v8 M4 17h16 M10 20h4',
  menu: 'M4 6h16 M4 12h16 M4 18h16',
  chevR: 'M9 5l7 7-7 7',
  chevL: 'M15 5l-7 7 7 7',
  chevD: 'M5 9l7 7 7-7',
  chevU: 'M5 15l7-7 7 7',
  clock: 'M3 3h18v18H3z M12 7v5h4',
  tunnel: 'M2 20V8l4-4h12l4 4v12 M7 20v-9l2-2h6l2 2v9',
  key: 'M3 9h7v7H3z M10 12h11 M17 12v4 M21 12v5',
  wrench: 'M15 3h5v5l-3 3-2-2-8 8v3H4l-1-1v-3h3l8-8-2-2z',
  chain: 'M10 7H4v10h6 M14 7h6v10h-6 M8 12h8',
  logout: 'M10 4H4v16h6 M15 8l4 4-4 4 M19 12H9',
  lock: 'M5 11h14v10H5z M8 11V7l2-2h4l2 2v4',
  phone: 'M7 2h10v20H7z M11 18h2',
  sun: 'M9 9h6v6H9z M12 2v4 M12 18v4 M2 12h4 M18 12h4 M5 5l2 2 M17 17l2 2 M19 5l-2 2 M5 19l2-2',
  moon: 'M14 3H9L5 7v10l4 4h8l4-4v-3h-6l-3-3V6z',
  rain: 'M5 15h14v-5l-3-3h-3l-2-2H8L5 8z M8 18l-1 3 M12 18l-1 3 M16 18l-1 3',
  save: 'M4 4h13l3 3v13H4z M8 4v5h7V4 M8 20v-6h8v6',
  megaphone: 'M3 10h4l10-5v14L7 14H3z M7 14l2 6h3l-1-6',
  ban: 'M5 5h14v14H5z M5 5l14 14',
  checkSq: 'M4 4h16v16H4z M8 12l3 3 5-6',
  layers: 'M12 3l9 5-9 5-9-5z M3 12l9 5 9-5 M3 16l9 5 9-5',
  gamepad: 'M2 8h20v10h-6l-2-2h-4l-2 2H2z M6 11v4 M4 13h4 M15 12h2 M18 14h2',
  coffee: 'M4 9h12v7l-2 3H6l-2-3z M16 10h3v4h-3 M7 3v3 M11 3v3',
  star: 'M12 2l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z',
  filter: 'M3 4h18l-7 8v8l-4-2v-6z',
  heart: 'M12 20L3 11V6l3-3h4l2 2 2-2h4l3 3v5z',
  globe: 'M3 3h18v18H3z M3 12h18 M12 3v18 M7 3v18 M17 3v18',
  link: 'M10 14l4-4 M8 10l-3 3v4l2 2h4l3-3 M16 14l3-3V7l-2-2h-4l-3 3',
  leaf: 'M4 20L20 4 M20 4v8l-4 4h-6 M20 4h-8l-4 4v6',
  sparkle: 'M12 2v6 M12 16v6 M2 12h6 M16 12h6 M7 7l2 2 M15 15l2 2 M17 7l-2 2 M7 17l2-2',
  more: 'M4 10h4v4H4z M10 10h4v4h-4z M16 10h4v4h-4z',
  pin: 'M8 3h8v7l3 3v2H5v-2l3-3z M12 15v6',
  qr: 'M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h3v3h-3z M18 18h3v3h-3z M6 6h1v1H6z M17 6h1v1h-1z M6 17h1v1H6z',
  pickaxe: 'M3 6l3-3h9l6 6v4l-2-1-4-4H9 M13 8L3 21',
  skull: 'M5 3h14v12h-3v4H8v-4H5z M8 8h3v3H8z M13 8h3v3h-3z',
  swords: 'M3 3l11 11 M3 3h5 M3 3v5 M21 3L10 14 M21 3h-5 M21 3v5 M6 18l-3 3 M18 18l3 3',
  dot: 'M10 10h4v4h-4z',
};

const FILLED = new Set(['play', 'stop', 'more', 'dot']);

export function Icon({ name, size = 18, class: c = '', title }) {
  const d = P[name] || P.dot;
  const filled = FILLED.has(name);
  return html`<svg class=${`ic ${c}`} width=${size} height=${size} viewBox="0 0 24 24" fill=${filled ? 'currentColor' : 'none'} stroke=${filled ? 'none' : 'currentColor'} stroke-width="2" stroke-linecap="square" stroke-linejoin="miter" aria-hidden=${title ? undefined : 'true'} role=${title ? 'img' : undefined}>${title ? html`<title>${title}</title>` : null}<path d=${d} /></svg>`;
}

// ---------------------------------------------------------------- pixel art

const PAL = {
  k: '#0b0d0b', w: '#f4f7f2', s: '#c4ccc1', p: '#ff6fae', P: '#d8417f', g: '#8df35b', d: '#4fae2d', D: '#2c6a17',
  b: '#7a5233', n: '#5c3b22', o: '#f08a4b', O: '#b85a24', a: '#6f7b82', A: '#9aa7ad', y: '#ffcf5a', Y: '#c99a2a',
  u: '#d58fe6', U: '#9a5bb0', t: '#e3d6b4', T: '#b1a17b', r: '#ff4d63', c: '#9fd6ff',
};

const ART = {
  panda: [
    '.kk........kk.',
    'kkkk......kkkk',
    'kkkkwwwwwwkkkk',
    '.kkwwwwwwwwkk.',
    '.wwwwwwwwwwww.',
    'wwkkkwwwwkkkww',
    'wwkwkkwwkkwkww',
    'wwkkkwwwwkkkww',
    'wwwwwwkkwwwwww',
    'wppwwwwwwwwppw',
    '.wwwwkwwkwwww.',
    '..wwwwkkwwww..',
    '...wwwwwwww...',
  ],
  sleepy: [
    '.kk........kk.',
    'kkkk......kkkk',
    'kkkkwwwwwwkkkk',
    '.kkwwwwwwwwkk.',
    '.wwwwwwwwwwww.',
    'wwwwwwwwwwwwww',
    'wwkkkwwwwkkkww',
    'wwwkkwwwwkkwww',
    'wwwwwwkkwwwwww',
    'wppwwwwwwwwppw',
    '.wwwwwwwwwwww.',
    '..wwwwkkwwww..',
    '...wwwwwwww...',
  ],
  vanilla: [
    'gggggggggggg',
    'ggdggggdgggg',
    'gggggdggggdg',
    'gdgggggggggg',
    'bgbbgbbbgbbg',
    'bbbbbnbbbbbb',
    'bnbbbbbbnbbb',
    'bbbbbbbbbbbb',
    'bbbnbbbbbbnb',
    'bbbbbbnbbbbb',
    'bnbbbbbbbbbb',
    'bbbbbbbbnbbb',
  ],
  paper: [
    '..........ww',
    '........wwww',
    '......wwwwsw',
    '....wwwwwsw.',
    '..wwwwwwssw.',
    'wwwwwwwsww..',
    '..wwwwssw...',
    '....wssw....',
    '....wsw.....',
    '.....w......',
  ],
  purpur: [
    'uuuuuuuuuuuu',
    'uUUUUUUUUUUu',
    'uUuuuuuuuuUu',
    'uUuUUUUUUuUu',
    'uUuUuuuuUuUu',
    'uUuUuUUuUuUu',
    'uUuUuUUuUuUu',
    'uUuUuuuuUuUu',
    'uUuUUUUUUuUu',
    'uUuuuuuuuuUu',
    'uUUUUUUUUUUu',
    'uuuuuuuuuuuu',
  ],
  fabric: [
    '.tttttttttt.',
    'tTTttTTttTTt',
    'tTTttTTttTTt',
    'ttttTTttTTtt',
    'ttttTTttTTtt',
    'tTTttTTttTTt',
    'tTTttTTttTTt',
    'ttttTTttTTtt',
    'ttttTTttTTtt',
    'tTTttTTttTTt',
    'tTTttTTttTTt',
    '.tttttttttt.',
  ],
  forge: [
    '............',
    '.AAAAAAAAAA.',
    'aaaaaaaaaaaa',
    '.aaaaaaaaaa.',
    '...aaaaaa...',
    '....aaaa....',
    '....aaaa....',
    '...aaaaaa...',
    '..aaaaaaaa..',
    '..aaaaaaaa..',
  ],
  neoforge: [
    '............',
    '.oooooooooo.',
    'OOOOOOOOOOOO',
    '.OOOOOOOOOO.',
    '...OOOOOO...',
    '....OOOO....',
    '....OOOO....',
    '...OOOOOO...',
    '..OOOOOOOO..',
    '..OOOOOOOO..',
  ],
  modpack: [
    '.bbbbbbbbbb.',
    'bnnnnnnnnnnb',
    'bnbbbbbbbbnb',
    'bnbbbbbbbbnb',
    'bnnnnyynnnnb',
    'bnbbbyybbbnb',
    'bnbbbbbbbbnb',
    'bnbbbbbbbbnb',
    'bnnnnnnnnnnb',
    '.bbbbbbbbbb.',
  ],
  steve: [
    'nnnnnnnn',
    'nnnnnnnn',
    'nbbbbbbn',
    'bbbbbbbb',
    'bwcbbcwb',
    'bbbnnbbb',
    'bbnbbnbb',
    'bbnnnnbb',
  ],
  heart: [
    '.rr.rr.',
    'rrrrrrr',
    'rrrrrrr',
    '.rrrrr.',
    '..rrr..',
    '...r...',
  ],
};

// Merges horizontal runs into wider rects so the SVG stays light.
function rects(rows) {
  const out = [];
  rows.forEach((row, y) => {
    let x = 0;
    while (x < row.length) {
      const c = row[x];
      if (c === '.') { x++; continue; }
      let w = 1;
      while (row[x + w] === c) w++;
      out.push({ x, y, w, c });
      x += w;
    }
  });
  return out;
}

const cache = new Map();
export function Pixel({ art, size = 48, class: c = '' }) {
  const rows = ART[art] || ART.panda;
  const key = art;
  if (!cache.has(key)) cache.set(key, rects(rows));
  const w = Math.max(...rows.map((r) => r.length));
  const h = rows.length;
  return html`<svg class=${`px ${c}`} width=${size} height=${Math.round((size * h) / w)} viewBox=${`0 0 ${w} ${h}`} shape-rendering="crispEdges" aria-hidden="true">
    ${cache.get(key).map((r) => html`<rect x=${r.x} y=${r.y} width=${r.w} height="1" fill=${PAL[r.c] || '#f0f'} />`)}
  </svg>`;
}

// Deterministic 5x5 symmetric "identicon" for servers without a custom icon.
export function Identicon({ seed, size = 52, accent = 'green' }) {
  const h = hash(String(seed));
  const main = accent === 'pink' ? '#ff6fae' : '#8df35b';
  const alt = accent === 'pink' ? '#8df35b' : '#ff6fae';
  const cells = [];
  for (let y = 0; y < 5; y++) {
    for (let x = 0; x < 3; x++) {
      const bit = (h >> (y * 3 + x)) & 1;
      if (!bit) continue;
      const fill = ((h >> (16 + ((y + x) % 8))) & 1) && y === 2 ? alt : main;
      cells.push({ x, y, fill });
      if (x < 2) cells.push({ x: 4 - x, y, fill });
    }
  }
  return html`<svg class="px" width=${size} height=${size} viewBox="-1 -1 7 7" shape-rendering="crispEdges" aria-hidden="true">
    ${cells.map((c) => html`<rect x=${c.x} y=${c.y} width="1" height="1" fill=${c.fill} />`)}
  </svg>`;
}

export const TYPE_ART = { vanilla: 'vanilla', paper: 'paper', purpur: 'purpur', fabric: 'fabric', forge: 'forge', neoforge: 'neoforge', modpack: 'modpack', pending: 'modpack' };
