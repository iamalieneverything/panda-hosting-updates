// PandA UI kit: buttons, toggles, tooltips, modals, charts, dropzones…
import { html, useState, useEffect, useRef, useMemo, useCallback, useLayoutEffect } from '../lib/h.js';
import { cls, headUrl } from '../lib/util.js';
import { Icon, Identicon, Pixel, TYPE_ART } from './icons.js';
import { useStore, dismissToast } from '../lib/store.js';

export function Btn({ kind = '', size = '', icon, iconR, loading, children, class: c = '', ...rest }) {
  return html`<button type="button" ...${rest} class=${cls('btn', kind, size, !children && 'icon', c)} disabled=${rest.disabled || loading}>
    ${loading ? html`<${Icon} name="restart" size=${size === 'xs' ? 13 : 15} class="spin" />` : icon ? html`<${Icon} name=${icon} size=${size === 'xs' ? 13 : size === 'sm' ? 15 : 17} />` : null}
    ${children}
    ${iconR ? html`<${Icon} name=${iconR} size=${15} />` : null}
  </button>`;
}

export function Toggle({ checked, onChange, pink, disabled, label }) {
  return html`<label class=${cls('toggle', pink && 'pink')} title=${label}>
    <input type="checkbox" checked=${!!checked} disabled=${disabled} aria-label=${label} onChange=${(e) => onChange && onChange(e.currentTarget.checked)} />
    <span class="track"></span><span class="knob"></span>
  </label>`;
}

export function Seg({ options, value, onChange, pink, block, small }) {
  return html`<div class=${cls('seg', pink && 'pink', block && 'block')} role="radiogroup">
    ${options.map((o) => {
      const v = typeof o === 'object' ? o.value : o;
      const l = typeof o === 'object' ? o.label : o;
      return html`<button type="button" role="radio" aria-checked=${value === v} class=${cls(value === v && 'on')} style=${small ? 'height:26px;padding:0 9px;font-size:12px' : ''} onClick=${() => onChange(v)}>${l}</button>`;
    })}
  </div>`;
}

export function Check({ checked, onChange, children }) {
  return html`<label class="check"><input type="checkbox" checked=${!!checked} onChange=${(e) => onChange(e.currentTarget.checked)} /><span>${children}</span></label>`;
}

export function Field({ label, hint, tip, children, class: c = '' }) {
  return html`<div class=${cls('field', c)}>
    ${label ? html`<div class="lbl">${label}${tip ? html`<${Tip} text=${tip} />` : null}</div>` : null}
    ${children}
    ${hint ? html`<div class="hint">${hint}</div>` : null}
  </div>`;
}

export function Range({ value, min, max, step = 1, onInput, pink }) {
  const p = ((value - min) / (max - min)) * 100;
  return html`<input type="range" class=${cls('range', pink && 'pink')} min=${min} max=${max} step=${step} value=${value} style=${`--pct:${p}%`} onInput=${(e) => onInput(Number(e.currentTarget.value))} />`;
}

// ---------------------------------------------------------------- tooltip

export function Tip({ text, title, k }) {
  const ref = useRef();
  const [pos, setPos] = useState(null);
  const show = () => {
    const r = ref.current.getBoundingClientRect();
    const w = Math.min(320, window.innerWidth - 24);
    let left = r.left + r.width / 2 - w / 2;
    left = Math.max(12, Math.min(left, window.innerWidth - w - 12));
    const below = r.top < 160;
    setPos({ left, top: below ? r.bottom + 10 : r.top - 10, below, w });
  };
  const hide = () => setPos(null);
  return html`<span style="display:inline-flex">
    <button type="button" class="tip-btn" ref=${ref} aria-label=${`Help: ${text}`} onMouseEnter=${show} onMouseLeave=${hide} onFocus=${show} onBlur=${hide} onClick=${(e) => { e.preventDefault(); e.stopPropagation(); pos ? hide() : show(); }}>?</button>
    ${pos ? html`<div class="tooltip" role="tooltip" style=${`left:${pos.left}px;top:${pos.top}px;width:${pos.w}px;transform:${pos.below ? 'none' : 'translateY(-100%)'}`}>${title ? html`<b>${title}</b>` : null}${text}${k ? html`<span class="k">${k}</span>` : null}</div>` : null}
  </span>`;
}

// ---------------------------------------------------------------- modal + dialogs

export function Modal({ title, onClose, children, footer, size = '', icon }) {
  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape' && onClose) onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  return html`<div class="overlay" onMouseDown=${(e) => { if (e.target === e.currentTarget && onClose) onClose(); }}>
    <div class=${cls('modal', size)} role="dialog" aria-modal="true" aria-label=${title}>
      <div class="modal-h"><h2 class="row">${icon ? html`<${Icon} name=${icon} size=${18} />` : null}${title}</h2>${onClose ? html`<${Btn} kind="ghost" size="sm" icon="x" aria-label="Close" onClick=${onClose} />` : null}</div>
      <div class="modal-b">${children}</div>
      ${footer ? html`<div class="modal-f">${footer}</div>` : null}
    </div>
  </div>`;
}

let dialogSet = null;
export function DialogHost() {
  const [d, setD] = useState(null);
  dialogSet = setD;
  if (!d) return null;
  const close = (v) => { setD(null); d.resolve(v); };
  return html`<${DialogView} d=${d} close=${close} />`;
}

function DialogView({ d, close }) {
  const [val, setVal] = useState(d.value || '');
  const ok = () => {
    if (d.kind === 'prompt') return close(val);
    if (d.typeToConfirm && val !== d.typeToConfirm) return;
    close(true);
  };
  return html`<${Modal} title=${d.title} icon=${d.danger ? 'warn' : d.icon} onClose=${() => close(d.kind === 'prompt' ? null : false)}
    footer=${html`<${Btn} kind="ghost" onClick=${() => close(d.kind === 'prompt' ? null : false)}>${d.cancel || 'Cancel'}<//><${Btn} kind=${d.danger ? 'danger solid' : 'g'} disabled=${d.typeToConfirm && val !== d.typeToConfirm} onClick=${ok}>${d.ok || 'OK'}<//>`}>
    ${d.body ? html`<p class="dim" style="margin-bottom:${d.kind === 'prompt' || d.typeToConfirm ? '14px' : 0}">${d.body}</p>` : null}
    ${d.kind === 'prompt' || d.typeToConfirm ? html`<input class="input" autofocus value=${val} placeholder=${d.placeholder || d.typeToConfirm || ''} onInput=${(e) => setVal(e.currentTarget.value)} onKeyDown=${(e) => e.key === 'Enter' && ok()} />` : null}
    ${d.typeToConfirm ? html`<div class="hint mt-8">Type <b class="mono">${d.typeToConfirm}</b> to confirm.</div>` : null}
  <//>`;
}

export const confirm = (opts) => new Promise((resolve) => dialogSet && dialogSet({ kind: 'confirm', ...opts, resolve }));
export const prompt = (opts) => new Promise((resolve) => dialogSet && dialogSet({ kind: 'prompt', ...opts, resolve }));

// ---------------------------------------------------------------- toasts

export function Toasts() {
  const toasts = useStore((s) => s.toasts);
  const icons = { success: 'check', error: 'warn', info: 'info', warn: 'warn' };
  return html`<div class="toasts" aria-live="polite">
    ${toasts.map((t) => html`<div class=${cls('toast', t.level)} key=${t.id} onClick=${() => dismissToast(t.id)}>
      <span class="ti"><${Icon} name=${icons[t.level] || 'info'} size=${18} /></span>
      <div class="grow"><div class="tt">${t.title}</div>${t.body ? html`<div class="tb">${t.body}</div>` : null}</div>
    </div>`)}
  </div>`;
}

// ---------------------------------------------------------------- small bits

export function Bar({ value, busy, pink, thin, warn, bad }) {
  return html`<div class=${cls('bar', busy && 'busy', pink && 'pink', thin && 'thin', warn && 'warn', bad && 'bad')}><i style=${`--v:${Math.round((value || 0) * 100)}%`}></i></div>`;
}

export function Empty({ art = 'sleepy', title, children, action }) {
  return html`<div class="empty">
    <div class="art"><${Pixel} art=${art} size=${54} /></div>
    ${title ? html`<div class="et">${title}</div>` : null}
    ${children ? html`<div style="max-width:440px">${children}</div>` : null}
    ${action || null}
  </div>`;
}

export function Status({ status }) {
  const label = { online: 'Online', offline: 'Offline', starting: 'Starting', stopping: 'Stopping', crashed: 'Crashed', installing: 'Installing' }[status] || status;
  const k = { online: 'g', crashed: 'r', starting: 'a', stopping: 'a', installing: 'a' }[status] || 'k';
  return html`<span class="row gap-6"><span class=${cls('sq', status)}></span><span class=${`stamp ${k}`}>${label}</span></span>`;
}

export function ServerAvatar({ server, size = 52, lg }) {
  const [broken, setBroken] = useState(false);
  const [bust] = useState(() => Date.now());
  const accent = server.accent || 'green';
  return html`<div class=${cls('srv-avatar', lg && 'lg')} style=${`width:${size}px;height:${size}px`}>
    ${server.hasIcon && !broken
      ? html`<img src=${`/api/servers/${server.id}/icon?v=${bust}`} alt="" onError=${() => setBroken(true)} />`
      : html`<${Identicon} seed=${server.id} size=${size - 10} accent=${accent} />`}
  </div>`;
}

// Remote image (mod/pack icon) that falls back to a pixel icon when it can't load.
export function Img({ src, fallback = 'puzzle', size = 20 }) {
  const [broken, setBroken] = useState(false);
  useEffect(() => setBroken(false), [src]);
  if (!src || broken) return html`<${Icon} name=${fallback} size=${size} />`;
  return html`<img src=${src} alt="" loading="lazy" onError=${() => setBroken(true)} />`;
}

export function TypeIcon({ type, size = 22 }) {
  return html`<${Pixel} art=${TYPE_ART[type] || 'vanilla'} size=${size} />`;
}

export function Head({ name, size = 36, class: c = '' }) {
  const [broken, setBroken] = useState(false);
  if (broken || !name) return html`<span class=${cls('head', c)} style=${`width:${size}px;height:${size}px;display:inline-grid;place-items:center`}><${Pixel} art="steve" size=${size} /></span>`;
  return html`<img class=${cls('head', c)} width=${size} height=${size} src=${headUrl(name, 64)} alt="" loading="lazy" onError=${() => setBroken(true)} />`;
}

// ---------------------------------------------------------------- charts

// Block sparkline (bars) used in the header.
export function Spark({ data, max = 100, color = 'var(--bamboo)', w = 64, h = 24, n = 32 }) {
  const pts = data.slice(-n);
  const bw = w / n;
  return html`<svg class="spark" width=${w} height=${h} viewBox=${`0 0 ${w} ${h}`} shape-rendering="crispEdges" aria-hidden="true">
    ${Array.from({ length: n }).map((_, i) => {
      const v = pts[i - (n - pts.length)];
      if (v == null) return html`<rect x=${i * bw} y=${h - 1} width=${Math.max(1, bw - 1)} height="1" fill="#2f362f" />`;
      const bh = Math.max(1, Math.round((Math.min(v, max) / max) * h));
      return html`<rect x=${i * bw} y=${h - bh} width=${Math.max(1, bw - 1)} height=${bh} fill=${color} opacity=${0.45 + (0.55 * i) / n} />`;
    })}
  </svg>`;
}

// Stepped area chart for history (CPU / RAM).
export function AreaChart({ series, max = 100, h = 90, labels = true, unit = '%', fmt }) {
  const ref = useRef();
  const [w, setW] = useState(300);
  useLayoutEffect(() => {
    if (!ref.current) return;
    const ro = new ResizeObserver((e) => setW(Math.max(120, Math.floor(e[0].contentRect.width))));
    ro.observe(ref.current);
    return () => ro.disconnect();
  }, []);
  const n = Math.max(...series.map((s) => s.data.length), 2);
  const x = (i) => Math.round((i / (n - 1)) * (w - 1));
  const y = (v) => Math.round(h - 1 - (Math.min(v, max) / max) * (h - 6));
  const path = (data) => {
    if (!data.length) return '';
    const off = n - data.length;
    let d = `M${x(off)} ${y(data[0])}`;
    for (let i = 1; i < data.length; i++) d += `H${x(off + i)}V${y(data[i])}`;
    return d;
  };
  const f = fmt || ((v) => `${Math.round(v)}${unit}`);
  return html`<div ref=${ref} style="position:relative;width:100%">
    <svg width=${w} height=${h} viewBox=${`0 0 ${w} ${h}`} style="display:block" aria-hidden="true">
      ${[0.25, 0.5, 0.75].map((g) => html`<line x1="0" x2=${w} y1=${Math.round(h * g) + 0.5} y2=${Math.round(h * g) + 0.5} stroke="#1f241f" stroke-dasharray="2 4" />`)}
      ${series.map((s) => {
        const d = path(s.data);
        if (!d) return null;
        const off = n - s.data.length;
        return html`<g>
          <path d=${`${d}V${h}H${x(off)}Z`} fill=${s.color} opacity="0.12" />
          <path d=${d} fill="none" stroke=${s.color} stroke-width="2" shape-rendering="crispEdges" />
        </g>`;
      })}
    </svg>
    ${labels ? html`<div class="row between tiny muted mono" style="margin-top:4px"><span>${Math.round((n * 2) / 60)} min ago</span><span>${series.map((s) => (s.data.length ? html`<span style=${`color:${s.color};margin-left:10px`}>${f(s.data[s.data.length - 1])}</span>` : null))}</span></div>` : null}
  </div>`;
}

// ---------------------------------------------------------------- drag & drop

export function Dropzone({ onFiles, accept, title = 'Drop files here', sub, icon = 'upload' }) {
  const [over, setOver] = useState(false);
  const input = useRef();
  const pick = (list) => {
    const files = [...list].filter((f) => !accept || accept.split(',').some((a) => f.name.toLowerCase().endsWith(a.trim())));
    if (files.length) onFiles(files);
  };
  return html`<div class=${cls('dropzone', over && 'over')} role="button" tabindex="0"
    onClick=${() => input.current.click()}
    onKeyDown=${(e) => (e.key === 'Enter' || e.key === ' ') && input.current.click()}
    onDragOver=${(e) => { e.preventDefault(); e.stopPropagation(); setOver(true); }}
    onDragLeave=${() => setOver(false)}
    onDrop=${(e) => { e.preventDefault(); e.stopPropagation(); setOver(false); pick(e.dataTransfer.files); }}>
    <div class="dz-ic"><${Icon} name=${icon} size=${22} /></div>
    <div style="font-weight:700">${title}</div>
    ${sub ? html`<div class="small muted">${sub}</div>` : null}
    <input ref=${input} type="file" multiple accept=${accept} class="hide" onChange=${(e) => { pick(e.currentTarget.files); e.currentTarget.value = ''; }} />
  </div>`;
}

// Whole-window drop target with a pink veil.
export function useWindowDrop(onFiles, accept, enabled = true) {
  const [over, setOver] = useState(false);
  const cb = useRef(onFiles);
  cb.current = onFiles;
  useEffect(() => {
    if (!enabled) return;
    let depth = 0;
    const isFiles = (e) => e.dataTransfer && [...(e.dataTransfer.types || [])].includes('Files');
    const enter = (e) => { if (!isFiles(e)) return; depth++; setOver(true); };
    const leave = (e) => { if (!isFiles(e)) return; depth = Math.max(0, depth - 1); if (!depth) setOver(false); };
    const overH = (e) => { if (isFiles(e)) e.preventDefault(); };
    const drop = (e) => {
      if (!isFiles(e)) return;
      e.preventDefault();
      depth = 0; setOver(false);
      const files = [...e.dataTransfer.files].filter((f) => !accept || accept.split(',').some((a) => f.name.toLowerCase().endsWith(a.trim())));
      if (files.length) cb.current(files);
    };
    window.addEventListener('dragenter', enter);
    window.addEventListener('dragleave', leave);
    window.addEventListener('dragover', overH);
    window.addEventListener('drop', drop);
    return () => { window.removeEventListener('dragenter', enter); window.removeEventListener('dragleave', leave); window.removeEventListener('dragover', overH); window.removeEventListener('drop', drop); };
  }, [enabled, accept]);
  return over;
}

export function DropVeil({ text }) {
  return html`<div class="drop-veil"><div>${text}</div></div>`;
}

// ---------------------------------------------------------------- searchable picker

export function Picker({ items, value, onChange, placeholder = 'Search…', render, mono = true }) {
  const [open, setOpen] = useState(false);
  const [qv, setQ] = useState('');
  const [act, setAct] = useState(0);
  const wrap = useRef();
  const list = useMemo(() => {
    const ql = qv.trim().toLowerCase();
    return (ql ? items.filter((i) => String(i.label || i.id).toLowerCase().includes(ql)) : items).slice(0, 200);
  }, [items, qv]);
  useEffect(() => {
    const close = (e) => { if (wrap.current && !wrap.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, []);
  const sel = items.find((i) => i.id === value);
  const choose = (i) => { onChange(i.id); setOpen(false); setQ(''); };
  return html`<div class="picker" ref=${wrap}>
    <div class="input-wrap">
      <span class="ic-l"><${Icon} name="search" size=${15} /></span>
      <input class=${cls('input', mono && 'mono')} value=${open ? qv : (sel ? sel.label || sel.id : '')} placeholder=${placeholder}
        onFocus=${() => { setOpen(true); setQ(''); setAct(0); }}
        onInput=${(e) => { setQ(e.currentTarget.value); setOpen(true); setAct(0); }}
        onKeyDown=${(e) => {
          if (e.key === 'ArrowDown') { e.preventDefault(); setAct((a) => Math.min(a + 1, list.length - 1)); }
          if (e.key === 'ArrowUp') { e.preventDefault(); setAct((a) => Math.max(a - 1, 0)); }
          if (e.key === 'Enter' && list[act]) { e.preventDefault(); choose(list[act]); e.currentTarget.blur(); }
          if (e.key === 'Escape') { setOpen(false); e.currentTarget.blur(); }
        }} />
      <span class="suffix" style="pointer-events:none"><${Icon} name="chevD" size=${14} /></span>
    </div>
    ${open ? html`<div class="picker-list">
      ${list.length ? list.map((i, idx) => html`<button type="button" class=${cls(idx === act && 'act', i.id === value && 'sel')} onMouseDown=${(e) => { e.preventDefault(); choose(i); }}>${render ? render(i) : html`<span>${i.label || i.id}</span>${i.tag ? html`<span class="chip sm">${i.tag}</span>` : null}`}</button>`) : html`<div class="small muted" style="padding:12px">Nothing matches “${qv}”.</div>`}
    </div>` : null}
  </div>`;
}

export function useInterval(fn, ms) {
  const cb = useRef(fn);
  cb.current = fn;
  useEffect(() => { const t = setInterval(() => cb.current(), ms); return () => clearInterval(t); }, [ms]);
}

export function useAsync(fn, deps = []) {
  const [st, setSt] = useState({ loading: true, data: null, error: null });
  const run = useCallback(async () => {
    setSt((s) => ({ ...s, loading: true }));
    try { const data = await fn(); setSt({ loading: false, data, error: null }); return data; } catch (error) { setSt({ loading: false, data: null, error }); return null; }
  }, deps);
  useEffect(() => { run(); }, [run]);
  return { ...st, reload: run, set: (data) => setSt((s) => ({ ...s, data: typeof data === 'function' ? data(s.data) : data })) };
}

export function Loading({ text = 'Loading…' }) {
  return html`<div class="row" style="padding:30px;justify-content:center;color:var(--text-3)"><${Icon} name="restart" class="spin" size=${18} /> ${text}</div>`;
}

export function ErrorBox({ error, retry }) {
  if (!error) return null;
  return html`<div class="alert error"><span class="ai"><${Icon} name="warn" /></span><div class="grow"><div class="at">Something went wrong</div><div class="ab">${error.message || String(error)}</div></div>${retry ? html`<${Btn} size="sm" icon="restart" onClick=${retry}>Retry<//>` : null}</div>`;
}
