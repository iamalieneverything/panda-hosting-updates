// Logo pieces.
import { html } from '../lib/h.js';
import { Pixel } from './icons.js';

export function BrandTile({ size = 44, art = 'panda' }) {
  return html`<span class="brand-tile" style=${`width:${size}px;height:${size}px`}><${Pixel} art=${art} size=${Math.round(size * 0.68)} /></span>`;
}

export function Wordmark({ size = 21 }) {
  return html`<span class="wordmark" style=${`font-size:${size}px`}><span class="p">P</span>and<span class="a">A</span></span>`;
}

export function go(to) { location.hash = to.startsWith('#') ? to : `#${to}`; }
