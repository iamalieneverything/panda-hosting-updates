// New server wizard: flavour → version (or modpack) → make it yours → create.
import { html, useState, useEffect, useMemo } from '../lib/h.js';
import { api } from '../lib/api.js';
import { useStore, waitTask, refreshServers } from '../lib/store.js';
import { cls, gb, motdParts } from '../lib/util.js';
import { Icon, Pixel, Identicon } from '../ui/icons.js';
import { Btn, Field, Toggle, Range, Check, Bar, Seg, Picker, Tip, Loading } from '../ui/kit.js';
import { Browser } from './browse.js';
import { go } from '../ui/brand.js';

const FLAVORS = [
  { type: 'paper', title: 'Paper', art: 'paper', d: 'Fast vanilla gameplay with plugins (EssentialsX, WorldEdit, LuckPerms…). The best pick for most friend servers.', tags: ['Plugins', 'Fast'], rec: true },
  { type: 'vanilla', title: 'Vanilla', art: 'vanilla', d: 'Pure Minecraft exactly as Mojang made it. Datapacks still work.', tags: ['Datapacks'] },
  { type: 'purpur', title: 'Purpur', art: 'purpur', d: 'Paper with hundreds of extra settings, like rideable mobs and tweakable gameplay.', tags: ['Plugins', 'Extra knobs'] },
  { type: 'fabric', title: 'Fabric', art: 'fabric', d: 'Lightweight mod loader. Great for performance mods, Create Fabric, Cobblemon and more.', tags: ['Mods', 'Light'] },
  { type: 'neoforge', title: 'NeoForge', art: 'neoforge', d: 'The modern home of big Forge mods (1.20.2 and newer). Most new modpacks use it.', tags: ['Mods', 'Big packs'] },
  { type: 'forge', title: 'Forge', art: 'forge', d: 'The classic mod loader. Use it for older modpacks like 1.12.2 or 1.20.1.', tags: ['Mods', 'Classic'] },
  { type: 'modpack', title: 'Modpack', art: 'modpack', d: 'One click: All the Mods, Cobblemon, Prominence, Better MC… PandA installs everything.', tags: ['Modrinth', 'CurseForge'], pack: true },
];

const STEP_NAMES = ['Flavour', 'Version', 'Make it yours', 'Create'];

function MotdPreview({ name, motd, players, max, icon, id, accent }) {
  return html`<div class="motd-preview">
    ${icon ? html`<img class="icon" src=${icon} alt="" />` : html`<div class="icon" style="display:grid;place-items:center"><${Identicon} seed=${id} size=${40} accent=${accent} /></div>`}
    <div class="grow" style="min-width:0">
      <div class="sn">${name || 'My Server'}</div>
      <div class="sm">${motdParts(motd).map((p) => html`<span style=${`color:${p.color};${p.bold ? 'font-weight:700;' : ''}${p.italic ? 'font-style:italic;' : ''}${p.underline ? 'text-decoration:underline;' : ''}`}>${p.text}</span>`)}</div>
    </div>
    <div class="sp">${players}/${max}</div>
  </div>`;
}

async function resizeIcon(file) {
  const img = await new Promise((resolve, reject) => {
    const i = new Image();
    i.onload = () => resolve(i);
    i.onerror = reject;
    i.src = URL.createObjectURL(file);
  });
  const c = document.createElement('canvas');
  c.width = 64; c.height = 64;
  const ctx = c.getContext('2d');
  ctx.imageSmoothingEnabled = img.width > 64;
  const s = Math.min(img.width, img.height);
  ctx.drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, 64, 64);
  return c.toDataURL('image/png');
}

export function CreateServer({ query }) {
  const info = useStore((s) => s.info);
  const total = info ? Math.floor(info.info.memTotal / 1048576) : 8192;
  const [step, setStep] = useState(query && query.type ? 1 : 0);
  const [type, setType] = useState(query && query.type ? query.type : null);
  const [versions, setVersions] = useState(null);
  const [snapshots, setSnapshots] = useState(false);
  const [mc, setMc] = useState('');
  const [loaders, setLoaders] = useState([]);
  const [loader, setLoader] = useState('');
  const [showAdv, setShowAdv] = useState(false);
  const [pack, setPack] = useState(null);
  const [seedId] = useState(() => Math.random().toString(36).slice(2));
  const [form, setForm] = useState({
    name: '', motd: '', memoryMb: 4096, maxPlayers: 10, gamemode: 'survival', difficulty: 'normal',
    bedrock: false, whitelist: false, onlineMode: true, pvp: true, hardcore: false, seed: '', levelType: 'minecraft:normal',
    owner: '', accent: Math.random() < 0.5 ? 'green' : 'pink', icon: null, autoStart: true, viewDistance: 10,
  });
  const [eula, setEula] = useState(false);
  const [taskId, setTaskId] = useState(null);
  const [created, setCreated] = useState(null);
  const [err, setErr] = useState('');
  const task = useStore((s) => (taskId ? s.tasks[taskId] : null));
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  useEffect(() => { window.scrollTo(0, 0); }, [step]);
  const isPack = type === 'modpack';
  const flavor = FLAVORS.find((f) => f.type === type);

  useEffect(() => { set('memoryMb', Math.min(type === 'modpack' || type === 'neoforge' || type === 'forge' ? 6144 : 4096, Math.floor((total * 0.7) / 512) * 512)); }, [type, total]);

  useEffect(() => {
    if (!type || isPack) return;
    setVersions(null); setMc(''); setLoaders([]); setLoader('');
    api.get(`/versions/${type}`).then(({ versions: v }) => {
      setVersions(v);
      const first = v.find((x) => x.stable);
      if (first) setMc(first.id);
    }).catch((e) => { setErr(e.message); setVersions([]); });
  }, [type]);

  useEffect(() => {
    if (!mc || !['fabric', 'forge', 'neoforge'].includes(type)) return;
    setLoaders([]); setLoader('');
    api.get(`/versions/${type}/${encodeURIComponent(mc)}/loaders`).then(({ loaders: l }) => {
      setLoaders(l);
      const rec = l.find((x) => x.recommended) || l[0];
      if (rec) setLoader(rec.id);
    }).catch(() => {});
  }, [mc, type]);

  const versionItems = useMemo(() => (versions || []).filter((v) => snapshots || v.stable).map((v) => ({ id: v.id, label: v.id, tag: v.stable ? null : 'snapshot' })), [versions, snapshots]);

  const pickFlavor = (t) => { setType(t); setPack(null); setStep(1); setErr(''); };

  const create = async () => {
    setErr('');
    if (!eula) { setErr('Please accept the Minecraft EULA.'); return; }
    try {
      const body = {
        ...form,
        name: form.name.trim() || (pack ? pack.name : `${flavor ? flavor.title : 'My'} Server`),
        motd: form.motd || undefined,
        icon: form.icon || undefined,
        owner: form.owner.trim() || undefined,
        eula: true,
        startAfter: true,
      };
      // A modpack decides its own world type (sky islands, void…), so don't send one.
      if (isPack) { body.modpack = { source: pack.source, projectId: pack.id, versionId: pack.versionId || undefined }; delete body.levelType; }
      else { body.type = type; body.mcVersion = mc; body.loaderVersion = loader || undefined; }
      const r = await api.post('/servers', body);
      setCreated(r.id);
      setTaskId(r.taskId);
      refreshServers();
      setStep(4);
      await waitTask(r.taskId);
    } catch (e) { setErr(e.message); }
  };

  // ------------------------------------------------------------- progress screen
  if (step === 4) {
    const done = task && task.state === 'done';
    const failed = task && task.state === 'failed';
    const res = task && task.result;
    return html`<div class="page"><div class="wizard">
      <div class="panel pad corners" style="padding:34px">
        <div class="row top gap-24 wrap">
          <div class="big-panda" style="margin:0;width:96px;height:96px"><${Pixel} art=${done ? 'panda' : 'sleepy'} size=${66} /></div>
          <div class="grow" style="min-width:260px">
            <div class="kicker">${done ? 'Ready' : failed ? 'Problem' : 'Building'}</div>
            <h1 class="mt-8">${done ? 'Your server is starting!' : failed ? 'That didn\'t work' : `Building ${form.name || (pack ? pack.name : 'your server')}…`}</h1>
            <p class="dim mt-8">${done ? 'It boots in the background. Open it to see the console and your join address.' : failed ? task.error : 'Downloading Minecraft, the right Java and everything else. Big modpacks can take a few minutes.'}</p>
            ${!done && !failed ? html`<div class="mt-24"><${Bar} value=${task ? task.progress : 0} busy=${!task || task.progress == null} /></div><div class="row between mt-8 small"><span class="dim">${task ? task.stage : 'Starting…'}</span><span class="mono muted">${task && task.progress != null ? `${Math.round(task.progress * 100)}%` : ''}</span></div>` : null}
            ${done && res && res.geyser && res.geyser.warning ? html`<div class="alert warn mt-16"><span class="ai"><${Icon} name="gamepad" /></span><div><div class="at">About Bedrock</div><div class="ab">${res.geyser.warning}</div></div></div>` : null}
            ${done && res && res.modpack && res.modpack.blocked && res.modpack.blocked.length ? html`<div class="alert warn mt-16"><span class="ai"><${Icon} name="warn" /></span><div><div class="at">${res.modpack.blocked.length} mods couldn't be downloaded automatically</div><div class="ab">Their authors only allow downloads on curseforge.com. Get them there and drag them into the Mods tab: ${res.modpack.blocked.slice(0, 6).join(', ')}${res.modpack.blocked.length > 6 ? '…' : ''}</div></div></div>` : null}
            ${done && res && res.modpack && res.modpack.clientOnly && res.modpack.clientOnly.length ? html`<div class="alert info mt-16"><span class="ai"><${Icon} name="info" /></span><div><div class="at">Turned off ${res.modpack.clientOnly.length} client-only mods</div><div class="ab">These only work in the game itself, not on servers. You can turn them back on in the Mods tab.</div></div></div>` : null}
            <div class="btn-row mt-24">
              ${done ? html`<${Btn} kind="p" size="lg" iconR="chevR" onClick=${() => go(`/s/${created}`)}>Open server<//>` : null}
              ${failed ? html`<${Btn} onClick=${() => { setStep(3); setTaskId(null); }}>Go back<//><${Btn} kind="ghost" onClick=${() => go(`/s/${created}/console`)}>See details<//>` : null}
              ${!done && !failed ? html`<${Btn} kind="ghost" onClick=${() => go(`/s/${created}`)}>Keep it running, open server page<//>` : null}
            </div>
          </div>
        </div>
      </div>
      ${task && task.log && task.log.length ? html`<details class="panel mt-16"><summary class="panel-h" style="cursor:pointer;border:0"><span class="small muted">Installer output</span></summary><pre class="console" style="max-height:260px;margin:0;padding:12px 16px">${task.log.slice(-80).join('\n')}</pre></details>` : null}
    </div></div>`;
  }

  return html`<div class="page"><div class="wizard">
    <div class="page-head"><div><div class="kicker">New server</div><h1>${step === 0 ? 'What kind of server?' : step === 1 ? (isPack ? 'Pick a modpack' : `Pick a ${flavor ? flavor.title : ''} version`) : step === 2 ? 'Make it yours' : 'Last check'}</h1></div></div>
    <div class="steps">
      ${STEP_NAMES.map((s, i) => html`<button class=${cls('st', step === i && 'on', step > i && 'done')} style="border-top:0;border-bottom:0;border-left:0;background:${step === i ? 'var(--ink-2)' : 'none'};cursor:${i < step ? 'pointer' : 'default'};font:inherit" onClick=${() => i < step && setStep(i)}><span class="n">${step > i ? '✓' : i + 1}</span><span class="lbl-txt">${s}</span></button>`)}
    </div>

    ${step === 0 ? html`<div class="flavors">
      ${FLAVORS.map((f) => html`<button class=${cls('flavor', f.pack && 'pack', type === f.type && 'on')} onClick=${() => pickFlavor(f.type)}>
        ${f.rec ? html`<span class="rec stamp p">Best pick</span>` : null}
        <span class="fl-ic"><${Pixel} art=${f.art} size=${44} /></span>
        <span class="fl-t">${f.title}</span>
        <span class="fl-d">${f.d}</span>
        <span class="fl-tags">${f.tags.map((t) => html`<span class="chip sm">${t}</span>`)}</span>
      </button>`)}
    </div>` : null}

    ${step === 1 && isPack ? html`
      ${pack ? html`<div class="panel pad mb-16 row gap-14" style="border-color:var(--blossom)">
        <div class="c-icon lg">${pack.icon ? html`<img src=${pack.icon} alt="" />` : html`<${Pixel} art="modpack" size=${36} />`}</div>
        <div class="grow"><div class="kicker">Selected</div><div class="c-name mt-4" style="font-size:16px">${pack.name}</div><div class="c-sub">${pack.versionId ? 'Specific version' : 'Latest version'} · from ${pack.source === 'modrinth' ? 'Modrinth' : 'CurseForge'}</div></div>
        <${Btn} kind="p" iconR="chevR" onClick=${() => { if (!form.name) set('name', pack.name); setStep(2); }}>Continue<//>
      </div>` : null}
      <${Browser} kind="modpack" onPick=${(p, versionId) => { setPack({ ...p, versionId }); if (!form.name) set('name', p.name); }} pickLabel="Choose" />
    ` : null}

    ${step === 1 && !isPack ? html`<div class="grid g-side">
      <div class="panel pad">
        ${versions === null ? html`<${Loading} text="Fetching versions…" />` : html`
          <${Field} label="Minecraft version" hint="The newest is picked for you. Friends need the same version in their game.">
            <${Picker} items=${versionItems} value=${mc} onChange=${setMc} placeholder="Search versions, e.g. 1.21" />
          <//>
          <div class="row mt-12"><${Toggle} checked=${snapshots} onChange=${setSnapshots} label="Show snapshots" /><span class="small dim">Show snapshots & pre-releases</span></div>
          <div class="row wrap gap-6 mt-16">${versionItems.slice(0, 8).map((v) => html`<button class=${cls('chip mono', v.id === mc && 'g')} style="cursor:pointer" onClick=${() => setMc(v.id)}>${v.id}</button>`)}</div>
          ${['fabric', 'forge', 'neoforge'].includes(type) ? html`
            <hr class="sep" />
            <button class="linkish small" onClick=${() => setShowAdv(!showAdv)}>${showAdv ? '▾' : '▸'} Loader version (advanced)</button>
            ${showAdv ? html`<div class="mt-12"><${Field} label=${`${flavor.title} version`} hint="Leave on the recommended one unless a modpack needs a specific build.">
              <select class="select mono" value=${loader} onChange=${(e) => setLoader(e.currentTarget.value)}>${loaders.map((l) => html`<option value=${l.id}>${l.id}${l.recommended ? '  (recommended)' : ''}${!l.stable ? '  beta' : ''}</option>`)}</select>
            <//></div>` : html`<div class="small muted mt-8">Using ${loader || '…'} ${loader ? '(recommended)' : ''}</div>`}
          ` : null}
        `}
        ${err ? html`<div class="err-text mt-12">${err}</div>` : null}
        <div class="row between mt-24"><${Btn} kind="ghost" icon="chevL" onClick=${() => setStep(0)}>Back<//><${Btn} kind="g" iconR="chevR" disabled=${!mc} onClick=${() => setStep(2)}>Continue<//></div>
      </div>
      <div class="panel pad">
        <div class="row gap-14"><${Pixel} art=${flavor.art} size=${40} /><div><div class="kicker">You picked</div><h2 class="mt-4">${flavor.title}</h2></div></div>
        <p class="small dim mt-12">${flavor.d}</p>
        <hr class="sep" />
        <div class="small dim">PandA will also download the right <b>Java</b> for this version automatically.</div>
      </div>
    </div>` : null}

    ${step === 2 ? html`<div class="grid g-side">
      <div class="col gap-18">
        <div class="panel pad">
          <div class="grid g2">
            <${Field} label="Server name"><input class="input" maxlength="48" value=${form.name} placeholder=${pack ? pack.name : 'My Server'} onInput=${(e) => set('name', e.currentTarget.value)} /><//>
            <${Field} label="Your Minecraft name" tip="PandA makes you an operator (admin) and adds you to the whitelist, so you're in charge from the first join." hint="Optional — makes you the admin."><input class="input" maxlength="16" value=${form.owner} placeholder="e.g. Alien" onInput=${(e) => set('owner', e.currentTarget.value.replace(/[^A-Za-z0-9_]/g, ''))} /><//>
            <${Field} label="Server message" class="span-2" tip="Shown under your server's name in the multiplayer list. Use §a, §d, §l etc. for colors and bold." hint="Tip: §a = green, §d = pink, §l = bold.">
              <input class="input" value=${form.motd} placeholder=${`§d${form.name || 'My Server'} §7· §aPandA Hosting`} onInput=${(e) => set('motd', e.currentTarget.value)} />
            <//>
            <div class="span-2"><${MotdPreview} name=${form.name || (pack && pack.name)} motd=${form.motd || `§d${form.name || 'My Server'} §7· §aPandA Hosting`} players=${0} max=${form.maxPlayers} icon=${form.icon} id=${seedId} accent=${form.accent} /></div>
            <${Field} label="Server icon" hint="Any picture — PandA shrinks it to 64×64.">
              <div class="row"><label class="btn sm"><${Icon} name="upload" size=${15} />Choose image<input type="file" accept="image/*" class="hide" onChange=${async (e) => { const f = e.currentTarget.files[0]; if (f) set('icon', await resizeIcon(f)); }} /></label>${form.icon ? html`<${Btn} size="sm" kind="ghost" onClick=${() => set('icon', null)}>Remove<//>` : null}</div>
            <//>
            <${Field} label="Card color"><${Seg} value=${form.accent} onChange=${(v) => set('accent', v)} options=${[{ value: 'green', label: 'Bamboo' }, { value: 'pink', label: 'Blossom' }]} /><//>
          </div>
        </div>

        <div class="panel pad">
          <h3 class="mb-12">Gameplay</h3>
          <div class="grid g2">
            <${Field} label="Game mode"><${Seg} block value=${form.gamemode} onChange=${(v) => set('gamemode', v)} options=${[{ value: 'survival', label: 'Survival' }, { value: 'creative', label: 'Creative' }, { value: 'adventure', label: 'Adventure' }]} /><//>
            <${Field} label="Difficulty"><${Seg} block pink value=${form.difficulty} onChange=${(v) => set('difficulty', v)} options=${[{ value: 'peaceful', label: 'Peaceful' }, { value: 'easy', label: 'Easy' }, { value: 'normal', label: 'Normal' }, { value: 'hard', label: 'Hard' }]} /><//>
            <${Field} label=${html`Max players <span class="mono pink" style="margin-left:auto">${form.maxPlayers}</span>`}><${Range} value=${form.maxPlayers} min=${1} max=${100} onInput=${(v) => set('maxPlayers', v)} /><//>
            <${Field} label=${html`View distance <span class="mono pink" style="margin-left:auto">${form.viewDistance} chunks</span>`} tip="How far players can see. Lower is smoother on weaker computers."><${Range} value=${form.viewDistance} min=${4} max=${24} onInput=${(v) => set('viewDistance', v)} /><//>
          </div>
          <div class="mt-12">
            <div class="switch-row"><div class="txt"><div class="t"><${Icon} name="gamepad" size=${16} />Bedrock players (phones & consoles)</div><div class="d">Adds Geyser so people on phones, tablets, Xbox, PlayStation and Switch can join. ${type === 'vanilla' || type === 'forge' ? 'On this flavour they need their own Java account.' : 'They don\'t need a Java account.'}</div></div><${Toggle} pink checked=${form.bedrock} onChange=${(v) => set('bedrock', v)} label="Bedrock" /></div>
            <div class="switch-row"><div class="txt"><div class="t">Whitelist</div><div class="d">Only people you add can join. You're added automatically.</div></div><${Toggle} checked=${form.whitelist} onChange=${(v) => set('whitelist', v)} label="Whitelist" /></div>
            <div class="switch-row"><div class="txt"><div class="t">PvP</div><div class="d">Players can hurt each other.</div></div><${Toggle} checked=${form.pvp} onChange=${(v) => set('pvp', v)} label="PvP" /></div>
            <div class="switch-row"><div class="txt"><div class="t">Hardcore</div><div class="d">One life. Die and you become a spectator.</div></div><${Toggle} pink checked=${form.hardcore} onChange=${(v) => set('hardcore', v)} label="Hardcore" /></div>
            <div class="switch-row"><div class="txt"><div class="t">Cracked mode ${!form.onlineMode ? html`<span class="stamp a">Careful</span>` : null}</div><div class="d">Lets people without a paid Minecraft account join. Anyone could use any name — turn on the whitelist too.</div></div><${Toggle} pink checked=${!form.onlineMode} onChange=${(v) => set('onlineMode', !v)} label="Cracked mode" /></div>
          </div>
          <details class="mt-12"><summary class="linkish small" style="list-style:none">▸ World options</summary>
            <div class="grid g2 mt-12">
              <${Field} label="World seed" hint="Leave empty for a random world."><input class="input mono" value=${form.seed} onInput=${(e) => set('seed', e.currentTarget.value)} /><//>
              ${isPack ? html`<${Field} label="World type"><div class="small dim" style="padding-top:8px">Decided by the modpack (for example sky islands in “To the Sky” packs).</div><//>` : html`<${Field} label="World type"><select class="select" value=${form.levelType} onChange=${(e) => set('levelType', e.currentTarget.value)}>
                <option value="minecraft:normal">Normal</option><option value="minecraft:flat">Superflat</option><option value="minecraft:large_biomes">Large biomes</option><option value="minecraft:amplified">Amplified</option>
              </select><//>`}
            </div>
          </details>
        </div>
      </div>

      <div class="col gap-18">
        <div class="panel pad">
          <div class="row between"><h3>Memory</h3><${Tip} text="RAM the server can use. Vanilla & Paper: 2–4 GB. Mods: 4–6 GB. Big modpacks like All the Mods: 8–10 GB. Leave some for the computer itself." /></div>
          <div class="ram-readout mt-12">${gb(form.memoryMb)} <small>of ${gb(total)}</small></div>
          <div class="mt-8"><${Range} pink value=${form.memoryMb} min=${1024} max=${Math.max(2048, Math.floor((total * 0.85) / 512) * 512)} step=${512} onInput=${(v) => set('memoryMb', v)} /></div>
          <div class="row wrap gap-6 mt-12">${[[2048, 'Small'], [4096, 'Friends'], [6144, 'Mods'], [10240, 'Huge pack']].filter(([m]) => m <= total * 0.85).map(([m, l]) => html`<button class=${cls('chip', form.memoryMb === m && 'p')} style="cursor:pointer" onClick=${() => set('memoryMb', m)}>${l} · ${gb(m)}</button>`)}</div>
          ${form.memoryMb > total * 0.75 ? html`<div class="small amber mt-12">That leaves little for the computer itself — it might get slow.</div>` : null}
        </div>
        <div class="panel pad">
          <div class="switch-row" style="padding-top:0"><div class="txt"><div class="t">Start when PandA starts</div><div class="d">Comes back on its own after a power cut.</div></div><${Toggle} checked=${form.autoStart} onChange=${(v) => set('autoStart', v)} label="Auto start" /></div>
        </div>
        <div class="row between"><${Btn} kind="ghost" icon="chevL" onClick=${() => setStep(1)}>Back<//><${Btn} kind="g" size="lg" iconR="chevR" onClick=${() => setStep(3)}>Review<//></div>
      </div>
    </div>` : null}

    ${step === 3 ? html`<div class="grid g-side">
      <div class="panel pad corners">
        <div class="row gap-14">
          ${form.icon ? html`<img src=${form.icon} width="64" height="64" class="px" style="border:1px solid var(--line-2)" />` : html`<div class="srv-avatar lg"><${Identicon} seed=${seedId} size=${58} accent=${form.accent} /></div>`}
          <div><div class="kicker">Ready to build</div><h1 class="mt-4">${form.name || (pack ? pack.name : `${flavor.title} Server`)}</h1></div>
        </div>
        <dl class="kv mt-24" style="font-size:14px">
          <dt>Flavour</dt><dd>${isPack ? `Modpack · ${pack.name}` : flavor.title}</dd>
          ${!isPack ? html`<dt>Minecraft</dt><dd>${mc}</dd>` : html`<dt>Minecraft</dt><dd>from the pack</dd>`}
          ${loader ? html`<dt>${flavor.title}</dt><dd>${loader}</dd>` : null}
          <dt>Memory</dt><dd>${gb(form.memoryMb)}</dd>
          <dt>Players</dt><dd>${form.maxPlayers} max · ${form.gamemode} · ${form.difficulty}</dd>
          <dt>Bedrock</dt><dd>${form.bedrock ? 'Yes (Geyser)' : 'No'}</dd>
          <dt>Whitelist</dt><dd>${form.whitelist ? 'On' : 'Off'}</dd>
          <dt>Accounts</dt><dd>${form.onlineMode ? 'Real accounts only' : 'Cracked allowed'}</dd>
          ${form.owner ? html`<dt>Admin</dt><dd>${form.owner}</dd>` : null}
        </dl>
        <hr class="sep" />
        <${Check} checked=${eula} onChange=${setEula}>I agree to the <a href="https://aka.ms/MinecraftEULA" target="_blank" rel="noopener">Minecraft End User License Agreement</a>. (Mojang requires this for every server.)<//>
        ${err ? html`<div class="err-text mt-12">${err}</div>` : null}
        <div class="row between mt-24"><${Btn} kind="ghost" icon="chevL" onClick=${() => setStep(2)}>Back<//><${Btn} kind="p" size="xl" icon="bolt" onClick=${create}>Create server<//></div>
      </div>
      <div class="panel pad">
        <div class="kicker g">What happens next</div>
        <ol class="small dim" style="padding-left:18px;line-height:1.9;margin:12px 0 0">
          <li>PandA downloads ${isPack ? 'the modpack, its mods' : 'Minecraft'} and the right Java.</li>
          ${form.bedrock ? html`<li>Geyser + Floodgate are added for Bedrock players.</li>` : null}
          <li>The server starts by itself.</li>
          <li>You get a join address to share with friends.</li>
        </ol>
      </div>
    </div>` : null}
  </div></div>`;
}
