// First boot: Wi-Fi → name & password → first server → open on your phone.
import { html, useState, useEffect } from '../lib/h.js';
import { api } from '../lib/api.js';
import { startLive, waitTask, useStore } from '../lib/store.js';
import { cls, gb } from '../lib/util.js';
import { Icon, Pixel } from '../ui/icons.js';
import { Btn, Field, Toggle, Range, Check, Bar, Seg } from '../ui/kit.js';
import { Wordmark } from '../ui/brand.js';
import { WifiPicker } from './network.js';

const STEPS = ['Welcome', 'Internet', 'You', 'First server', 'Done'];

export function Setup({ state: appState, onDone }) {
  const [step, setStep] = useState(0);
  const [sys, setSys] = useState(null);
  useEffect(() => { api.get('/system').then(setSys).catch(() => {}); }, []);
  return html`<div class="gate">
    <div class="gate-card wide">
      ${step > 0 ? html`<div class="steps">
        ${STEPS.slice(1).map((s, i) => html`<div class=${cls('st', step === i + 1 && 'on', step > i + 1 && 'done')}><span class="n">${step > i + 1 ? '✓' : i + 1}</span><span class="lbl-txt">${s}</span></div>`)}
      </div>` : null}
      ${step === 0 ? html`<${Welcome} next=${() => setStep(1)} local=${appState.local} />` : null}
      ${step === 1 ? html`<${Internet} next=${() => setStep(2)} back=${() => setStep(0)} />` : null}
      ${step === 2 ? html`<${Identity} next=${() => { startLive(); setStep(3); }} back=${() => setStep(1)} />` : null}
      ${step === 3 ? html`<${FirstServer} sys=${sys} next=${() => setStep(4)} />` : null}
      ${step === 4 ? html`<${Finish} sys=${sys} done=${onDone} />` : null}
    </div>
  </div>`;
}

function Welcome({ next }) {
  return html`<div class="center" style="padding:20px 0">
    <div class="big-panda"><${Pixel} art="panda" size=${92} /></div>
    <div class="kicker" style="justify-content:center">First boot</div>
    <div class="hello mt-12">Welcome to<br /><span class="p">P</span>and<span class="a">A</span> Hosting</div>
    <p class="dim mt-16" style="max-width:520px;margin-left:auto;margin-right:auto;font-size:16px">Your own Minecraft server box. No commands, no router fiddling — just click, play, and invite your friends.</p>
    <div class="mt-24"><span class="founders"><${Icon} name="heart" size=${15} /> Made by <b class="green">Alien</b> & <b class="pink">Patrko</b></span></div>
    <div class="small muted mt-8"><span class="pink">P</span>atrko <span class="dim">and</span> <span class="green">A</span>lien = <span class="pink">P</span>and<span class="green">A</span></div>
    <div class="mt-32"><${Btn} kind="p" size="xl" iconR="chevR" onClick=${next}>Let's set it up<//></div>
    <div class="small muted mt-16">Takes about two minutes.</div>
  </div>`;
}

function Internet({ next, back }) {
  const [net, setNet] = useState(null);
  const load = () => api.get('/network').then(setNet).catch(() => setNet({ wifi: { supported: false, connected: true } }));
  useEffect(() => { load(); }, []);
  const w = net && net.wifi;
  return html`<div class="panel pad corners">
    <div class="kicker g">Step 1</div>
    <h1 class="mt-8">Get online</h1>
    <p class="dim mt-8">PandA needs the internet to download Minecraft, mods and Java.</p>
    <div class="mt-24">
      ${!net ? html`<div class="muted">Checking your connection…</div>` : null}
      ${w && w.connected ? html`<div class="alert ok"><span class="ai"><${Icon} name="check" /></span><div><div class="at">You're online${w.ethernet ? ' with a cable' : w.ssid ? ` on “${w.ssid}”` : ''}</div><div class="ab">${w.supported ? 'You can switch Wi-Fi networks below if you want.' : w.note || 'All good.'}</div></div></div>` : null}
      ${w && w.supported ? html`<div class="mt-16"><${WifiPicker} onConnected=${load} /></div>` : null}
    </div>
    <div class="row between mt-24"><${Btn} kind="ghost" icon="chevL" onClick=${back}>Back<//><${Btn} kind="g" size="lg" iconR="chevR" disabled=${!(w && w.connected)} onClick=${next}>Continue<//></div>
  </div>`;
}

function Identity({ next, back }) {
  const [name, setName] = useState('PandA');
  const [pw, setPw] = useState('');
  const [pw2, setPw2] = useState('');
  const [trust, setTrust] = useState(true);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const submit = async () => {
    setErr('');
    if (pw.length < 4) return setErr('Use at least 4 characters for the password.');
    if (pw !== pw2) return setErr('The two passwords don\'t match.');
    setBusy(true);
    try { await api.post('/setup', { deviceName: name, password: pw, trustLocal: trust, tz: (() => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone; } catch { return ''; } })() }); next(); } catch (e) { setErr(e.message); }
    setBusy(false);
  };
  return html`<div class="panel pad corners">
    <div class="kicker g">Step 2</div>
    <h1 class="mt-8">Name your box</h1>
    <p class="dim mt-8">The name shows up on your network. The password protects the panel when you open it from a phone or another computer.</p>
    <div class="grid g2 mt-24">
      <${Field} label="Device name" hint="Like “Alien's PandA” or “Basement Server”.">
        <input class="input big" value=${name} maxlength="40" onInput=${(e) => setName(e.currentTarget.value)} />
      <//>
      <div></div>
      <${Field} label="Panel password">
        <input class="input big" type="password" autocomplete="new-password" value=${pw} onInput=${(e) => setPw(e.currentTarget.value)} />
      <//>
      <${Field} label="Type it again">
        <input class="input big" type="password" autocomplete="new-password" value=${pw2} onInput=${(e) => setPw2(e.currentTarget.value)} onKeyDown=${(e) => e.key === 'Enter' && submit()} />
      <//>
    </div>
    <div class="switch-row mt-16">
      <div class="txt"><div class="t">Skip the password on this screen</div><div class="d">The screen plugged into this machine opens the panel straight away. Phones and other PCs still need the password.</div></div>
      <${Toggle} checked=${trust} onChange=${setTrust} label="Skip password on this screen" />
    </div>
    ${err ? html`<div class="err-text mt-12">${err}</div>` : null}
    <div class="row between mt-24"><${Btn} kind="ghost" icon="chevL" onClick=${back}>Back<//><${Btn} kind="g" size="lg" iconR="chevR" loading=${busy} onClick=${submit}>Save & continue<//></div>
  </div>`;
}

const QUICK = [
  { type: 'paper', title: 'Paper', d: 'Fast, supports plugins. Best for friends.', art: 'paper', rec: true },
  { type: 'fabric', title: 'Fabric', d: 'For mods like Create, Cobblemon…', art: 'fabric' },
  { type: 'vanilla', title: 'Vanilla', d: 'Pure Minecraft, nothing extra.', art: 'vanilla' },
];

function FirstServer({ sys, next }) {
  const [type, setType] = useState('paper');
  const [versions, setVersions] = useState([]);
  const [mc, setMc] = useState('');
  const [name, setName] = useState('My Server');
  const [owner, setOwner] = useState('');
  const total = sys ? Math.floor(sys.info.memTotal / 1048576) : 8192;
  const [mem, setMem] = useState(Math.min(4096, Math.max(2048, Math.floor(total / 3 / 512) * 512)));
  const [bedrock, setBedrock] = useState(true);
  const [eula, setEula] = useState(false);
  const [busy, setBusy] = useState(false);
  const [taskId, setTaskId] = useState(null);
  const [err, setErr] = useState('');
  const task = useStore((s) => (taskId ? s.tasks[taskId] : null));

  useEffect(() => {
    setVersions([]);
    api.get(`/versions/${type}`).then(({ versions: v }) => { const st = v.filter((x) => x.stable); setVersions(st.slice(0, 30)); setMc(st[0] ? st[0].id : ''); }).catch((e) => setErr(e.message));
  }, [type]);

  const create = async () => {
    setErr('');
    if (!eula) return setErr('Tick the EULA box to continue.');
    setBusy(true);
    try {
      const r = await api.post('/servers', { type, mcVersion: mc, name, memoryMb: mem, bedrock, eula: true, owner: owner.trim() || undefined, startAfter: true });
      setTaskId(r.taskId);
      await waitTask(r.taskId);
      next();
    } catch (e) { setErr(e.message); setBusy(false); }
  };

  if (taskId) {
    return html`<div class="panel pad corners">
      <div class="kicker g">Step 3</div>
      <h1 class="mt-8">Building ${name}…</h1>
      <p class="dim mt-8">PandA is downloading Minecraft and the right Java for it. You can grab a snack.</p>
      <div class="mt-24"><${Bar} value=${task ? task.progress : 0} busy=${!task || task.progress == null} /></div>
      <div class="row between mt-8 small"><span class="dim">${task ? task.stage : 'Starting…'}</span><span class="mono muted">${task && task.progress != null ? `${Math.round(task.progress * 100)}%` : ''}</span></div>
      ${err ? html`<div class="alert error mt-16"><span class="ai"><${Icon} name="warn" /></span><div><div class="at">That didn't work</div><div class="ab">${err}</div></div></div><div class="mt-16"><${Btn} onClick=${() => { setTaskId(null); setBusy(false); }}>Try again<//> <${Btn} kind="ghost" onClick=${next}>Skip<//></div>` : null}
    </div>`;
  }

  return html`<div class="panel pad corners">
    <div class="kicker g">Step 3</div>
    <h1 class="mt-8">Make your first server</h1>
    <p class="dim mt-8">You can make more later — and add modpacks like All the Mods from the Control Panel.</p>
    <div class="grid g3 mt-24">
      ${QUICK.map((q) => html`<button class=${cls('flavor', type === q.type && 'on')} onClick=${() => setType(q.type)}>
        ${q.rec ? html`<span class="rec stamp p">Best pick</span>` : null}
        <span class="fl-ic"><${Pixel} art=${q.art} size=${44} /></span>
        <span class="fl-t">${q.title}</span><span class="fl-d">${q.d}</span>
      </button>`)}
    </div>
    <div class="grid g2 mt-24">
      <${Field} label="Server name"><input class="input" value=${name} maxlength="48" onInput=${(e) => setName(e.currentTarget.value)} /><//>
      <${Field} label="Minecraft version">
        <select class="select mono" value=${mc} onChange=${(e) => setMc(e.currentTarget.value)}>${versions.map((v) => html`<option value=${v.id}>${v.id}</option>`)}</select>
      <//>
      <${Field} label="Your Minecraft name (optional)" hint="You'll be made an operator automatically."><input class="input" value=${owner} placeholder="e.g. Notch" maxlength="16" onInput=${(e) => setOwner(e.currentTarget.value)} /><//>
      <${Field} label=${html`Memory <span class="mono pink" style="margin-left:auto">${gb(mem)}</span>`} hint=${`This computer has ${gb(total)}. 4 GB is plenty for friends.`}>
        <${Range} value=${mem} min=${1024} max=${Math.max(2048, Math.floor((total * 0.8) / 512) * 512)} step=${512} onInput=${setMem} pink />
      <//>
    </div>
    <div class="switch-row mt-12">
      <div class="txt"><div class="t"><${Icon} name="gamepad" size=${16} /> Phone & console friends (Bedrock)</div><div class="d">Lets people on phones, Xbox, PlayStation and Switch join too. Uses Geyser.</div></div>
      <${Toggle} checked=${bedrock} onChange=${setBedrock} pink label="Bedrock support" />
    </div>
    <div class="mt-16"><${Check} checked=${eula} onChange=${setEula}>I agree to the <a href="https://aka.ms/MinecraftEULA" target="_blank" rel="noopener">Minecraft EULA</a> (Mojang's rules for running a server).<//></div>
    ${err ? html`<div class="err-text mt-12">${err}</div>` : null}
    <div class="row between mt-24"><${Btn} kind="ghost" onClick=${next}>Skip for now<//><${Btn} kind="p" size="lg" icon="bolt" loading=${busy} disabled=${!mc} onClick=${create}>Create server<//></div>
  </div>`;
}

function Finish({ sys, done }) {
  const url = sys ? sys.panelUrl : '';
  return html`<div class="panel pad corners">
    <div class="row top gap-24 wrap">
      <div class="grow" style="min-width:260px">
        <div class="kicker g">All set</div>
        <h1 class="mt-8">You're ready to play</h1>
        <p class="dim mt-8">Open the panel from your phone or another computer on the same Wi-Fi — scan the code or type the address.</p>
        <div class="ticket green mt-24" style="min-height:0;grid-template-columns:1fr">
          <div class="main-part"><div class="t-k">PANEL ADDRESS</div><div class="t-addr" style="font-size:24px">${url.replace('http://', '')}</div></div>
        </div>
        <div class="mt-24"><${Btn} kind="p" size="xl" iconR="chevR" onClick=${done}>Open the Control Panel<//></div>
      </div>
      <div class="col" style="align-items:center">
        <div class="qr"><img src=${`/api/system/qr?text=${encodeURIComponent(url)}`} alt="QR code for the panel address" /></div>
        <span class="small muted">Scan with your phone camera</span>
      </div>
    </div>
  </div>`;
}

export { Wordmark };
