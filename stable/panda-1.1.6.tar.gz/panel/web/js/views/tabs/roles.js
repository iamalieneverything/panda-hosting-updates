// Roles & permissions: operator levels everywhere, real permissions through LuckPerms.
import { html, useState, useEffect } from '../../lib/h.js';
import { api } from '../../lib/api.js';
import { toast, waitTask } from '../../lib/store.js';
import { cls } from '../../lib/util.js';
import { Icon } from '../../ui/icons.js';
import { Btn, Tip, Loading, confirm, Head } from '../../ui/kit.js';

const LEVEL_HELP = {
  0: 'Regular player — no operator powers.',
  1: 'Helper: can build inside spawn protection.',
  2: 'Game master: cheats, /gamemode, /tp, /give, command blocks.',
  3: 'Moderator: also kick, ban, op and whitelist players.',
  4: 'Owner: everything, including /stop and /save-all.',
};

function RoleCard({ role, idx, players, catalog, permsOn, onChange, onDelete }) {
  const [member, setMember] = useState('');
  const [perm, setPerm] = useState('');
  const set = (k, v) => onChange({ ...role, [k]: v });
  const addMember = () => {
    const n = member.trim();
    if (!/^[.*]?[A-Za-z0-9_]{1,16}$/.test(n)) { toast('error', 'That isn\'t a Minecraft name'); return; }
    if (!role.members.some((m) => m.toLowerCase() === n.toLowerCase())) set('members', [...role.members, n]);
    setMember('');
  };
  const addPerm = (p) => {
    const node = String(p || perm).trim();
    if (!node || !/^[a-z0-9*._\-]+$/i.test(node)) return;
    if (!role.permissions.includes(node)) set('permissions', [...role.permissions, node]);
    setPerm('');
  };
  const labelFor = (node) => { for (const g of catalog) for (const n of g.nodes) if (n.node === node) return n.label; return null; };
  return html`<div class="role">
    <div class="role-h" style=${`box-shadow:inset 4px 0 0 ${role.color}`}>
      <label class="role-swatch" style=${`background:${role.color};position:relative`} title="Role color"><input type="color" value=${role.color} onInput=${(e) => set('color', e.currentTarget.value)} style="opacity:0;position:absolute;inset:0;cursor:pointer" /></label>
      <input class="input" style="max-width:220px;font-weight:700" value=${role.name} maxlength="24" onInput=${(e) => set('name', e.currentTarget.value)} aria-label="Role name" />
      <span class="grow"></span>
      <span class="chip sm mono">${role.members.length} ${role.members.length === 1 ? 'member' : 'members'}</span>
      ${idx > 0 ? html`<${Btn} kind="ghost" size="sm" icon="trash" aria-label="Delete role" onClick=${onDelete} />` : null}
    </div>
    <div class="role-b">
      <div class="row wrap gap-18">
        <div>
          <div class="lbl mb-8">Operator level <${Tip} title="Operator level" text="Minecraft's built-in power levels. Works on every server type. The highest role a player has wins." /></div>
          <div class="levels">${[0, 1, 2, 3, 4].map((l) => html`<button type="button" class=${cls(role.opLevel === l && 'on')} title=${LEVEL_HELP[l]} onClick=${() => set('opLevel', l)}>${l}</button>`)}</div>
          <div class="tiny muted mt-4" style="max-width:300px">${LEVEL_HELP[role.opLevel]}</div>
        </div>
        ${permsOn ? html`<div>
          <div class="lbl mb-8">Chat prefix <${Tip} text="Shown before the player's name in chat. Use & color codes, like &d for pink." /></div>
          <input class="input mono" style="width:180px" value=${role.prefix} maxlength="32" onInput=${(e) => set('prefix', e.currentTarget.value)} />
        </div>
        <div>
          <div class="lbl mb-8">Priority <${Tip} text="Higher numbers win when a player has several roles." /></div>
          <input class="input mono" style="width:90px" inputmode="numeric" value=${role.weight} onInput=${(e) => set('weight', Number(e.currentTarget.value.replace(/\D/g, '')) || 0)} />
        </div>` : null}
      </div>

      <div>
        <div class="lbl mb-8">Members</div>
        <div class="member-list">
          ${role.members.map((m) => html`<span class="chip"><${Head} name=${m} size=${18} />${m}<button class="x" aria-label=${`Remove ${m}`} onClick=${() => set('members', role.members.filter((x) => x !== m))}><${Icon} name="x" size=${12} /></button></span>`)}
          <div class="row gap-4">
            <input class="input" style="height:28px;width:160px;font-size:13px" list=${`players-${idx}`} placeholder="Add player…" value=${member} onInput=${(e) => setMember(e.currentTarget.value)} onKeyDown=${(e) => e.key === 'Enter' && addMember()} />
            <datalist id=${`players-${idx}`}>${players.map((p) => html`<option value=${p} />`)}</datalist>
            <${Btn} size="xs" icon="plus" aria-label="Add member" onClick=${addMember} />
          </div>
        </div>
      </div>

      ${permsOn ? html`<div>
        <div class="lbl mb-8">Permissions <${Tip} text="What this role is allowed to do. These come from Minecraft and your plugins. PandA applies them through LuckPerms." /></div>
        <div class="perm-list">
          ${role.permissions.map((p) => html`<span class=${cls('chip', p === '*' && 'p')} title=${p}>${labelFor(p) || html`<span class="mono">${p}</span>`}<button class="x" aria-label=${`Remove ${p}`} onClick=${() => set('permissions', role.permissions.filter((x) => x !== p))}><${Icon} name="x" size=${12} /></button></span>`)}
          ${!role.permissions.length ? html`<span class="small muted">No extra permissions.</span>` : null}
        </div>
        <div class="row wrap mt-8">
          <select class="select" style="height:32px;width:auto;max-width:280px;font-size:13px" value="" onChange=${(e) => { addPerm(e.currentTarget.value); e.currentTarget.value = ''; }}>
            <option value="">+ Add a common permission…</option>
            ${catalog.map((g) => html`<optgroup label=${g.group}>${g.nodes.filter((n) => !role.permissions.includes(n.node)).map((n) => html`<option value=${n.node}>${n.label}</option>`)}</optgroup>`)}
          </select>
          <input class="input mono" style="height:32px;width:220px;font-size:12.5px" placeholder="or type one: plugin.node" value=${perm} onInput=${(e) => setPerm(e.currentTarget.value)} onKeyDown=${(e) => e.key === 'Enter' && addPerm()} />
          <${Btn} size="xs" icon="plus" aria-label="Add permission" disabled=${!perm.trim()} onClick=${() => addPerm()} />
        </div>
      </div>` : null}
    </div>
  </div>`;
}

export function RolesTab({ id, server }) {
  const [data, setData] = useState(null);
  const [roles, setRoles] = useState([]);
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [installing, setInstalling] = useState(false);
  const load = () => api.get(`/servers/${id}/roles`).then((d) => { setData(d); setRoles(d.roles); setDirty(false); }).catch((e) => toast('error', 'Couldn\'t load roles', e.message));
  useEffect(() => { load(); }, [id]);
  if (!data) return html`<${Loading} />`;
  const change = (i, r) => { setRoles((list) => list.map((x, j) => (j === i ? r : x))); setDirty(true); };
  const add = () => { setRoles((list) => [...list, { id: `role-${Date.now().toString(36)}`, name: 'New role', color: '#b9ff9e', prefix: '', opLevel: 0, weight: 20, permissions: [], members: [] }]); setDirty(true); };
  const del = async (i) => { if (await confirm({ title: `Delete ${roles[i].name}?`, body: 'Members lose this role\'s powers.', ok: 'Delete', danger: true })) { setRoles((l) => l.filter((_, j) => j !== i)); setDirty(true); } };
  const save = async () => {
    setSaving(true);
    try {
      const { result } = await api.put(`/servers/${id}/roles`, { roles });
      toast('success', 'Roles saved', result.waiting ? (data.luckperms && server.status !== 'online' ? 'Permissions apply when the server starts.' : 'Exact operator levels apply after the next restart.') : 'Applied.');
      load();
    } catch (e) { toast('error', 'Not saved', e.message); }
    setSaving(false);
  };
  const installLp = async () => {
    setInstalling(true);
    try { const { taskId } = await api.post(`/servers/${id}/roles/luckperms`); await waitTask(taskId); toast('success', 'LuckPerms installed', 'Restart the server, then save your roles.'); load(); } catch (e) { toast('error', 'Couldn\'t install LuckPerms', e.message); }
    setInstalling(false);
  };
  const permsOn = data.luckperms;
  return html`<div>
    ${data.luckperms ? html`<div class="alert ok mb-16"><span class="ai"><${Icon} name="check" /></span><div class="grow"><div class="at">Full permissions are on (LuckPerms)</div><div class="ab">Roles become LuckPerms groups with the permissions, prefixes and members below. ${server.status !== 'online' ? 'They are applied when the server is running.' : ''}</div></div></div>`
      : data.canLuckPerms ? html`<div class="alert info mb-16"><span class="ai"><${Icon} name="crown" /></span><div class="grow"><div class="at">Want detailed permissions?</div><div class="ab">Right now roles set Minecraft operator levels. Add LuckPerms (free, one click) to control exactly what each role can do, and give them chat prefixes.</div></div><${Btn} kind="p" size="sm" icon="download" loading=${installing} onClick=${installLp}>Add LuckPerms<//></div>`
      : html`<div class="alert info mb-16"><span class="ai"><${Icon} name="info" /></span><div class="grow"><div class="at">Roles = operator levels on Vanilla</div><div class="ab">For detailed permissions, use a Paper or Fabric server with LuckPerms.</div></div></div>`}
    <div class="col gap-14">
      ${roles.map((r, i) => html`<${RoleCard} key=${r.id} role=${r} idx=${i} players=${data.players} catalog=${data.catalog} permsOn=${permsOn} onChange=${(x) => change(i, x)} onDelete=${() => del(i)} />`)}
    </div>
    <div class="row mt-16"><${Btn} icon="plus" onClick=${add}>Add role<//></div>
    ${dirty ? html`<div class="savebar"><span class="sq" style="background:var(--blossom)"></span><div class="grow"><b>Unsaved role changes</b><div class="small muted">Saving applies them to the server.</div></div><${Btn} kind="ghost" onClick=${() => { setRoles(data.roles); setDirty(false); }}>Discard<//><${Btn} kind="p" icon="save" loading=${saving} onClick=${save}>Save & apply<//></div>` : null}
  </div>`;
}
