// Players (kick / ban / op / whitelist as buttons) + live chat with a broadcast box.
import { html, useState, useEffect, useRef } from '../../lib/h.js';
import { api } from '../../lib/api.js';
import { useStore, onChat, toast } from '../../lib/store.js';
import { cls, ago, clock } from '../../lib/util.js';
import { Icon } from '../../ui/icons.js';
import { Btn, Toggle, Seg, Head, confirm, prompt, Loading } from '../../ui/kit.js';

function Chat({ id, server }) {
  const [msgs, setMsgs] = useState([]);
  const [text, setText] = useState('');
  const [style, setStyle] = useState('chat');
  const [busy, setBusy] = useState(false);
  const log = useRef();
  const stick = useRef(true);
  useEffect(() => {
    api.get(`/servers/${id}/chat`).then(({ chat }) => setMsgs(chat)).catch(() => {});
    return onChat(id, (e) => setMsgs((m) => [...m, e].slice(-400)));
  }, [id]);
  useEffect(() => { if (stick.current && log.current) log.current.scrollTop = log.current.scrollHeight; }, [msgs]);
  const send = async (e) => {
    e && e.preventDefault();
    if (!text.trim()) return;
    setBusy(true);
    try { await api.post(`/servers/${id}/broadcast`, { message: text, style }); setText(''); stick.current = true; } catch (x) { toast('error', 'Not sent', x.message); }
    setBusy(false);
  };
  const online = server.status === 'online';
  return html`<div class="panel chat-box">
    <div class="panel-h"><h3><${Icon} name="chat" size=${16} />Live chat</h3><span class=${cls('chip sm', online ? 'g' : '')}><span class=${cls('sq', online ? 'online' : 'offline')}></span>${online ? 'Live' : 'Offline'}</span></div>
    <div class="chat-log" ref=${log} onScroll=${(e) => { const el = e.currentTarget; stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 30; }}>
      ${!msgs.length ? html`<div class="small muted center" style="margin:auto">Chat messages, joins and deaths show up here.</div>` : null}
      ${msgs.map((m, i) => {
        if (m.type === 'chat') return html`<div class="cmsg" key=${i}><${Head} name=${m.name} size=${22} /><div class="grow"><span class="who">${m.name}</span>${m.message}</div><span class="when">${clock(m.t)}</span></div>`;
        if (m.type === 'broadcast' || m.type === 'say') return html`<div class="cmsg bc" key=${i}><div class="grow"><span class="who">${m.type === 'say' ? `[${m.name}]` : 'You'}</span>${m.message}${m.style && m.style !== 'chat' ? html` <span class="chip sm">${m.style}</span>` : null}</div><span class="when">${clock(m.t)}</span></div>`;
        const icon = m.type === 'join' ? 'user' : m.type === 'leave' ? 'logout' : m.type === 'death' ? 'skull' : 'star';
        const txt = m.type === 'join' ? 'joined the game' : m.type === 'leave' ? 'left the game' : m.type === 'death' ? m.message.replace(m.name, '').trim() : m.message;
        return html`<div class=${cls('cmsg sys', m.type === 'death' && 'death')} key=${i}><${Icon} name=${icon} size=${14} /><div class="grow"><span class="who">${m.name}</span>${txt}</div><span class="when">${clock(m.t)}</span></div>`;
      })}
    </div>
    <form class="bc-box" onSubmit=${send}>
      <div class="row between"><span class="lbl"><${Icon} name="megaphone" size=${15} />Broadcast</span><${Seg} small pink value=${style} onChange=${setStyle} options=${[{ value: 'chat', label: 'Chat' }, { value: 'title', label: 'Big title' }, { value: 'actionbar', label: 'Action bar' }]} /></div>
      <div class="row"><input class="input" maxlength="256" placeholder=${online ? 'Say something to everyone…' : 'Start the server to chat'} disabled=${!online} value=${text} onInput=${(e) => setText(e.currentTarget.value)} /><${Btn} kind="p" type="submit" icon="chevR" loading=${busy} disabled=${!online || !text.trim()}>Send<//></div>
    </form>
  </div>`;
}

export function PlayersTab({ id, server }) {
  const live = useStore((s) => (s.servers[id] ? (s.servers[id].players || []).map((p) => p.name).join(',') : ''));
  const [data, setData] = useState(null);
  const [name, setName] = useState('');
  const [showIps, setShowIps] = useState(false);
  const [busy, setBusy] = useState(null);
  const load = () => api.get(`/servers/${id}/players`).then(setData).catch((e) => toast('error', 'Couldn\'t load players', e.message));
  useEffect(() => { load(); }, [id, live, server.status]);

  const act = async (action, who, extra = {}) => {
    setBusy(`${action}:${who}`);
    try {
      await api.post(`/servers/${id}/players/action`, { action, name: who, ...extra });
      const labels = { kick: 'Kicked', ban: 'Banned', pardon: 'Unbanned', op: 'Now an operator', deop: 'No longer an operator', 'whitelist-add': 'Added to whitelist', 'whitelist-remove': 'Removed from whitelist', gamemode: 'Game mode changed', msg: 'Message sent', kill: 'Done' };
      toast('success', `${who}: ${labels[action] || 'Done'}`);
      setTimeout(load, 600);
    } catch (e) { toast('error', 'Couldn\'t do that', e.message); }
    setBusy(null);
  };
  const kick = async (who) => { const r = await prompt({ title: `Kick ${who}?`, body: 'They can join again right away. Add a reason if you like.', placeholder: 'Reason (optional)', ok: 'Kick', icon: 'logout' }); if (r !== null) act('kick', who, { reason: r }); };
  const ban = async (who) => { const r = await prompt({ title: `Ban ${who}?`, body: 'They won\'t be able to join until you unban them.', placeholder: 'Reason (optional)', ok: 'Ban', icon: 'ban' }); if (r !== null) act('ban', who, { reason: r }); };
  const msg = async (who) => { const r = await prompt({ title: `Message ${who}`, body: 'Sends a private message only they can see.', placeholder: 'Hey!', ok: 'Send', icon: 'chat' }); if (r) act('msg', who, { value: r }); };
  const toggleWl = async (on) => {
    try { await api.post(`/servers/${id}/whitelist`, { enabled: on }); setData((d) => ({ ...d, whitelistOn: on })); toast('success', on ? 'Whitelist on' : 'Whitelist off', on ? 'Only listed players can join.' : 'Anyone with the address can join.'); } catch (e) { toast('error', 'Not saved', e.message); }
  };
  const addName = async (action) => {
    const n = name.trim();
    if (!/^[.*]?[A-Za-z0-9_]{1,16}$/.test(n)) { toast('error', 'That isn\'t a Minecraft name', 'Names are 3–16 letters, numbers or _.'); return; }
    await act(action, n);
    setName('');
  };

  if (!data) return html`<${Loading} />`;
  const known = data.known.filter((k) => !data.online.some((o) => o.name.toLowerCase() === k.name.toLowerCase()));
  const kRow = (p) => known.find((k) => k.name.toLowerCase() === p.name.toLowerCase()) || data.known.find((k) => k.name.toLowerCase() === p.name.toLowerCase()) || {};

  return html`<div class="grid g-side">
    <div class="col gap-18">
      <div class="panel">
        <div class="panel-h">
          <h3><${Icon} name="users" size=${16} />Online now <span class="chip sm g mono">${data.online.length}/${data.max}</span></h3>
          <label class="row gap-6 small dim"><${Toggle} checked=${showIps} onChange=${setShowIps} label="Show IPs" />Show IPs</label>
        </div>
        <div class="plist">
          ${!data.online.length ? html`<div class="small muted" style="padding:22px 16px">${data.running ? 'Nobody is online right now.' : 'The server is offline. You can still manage the lists below.'}</div>` : null}
          ${data.online.map((p) => {
            const k = kRow(p);
            return html`<div class="prow">
              <${Head} name=${p.name} />
              <div class="grow" style="min-width:140px">
                <div class="pn">${p.name}${k.op ? html`<span class="chip sm p" title="Operator"><${Icon} name="crown" size=${11} />OP</span>` : null}${p.bedrock ? html`<span class="chip sm"><${Icon} name="gamepad" size=${11} />Bedrock</span>` : null}</div>
                <div class="ps">joined ${ago(p.joinedAt)}${showIps && p.ip ? html` · <span class="mono">${p.ip}</span>` : ''}</div>
              </div>
              <div class="acts">
                <select class="select" style="height:26px;width:auto;font-size:12px;padding:0 26px 0 8px;background-position:calc(100% - 13px) 11px,calc(100% - 8px) 11px" aria-label="Game mode" onChange=${(e) => { if (e.currentTarget.value) act('gamemode', p.name, { value: e.currentTarget.value }); e.currentTarget.value = ''; }}>
                  <option value="">Mode…</option><option value="survival">Survival</option><option value="creative">Creative</option><option value="adventure">Adventure</option><option value="spectator">Spectator</option>
                </select>
                <${Btn} size="xs" icon="chat" title="Message" aria-label="Message" onClick=${() => msg(p.name)} />
                <${Btn} size="xs" kind=${k.op ? 'p' : ''} icon="crown" loading=${busy === `op:${p.name}` || busy === `deop:${p.name}`} onClick=${() => act(k.op ? 'deop' : 'op', p.name)}>${k.op ? 'De-op' : 'Op'}<//>
                <${Btn} size="xs" icon="logout" onClick=${() => kick(p.name)}>Kick<//>
                <${Btn} size="xs" kind="danger" icon="ban" onClick=${() => ban(p.name)}>Ban<//>
              </div>
            </div>`;
          })}
        </div>
      </div>

      <div class="panel">
        <div class="panel-h">
          <h3><${Icon} name="checkSq" size=${16} />Whitelist & everyone</h3>
          <label class="row gap-6 small"><span class="dim">Whitelist</span><${Toggle} checked=${data.whitelistOn} onChange=${toggleWl} label="Whitelist" /></label>
        </div>
        <div class="panel-b" style="border-bottom:1px solid var(--line)">
          <div class="row wrap">
            <div class="input-wrap grow" style="min-width:180px"><span class="ic-l"><${Icon} name="userPlus" size=${15} /></span><input class="input" placeholder="Minecraft name" maxlength="17" value=${name} onInput=${(e) => setName(e.currentTarget.value)} onKeyDown=${(e) => e.key === 'Enter' && addName('whitelist-add')} /></div>
            <${Btn} kind="g" icon="checkSq" disabled=${!name.trim()} onClick=${() => addName('whitelist-add')}>Whitelist<//>
            <${Btn} icon="crown" disabled=${!name.trim()} onClick=${() => addName('op')}>Make op<//>
            <${Btn} kind="danger" icon="ban" disabled=${!name.trim()} onClick=${() => addName('ban')}>Ban<//>
          </div>
          ${!data.onlineMode ? html`<div class="small amber mt-8">Cracked mode is on, so names are matched without checking Mojang.</div>` : null}
        </div>
        ${known.length ? html`<div style="overflow-x:auto"><table class="table">
          <thead><tr><th>Player</th><th>Status</th><th style="text-align:right">Actions</th></tr></thead>
          <tbody>${known.map((p) => html`<tr>
            <td><div class="row"><${Head} name=${p.name} size=${26} class="sm" /><b>${p.name}</b></div></td>
            <td><div class="row wrap gap-4">
              ${p.op ? html`<span class="chip sm p"><${Icon} name="crown" size=${11} />OP ${p.op}</span>` : null}
              ${p.whitelisted ? html`<span class="chip sm g">Whitelisted</span>` : null}
              ${p.banned ? html`<span class="chip sm r" title=${p.banReason}>Banned</span>` : null}
              ${!p.op && !p.whitelisted && !p.banned ? html`<span class="small muted">Visited before</span>` : null}
            </div></td>
            <td><div class="row gap-4" style="justify-content:flex-end;flex-wrap:wrap">
              <${Btn} size="xs" kind=${p.whitelisted ? 'g' : ''} icon="checkSq" onClick=${() => act(p.whitelisted ? 'whitelist-remove' : 'whitelist-add', p.name)}>${p.whitelisted ? 'Listed' : 'Whitelist'}<//>
              <${Btn} size="xs" kind=${p.op ? 'p' : ''} icon="crown" onClick=${() => act(p.op ? 'deop' : 'op', p.name)}>${p.op ? 'De-op' : 'Op'}<//>
              ${p.banned ? html`<${Btn} size="xs" icon="check" onClick=${() => act('pardon', p.name)}>Unban<//>` : html`<${Btn} size="xs" kind="danger" icon="ban" onClick=${() => ban(p.name)}>Ban<//>`}
            </div></td>
          </tr>`)}</tbody>
        </table></div>` : html`<div class="small muted" style="padding:18px 16px">Players who join, or that you add above, are listed here.</div>`}
      </div>
    </div>
    <${Chat} id=${id} server=${server} />
  </div>`;
}

export { confirm };
