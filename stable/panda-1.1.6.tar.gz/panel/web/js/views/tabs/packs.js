// Datapacks + resource packs with drag and drop. PandA hosts resource packs itself.
import { html, useState, useEffect } from '../../lib/h.js';
import { api, upload } from '../../lib/api.js';
import { toast, waitTask } from '../../lib/store.js';
import { cls, bytes, ago } from '../../lib/util.js';
import { Icon, Pixel } from '../../ui/icons.js';
import { Btn, Toggle, Dropzone, useWindowDrop, DropVeil, Loading, confirm, Bar, Field, Img } from '../../ui/kit.js';
import { Browser } from '../browse.js';

function PackList({ id, kind, server, active, onUse }) {
  const [items, setItems] = useState(null);
  const [extra, setExtra] = useState({});
  const [view, setView] = useState('installed');
  const [uploading, setUploading] = useState(null);
  const load = () => api.get(`/servers/${id}/content/${kind}`).then((r) => { setItems(r.items); setExtra(r); }).catch((e) => toast('error', 'Couldn\'t load', e.message));
  useEffect(() => { load(); }, [id, kind]);
  const word = kind === 'datapack' ? 'datapack' : 'resource pack';

  const doUpload = async (files) => {
    setUploading(0);
    try {
      const r = await upload(`/servers/${id}/content/${kind}/upload`, files, setUploading);
      if (r.added.length) toast('success', `Added ${r.added.join(', ')}`);
      if (r.rejected.length) toast('error', 'Only .zip files work here', r.rejected.join(', '));
      load();
    } catch (e) { toast('error', 'Upload failed', e.message); }
    setUploading(null);
  };
  const over = useWindowDrop(doUpload, '.zip', view === 'installed');
  const install = async (p, versionId) => {
    try {
      const { taskId } = await api.post(`/servers/${id}/content/${kind}/install`, { source: p.source, projectId: p.id, versionId, name: p.name });
      await waitTask(taskId);
      toast('success', `Installed ${p.name}`);
      load();
    } catch (e) { toast('error', `Couldn't install ${p.name}`, e.message); }
  };
  const toggle = async (it) => { try { await api.post(`/servers/${id}/content/${kind}/toggle`, { file: it.file }); load(); } catch (e) { toast('error', 'Couldn\'t change it', e.message); } };
  const remove = async (it) => {
    if (!(await confirm({ title: `Delete ${it.name}?`, ok: 'Delete', danger: true }))) return;
    try { await api.del(`/servers/${id}/content/${kind}?file=${encodeURIComponent(it.file)}`); load(); } catch (e) { toast('error', 'Couldn\'t delete', e.message); }
  };
  const reloadPacks = async () => { try { await api.post(`/servers/${id}/command`, { command: 'reload' }); toast('success', 'Datapacks reloaded'); } catch (e) { toast('error', 'Couldn\'t reload', e.message); } };

  return html`<div>
    ${over ? html`<${DropVeil} text=${`Drop ${word}s (.zip)`} />` : null}
    <div class="row between wrap mb-16">
      <div class="subtabs">
        <button class=${cls(view === 'installed' && 'on')} onClick=${() => setView('installed')}>On this server ${items ? html`<span class="chip sm mono">${items.length}</span>` : null}</button>
        <button class=${cls(view === 'browse' && 'on')} onClick=${() => setView('browse')}><${Icon} name="search" size=${15} />Find ${word}s</button>
      </div>
      ${kind === 'datapack' && server.status === 'online' ? html`<${Btn} size="sm" icon="restart" onClick=${reloadPacks}>Reload datapacks now<//>` : null}
    </div>
    ${view === 'browse' ? html`<${Browser} kind=${kind} serverId=${id} onInstall=${install} />` : html`
      ${uploading !== null ? html`<div class="panel pad mb-16"><${Bar} value=${uploading} pink /></div>` : null}
      <div class="grid g-side">
        <div class="panel">
          ${items === null ? html`<${Loading} />` : !items.length ? html`<div class="empty"><div class="art"><${Pixel} art="sleepy" size=${54} /></div><div class="et">No ${word}s yet</div><div>Drag .zip files onto this page, or find some on Modrinth & CurseForge.</div></div>` : items.map((it) => {
            const isActive = kind === 'resourcepack' && active === it.file;
            return html`<div class=${cls('content-row', !it.enabled && 'off')} key=${it.file}>
              <div class="c-icon"><${Img} src=${it.icon} fallback=${kind === 'datapack' ? 'box' : 'layers'} /></div>
              <div class="grow" style="min-width:0">
                <div class="c-name"><span class="ellipsis">${it.name}</span>${isActive ? html`<span class="chip sm solid-p">In use</span>` : null}${it.folder ? html`<span class="chip sm">folder</span>` : null}</div>
                <div class="c-sub"><span class="mono">${it.file}</span>${it.size ? ` · ${bytes(it.size)}` : ''} · ${ago(it.installedAt)}</div>
              </div>
              ${kind === 'resourcepack' ? html`<${Btn} size="xs" kind=${isActive ? 'p' : ''} icon=${isActive ? 'check' : 'play'} onClick=${() => onUse(isActive ? null : it.file)}>${isActive ? 'Using' : 'Use this'}<//>` : html`<${Toggle} checked=${it.enabled} onChange=${() => toggle(it)} label=${`Turn ${it.name} ${it.enabled ? 'off' : 'on'}`} />`}
              <${Btn} kind="ghost" size="xs" icon="trash" aria-label=${`Delete ${it.name}`} onClick=${() => remove(it)} />
            </div>`;
          })}
        </div>
        <div class="col gap-18">
          <${Dropzone} accept=".zip" title=${`Drop ${word} .zip files`} sub="or click to choose files" onFiles=${doUpload} />
          ${kind === 'datapack' ? html`<div class="panel pad"><div class="kicker g">About datapacks</div><p class="small dim mt-8">Datapacks add recipes, structures and game tweaks without mods. They live inside the world folder. New ones load after “Reload datapacks” or a restart.</p></div>` : null}
          ${kind === 'resourcepack' ? html`<${RpSettings} id=${id} extra=${extra} active=${active} onSaved=${load} />` : null}
        </div>
      </div>
    `}
  </div>`;
}

function RpSettings({ id, extra, active, onSaved }) {
  const [required, setRequired] = useState(!!extra.required);
  const [promptText, setPrompt] = useState('');
  const [url, setUrl] = useState('');
  useEffect(() => { setRequired(!!extra.required); }, [extra.required]);
  const save = async (body) => {
    try { const r = await api.post(`/servers/${id}/resourcepack`, body); toast('success', 'Resource pack saved', r.restartNeeded ? 'Restart the server so players get it.' : ''); onSaved(); } catch (e) { toast('error', 'Not saved', e.message); }
  };
  return html`<div class="panel pad">
    <div class="kicker">Pack settings</div>
    <div class="switch-row"><div class="txt"><div class="t">Players must accept it</div><div class="d">Anyone who declines the pack gets disconnected.</div></div><${Toggle} pink checked=${required} onChange=${(v) => { setRequired(v); if (active || extra.url) save({ file: active, url: active ? undefined : extra.url, required: v, prompt: promptText }); }} label="Require pack" /></div>
    <${Field} label="Message when asking" class="mt-12"><input class="input" placeholder="This server uses a custom look!" value=${promptText} onInput=${(e) => setPrompt(e.currentTarget.value)} onBlur=${() => (active || extra.url) && save({ file: active, url: active ? undefined : extra.url, required, prompt: promptText })} /><//>
    <hr class="sep" />
    <p class="small dim">PandA hosts the pack for you. It reaches players on your Wi-Fi straight away. For friends joining through the tunnel, paste a public download link instead (e.g. from Modrinth or Dropbox).</p>
    <div class="row mt-8"><input class="input mono" placeholder="https://…/pack.zip" value=${url} onInput=${(e) => setUrl(e.currentTarget.value)} /><${Btn} size="sm" disabled=${!/^https?:\/\//.test(url)} onClick=${() => save({ url, required, prompt: promptText })}>Use link<//></div>
    ${extra.url ? html`<div class="tiny muted mono mt-8" style="word-break:break-all">Now: ${extra.url}</div>` : null}
  </div>`;
}

export function PacksTab({ id, server, detail, reload }) {
  const [sub, setSub] = useState('datapack');
  const [active, setActive] = useState(null);
  useEffect(() => { api.get(`/servers/${id}/content/resourcepack`).then((r) => setActive(r.active)).catch(() => {}); }, [id]);
  const use = async (file) => {
    try {
      const r = await api.post(`/servers/${id}/resourcepack`, { file });
      setActive(file);
      toast('success', file ? 'Resource pack set' : 'Resource pack turned off', r.restartNeeded ? 'Restart the server so players get it.' : '');
    } catch (e) { toast('error', 'Not saved', e.message); }
  };
  return html`<div>
    <div class="tabs" style="margin-bottom:18px">
      <button class=${cls(sub === 'datapack' && 'on')} onClick=${() => setSub('datapack')}><${Icon} name="box" size=${16} />Datapacks</button>
      <button class=${cls(sub === 'resourcepack' && 'on')} onClick=${() => setSub('resourcepack')}><${Icon} name="layers" size=${16} />Resource packs</button>
    </div>
    ${sub === 'datapack' ? html`<${PackList} key="dp" id=${id} kind="datapack" server=${server} />` : html`<${PackList} key="rp" id=${id} kind="resourcepack" server=${server} active=${active} onUse=${use} />`}
  </div>`;
}
