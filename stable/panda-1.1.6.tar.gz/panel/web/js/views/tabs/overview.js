// Server overview: join ticket, health, quick actions, auto-fix indicator.
import { html, useState } from '../../lib/h.js';
import { api } from '../../lib/api.js';
import { useStore, toast } from '../../lib/store.js';
import { cls, bytes, gb, duration, ago, hostPort } from '../../lib/util.js';
import { Icon } from '../../ui/icons.js';
import { Btn, AreaChart, Seg, Toggle, Head, prompt } from '../../ui/kit.js';
import { JoinTicket } from '../../ui/join.js';
import { go } from '../../ui/brand.js';

export function AutoFixBanner({ id, autofix, onSeen }) {
  if (!autofix || !autofix.unseen || !autofix.latest) return null;
  const items = autofix.latest.items || [];
  const seen = async () => { try { await api.post(`/servers/${id}/autofix/seen`); onSeen && onSeen(); } catch {} };
  return html`<div class="autofix mb-16">
    <span class="ico"><${Icon} name="wrench" size=${18} /></span>
    <div class="grow">
      <div style="font-weight:750">PandA auto-installed ${items.length} missing ${items.length === 1 ? 'library' : 'libraries'} <span class="stamp g" style="margin-left:6px">Auto-fixed</span></div>
      <div class="small dim mt-4">${items.slice(0, 5).map((i, n) => html`${n ? ', ' : ''}<b>${i.name}</b> <span class="muted">(${i.reason})</span>`)}${items.length > 5 ? ` and ${items.length - 5} more` : ''} · ${ago(autofix.latest.at)}</div>
    </div>
    <${Btn} size="sm" onClick=${seen}>Got it<//>
  </div>`;
}

export function Findings({ id, findings }) {
  const live = useStore((s) => s.findings[id] || []);
  const [hidden, setHidden] = useState({});
  const all = [...live, ...(findings || [])];
  const seen = new Set();
  const list = all.filter((f) => { const k = `${f.id}-${f.at}`; if (seen.has(k) || hidden[f.id]) return false; seen.add(k); return Date.now() - f.at < 30 * 60e3; }).slice(0, 3);
  if (!list.length) return null;
  return html`<div class="col gap-6 mb-16">
    ${list.map((f) => html`<div class=${cls('alert', f.level === 'error' ? 'error' : f.level === 'warn' ? 'warn' : 'info')}>
      <span class="ai"><${Icon} name=${f.level === 'info' ? 'info' : 'warn'} /></span>
      <div class="grow"><div class="at">${f.title} <span class="stamp k" style="margin-left:6px">PandA Doctor</span></div><div class="ab">${f.hint}</div></div>
      ${f.action ? html`<a class="btn sm" href=${`#/s/${id}/${f.action.tab}`}>${f.action.label}</a>` : null}
      <${Btn} kind="ghost" size="sm" icon="x" aria-label="Dismiss" onClick=${() => setHidden((h) => ({ ...h, [f.id]: true }))} />
    </div>`)}
  </div>`;
}

const QUICK = [
  { label: 'Make it day', icon: 'sun', cmd: 'time set day' },
  { label: 'Make it night', icon: 'moon', cmd: 'time set night' },
  { label: 'Clear weather', icon: 'sun', cmd: 'weather clear' },
  { label: 'Make it rain', icon: 'rain', cmd: 'weather rain' },
  { label: 'Save the world', icon: 'save', cmd: 'save-all' },
  { label: 'Heal everyone', icon: 'heart', cmd: 'effect give @a minecraft:instant_health 1 10' },
  { label: 'Feed everyone', icon: 'leaf', cmd: 'effect give @a minecraft:saturation 1 10' },
  { label: 'Kill dropped items', icon: 'trash', cmd: 'kill @e[type=item]' },
];

export function OverviewTab({ id, server: s, detail, reload }) {
  const live = useStore((st) => st.sstats[id] || []);
  const [quick, setQuick] = useState(detail.quick);
  const stats = [...(detail.stats || []), ...live.filter((p) => !detail.stats.length || p.t > detail.stats[detail.stats.length - 1].t)].slice(-150);
  const online = s.status === 'online';
  const run = async (cmd, label) => {
    try { await api.post(`/servers/${id}/command`, { command: cmd }); toast('success', label || 'Done'); } catch (e) { toast('error', 'Couldn\'t do that', e.message); }
  };
  const setProp = async (key, value, qk) => {
    setQuick((q) => ({ ...q, [qk]: value }));
    try {
      if (key === 'white-list') await api.post(`/servers/${id}/whitelist`, { enabled: value });
      else await api.put(`/servers/${id}/properties`, { changes: { [key]: String(value) } });
      if (key === 'gamemode' && online) toast('info', 'Saved', 'New players get this mode. Existing players keep theirs.');
    } catch (e) { toast('error', 'Not saved', e.message); }
  };
  const announce = async () => {
    const msg = await prompt({ title: 'Announce to everyone', body: 'Shows up big in the middle of every player\'s screen.', placeholder: 'Server restarting in 5 minutes!', ok: 'Announce', icon: 'megaphone' });
    if (msg) { try { await api.post(`/servers/${id}/broadcast`, { message: msg, style: 'title' }); toast('success', 'Announced'); } catch (e) { toast('error', 'Not sent', e.message); } }
  };
  const memLimit = (s.memoryMb || 0) * 1048576;
  const lastMem = stats.length ? stats[stats.length - 1].mem : 0;

  return html`<div>
    <${AutoFixBanner} id=${id} autofix=${detail.autofix} onSeen=${reload} />
    <${Findings} id=${id} findings=${detail.findings} />

    <div class="hero-strip">
      <${JoinTicket} server=${s} pink=${s.accent !== 'green'} />
      <div class="panel">
        <div class="panel-h"><h3><${Icon} name="info" size=${16} />At a glance</h3>${s.status === 'online' ? html`<span class="chip g sm">${(s.players || []).length}/${s.maxPlayers} players</span>` : null}</div>
        <div class="panel-b">
          <dl class="kv">
            <dt>Status</dt><dd>${s.status}${s.status === 'online' && s.readyAt ? ` · ${duration(Date.now() - s.readyAt)}` : ''}</dd>
            <dt>Java port</dt><dd>${s.port}</dd>
            ${s.bedrock && s.bedrock.enabled ? html`<dt>Bedrock port</dt><dd>${s.bedrock.port} (UDP)</dd>` : null}
            <dt>Your network</dt><dd>${detail.join ? hostPort(detail.join.lan) : '…'}</dd>
            <dt>Memory limit</dt><dd>${gb(s.memoryMb)}</dd>
            <dt>Java</dt><dd>${detail.meta.javaOverride || detail.meta.javaMajor || 'auto'}</dd>
            <dt>Auto start</dt><dd>${detail.meta.autoStart ? 'yes' : 'no'} · auto-restart ${detail.meta.autoRestart ? 'on' : 'off'}</dd>
            ${detail.meta.lastAutoBackup ? html`<dt>Last auto backup</dt><dd>${ago(detail.meta.lastAutoBackup)}</dd>` : null}
          </dl>
        </div>
      </div>
    </div>

    <div class="grid g2">
      <div class="panel">
        <div class="panel-h"><h3><${Icon} name="cpu" size=${16} />Processor</h3><span class="mono small green">${online || s.status === 'starting' ? `${Math.round(s.cpu || 0)}%` : '—'}</span></div>
        <div class="panel-b">${stats.length ? html`<${AreaChart} series=${[{ data: stats.map((p) => p.cpu), color: '#8df35b' }]} h=${110} />` : html`<div class="small muted" style="height:110px;display:grid;place-items:center">Start the server to see live usage.</div>`}</div>
      </div>
      <div class="panel">
        <div class="panel-h"><h3><${Icon} name="ram" size=${16} />Memory</h3><span class="mono small pink">${lastMem ? `${bytes(lastMem)} / ${gb(s.memoryMb)}` : '—'}</span></div>
        <div class="panel-b">${stats.length ? html`<${AreaChart} series=${[{ data: stats.map((p) => p.mem), color: '#ff6fae' }]} max=${Math.max(memLimit * 1.15, ...stats.map((p) => p.mem))} h=${110} fmt=${(v) => bytes(v)} />` : html`<div class="small muted" style="height:110px;display:grid;place-items:center">Start the server to see live usage.</div>`}</div>
      </div>
    </div>

    <div class="grid g-side mt-24">
      <div class="panel">
        <div class="panel-h"><h3><${Icon} name="bolt" size=${16} />Quick actions</h3>${!online ? html`<span class="small muted">Start the server to use these</span>` : null}</div>
        <div class="panel-b">
          <div class="qa-grid">
            ${QUICK.map((q) => html`<button class="qa" disabled=${!online} onClick=${() => run(q.cmd, q.label)}><span class="ic"><${Icon} name=${q.icon} size=${20} /></span>${q.label}</button>`)}
            <button class="qa" disabled=${!online} onClick=${announce}><span class="ic" style="color:var(--blossom)"><${Icon} name="megaphone" size=${20} /></span>Announce</button>
          </div>
          <hr class="sep" />
          <div class="grid g2">
            <div><div class="lbl mb-8">Difficulty</div><${Seg} small value=${quick.difficulty} onChange=${(v) => setProp('difficulty', v, 'difficulty')} options=${['peaceful', 'easy', 'normal', 'hard'].map((v) => ({ value: v, label: v[0].toUpperCase() + v.slice(1) }))} /></div>
            <div><div class="lbl mb-8">Default game mode</div><${Seg} small pink value=${quick.gamemode} onChange=${(v) => setProp('gamemode', v, 'gamemode')} options=${['survival', 'creative', 'adventure'].map((v) => ({ value: v, label: v[0].toUpperCase() + v.slice(1) }))} /></div>
          </div>
          <div class="switch-row mt-8"><div class="txt"><div class="t">Whitelist</div><div class="d">Only players on the list can join.</div></div><${Toggle} checked=${quick.whitelist} onChange=${(v) => setProp('white-list', v, 'whitelist')} label="Whitelist" /></div>
        </div>
      </div>
      <div class="panel">
        <div class="panel-h"><h3><${Icon} name="users" size=${16} />Who's on</h3><a class="small" href=${`#/s/${id}/players`}>Manage</a></div>
        <div class="plist">
          ${online && (s.players || []).length ? s.players.slice(0, 8).map((p) => html`<div class="prow"><${Head} name=${p.name} /><div class="grow"><div class="pn">${p.name}${p.bedrock ? html`<span class="chip sm p">Bedrock</span>` : null}</div><div class="ps">joined ${ago(p.joinedAt)}</div></div></div>`)
            : html`<div class="small muted" style="padding:20px 16px">${online ? 'Nobody is online. Share the join address!' : 'The server is offline.'}</div>`}
        </div>
      </div>
    </div>
  </div>`;
}

export { go };
