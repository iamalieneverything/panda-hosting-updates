// server.properties as a visual editor (every setting explained) + gamerule toggles.
import { html, useState, useEffect, useMemo } from '../../lib/h.js';
import { api } from '../../lib/api.js';
import { toast, waitTask, useStore } from '../../lib/store.js';
import { cls, motdParts } from '../../lib/util.js';
import { Icon } from '../../ui/icons.js';
import { Btn, Toggle, Tip, Loading, Range, Bar, confirm } from '../../ui/kit.js';

// Which world this is, a warning when a modpack world was made the wrong way, and a fresh start.
function WorldCard({ id, server }) {
  const [w, setW] = useState(null);
  const [seed, setSeed] = useState('');
  const [taskId, setTaskId] = useState(null);
  const task = useStore((s) => (taskId ? s.tasks[taskId] : null));
  const load = () => api.get(`/servers/${id}/world`).then(setW).catch(() => {});
  useEffect(() => { load(); }, [id, server.status]);
  // Always render the frame (see UpdatesCard in settings.js).
  if (!w) return html`<div class="panel pad mb-16"><${Loading} /></div>`;
  const running = server.status === 'online';
  const busy = !!taskId || ['starting', 'stopping', 'installing'].includes(server.status);

  const reset = async (fix) => {
    const what = fix ? `a new ${w.expected.label} world, the way the modpack is meant to start` : 'a brand-new world';
    const ok = await confirm({
      title: fix ? `Make the ${w.expected.label} world?` : 'Make a new world?',
      body: `${running ? 'The server stops, then ' : ''}PandA saves your current world as a backup (you can bring it back from the Backups tab) and makes ${what}.${running ? ' The server starts again by itself.' : ' It is created the next time the server starts.'}`,
      ok: 'Make new world',
      danger: true,
    });
    if (!ok) return;
    try {
      const r = await api.post(`/servers/${id}/world/reset`, { useModpack: true, seed: !fix && seed.trim() ? seed.trim() : undefined });
      setTaskId(r.taskId);
      await waitTask(r.taskId);
      toast('success', 'New world ready', running ? 'The server is starting with it.' : 'It is made when the server starts.');
      setSeed('');
      load();
    } catch (e) { toast('error', 'Couldn\'t make a new world', e.message); }
    setTaskId(null);
  };

  return html`<div class="panel pad mb-16">
    ${w.mismatch && w.exists ? html`<div class="alert warn mb-16">
      <span class="ai"><${Icon} name="warn" /></span>
      <div class="grow"><div class="at">This world should be ${w.expected.label}</div><div class="ab">The modpack starts players on ${w.expected.label}, but this world was made as a ${w.levelLabel.toLowerCase()} world (a bug in older PandA versions). Make a new world to fix it — your current one is kept as a backup.</div></div>
      <${Btn} kind="p" size="sm" loading=${!!taskId} disabled=${busy} onClick=${() => reset(true)}>Fix it<//>
    </div>` : null}
    <div class="row between wrap gap-14">
      <div>
        <div class="kicker">World</div>
        <div class="c-name mt-4">${w.levelName}</div>
        <div class="small muted">${w.levelLabel}${w.mismatch && !w.exists ? ` → ${w.expected.label} (set for the first start)` : ''}${w.exists ? '' : ' · made on the next start'}${w.seed ? ` · seed ${w.seed}` : ''}</div>
      </div>
      <div class="row gap-8 wrap">
        <input class="input mono" style="width:190px" placeholder="New seed (optional)" value=${seed} onInput=${(e) => setSeed(e.currentTarget.value)} />
        <${Btn} kind="danger" icon="restart" loading=${!!taskId} disabled=${busy} onClick=${() => reset(false)}>Make a new world<//>
      </div>
    </div>
    ${taskId ? html`<div class="mt-12"><div class="small mb-8">${task ? task.stage : 'Working…'}</div><${Bar} value=${task ? task.progress : null} busy=${!task || task.progress == null} /></div>` : null}
  </div>`;
}

const GROUP_ORDER = ['Players', 'Gameplay', 'World', 'Performance', 'Network', 'Resource pack', 'Other'];
const GROUP_ICON = { Players: 'users', Gameplay: 'swords', World: 'globe', Performance: 'bolt', Network: 'network', 'Resource pack': 'layers', Other: 'more' };
const WIDE = new Set(['motd', 'level-seed', 'generator-settings', 'resource-pack', 'resource-pack-prompt', 'initial-enabled-packs', 'initial-disabled-packs', 'bug-report-link']);

function Motd({ text }) {
  return html`<div class="motd-preview" style="margin-top:8px;padding:6px 10px"><div class="sm" style="margin:0">${motdParts(text).map((p) => html`<span style=${`color:${p.color};${p.bold ? 'font-weight:700;' : ''}${p.italic ? 'font-style:italic;' : ''}`}>${p.text}</span>`)}</div></div>`;
}

function PropControl({ m, value, onChange }) {
  if (m.managed) return html`<span class="chip sm"><${Icon} name="lock" size=${11} />Managed by PandA</span>`;
  if (m.type === 'bool') return html`<${Toggle} checked=${value === 'true'} onChange=${(v) => onChange(String(v))} label=${m.label} />`;
  if (m.type === 'enum') return html`<select class="select" value=${value} onChange=${(e) => onChange(e.currentTarget.value)}>${m.options.map((o) => html`<option value=${o.value}>${o.label}</option>`)}${!m.options.some((o) => o.value === value) && value ? html`<option value=${value}>${value}</option>` : null}</select>`;
  if (m.type === 'int' && m.slider) return html`<div class="row" style="width:240px"><${Range} value=${Number(value) || m.min} min=${m.min} max=${m.max} onInput=${(v) => onChange(String(v))} /><span class="mono small" style="width:28px;text-align:right">${value}</span></div>`;
  if (m.type === 'int') return html`<input class="input num mono" inputmode="numeric" value=${value} onInput=${(e) => onChange(e.currentTarget.value.replace(/[^\d-]/g, ''))} />`;
  return html`<input class="input" value=${value} onInput=${(e) => onChange(e.currentTarget.value)} />`;
}

function Properties({ id, server }) {
  const [data, setData] = useState(null);
  const [changes, setChanges] = useState({});
  const [q, setQ] = useState('');
  const [adv, setAdv] = useState(false);
  const [saving, setSaving] = useState(false);
  const load = () => api.get(`/servers/${id}/properties`).then((d) => { setData(d); setChanges({}); }).catch((e) => toast('error', 'Couldn\'t load settings', e.message));
  useEffect(() => { load(); }, [id]);
  const groups = useMemo(() => {
    if (!data) return [];
    const ql = q.trim().toLowerCase();
    const list = data.meta.filter((m) => !m.secret && !(m.managed && m.key !== 'server-port') && (adv || !m.advanced || ql) && (!ql || m.label.toLowerCase().includes(ql) || m.key.includes(ql) || (m.help || '').toLowerCase().includes(ql)));
    return GROUP_ORDER.map((g) => ({ g, items: list.filter((m) => (m.group || 'Other') === g) })).filter((x) => x.items.length);
  }, [data, q, adv]);
  if (!data) return html`<${Loading} />`;
  const val = (k) => (k in changes ? changes[k] : data.values[k] ?? (data.meta.find((m) => m.key === k) || {}).def ?? '');
  const set = (k, v) => setChanges((c) => { const n = { ...c }; if (String(data.values[k] ?? '') === v) delete n[k]; else n[k] = v; return n; });
  const dirty = Object.keys(changes).length;
  const save = async () => {
    setSaving(true);
    try {
      const r = await api.put(`/servers/${id}/properties`, { changes });
      toast('success', 'Settings saved', r.restartNeeded ? 'Restart the server to apply them.' : 'They apply next time the server starts.');
      load();
    } catch (e) { toast('error', 'Not saved', e.message); }
    setSaving(false);
  };
  return html`<div>
    <div class="row wrap gap-14 mb-16">
      <div class="input-wrap grow" style="max-width:420px"><span class="ic-l"><${Icon} name="search" size=${15} /></span><input class="input" placeholder="Search settings… (try “fly” or “spawn”)" value=${q} onInput=${(e) => setQ(e.currentTarget.value)} /></div>
      <label class="row gap-6 small dim"><${Toggle} checked=${adv} onChange=${setAdv} label="Show advanced" />Show advanced</label>
      ${!data.generated ? html`<span class="chip a">Start the server once to unlock every setting for this version</span>` : null}
    </div>
    ${groups.map(({ g, items }) => html`<section class="prop-group panel pad">
      <h3><${Icon} name=${GROUP_ICON[g] || 'more'} size=${16} />${g}</h3>
      <div class="prop-grid">
        ${items.map((m) => html`<div class=${cls('prop', WIDE.has(m.key) && 'wide', m.key in changes && 'changed')}>
          <div class="pl">
            <div class="t">${m.label}<${Tip} title=${m.label} text=${m.help} k=${`${m.key}${m.def !== undefined && m.def !== '' ? ` · default ${m.def}` : ''}`} /></div>
            <div class="k">${m.key}</div>
            ${m.key === 'motd' ? html`<${Motd} text=${val('motd')} />` : null}
          </div>
          <div class="pc">
            <${PropControl} m=${m} value=${String(val(m.key))} onChange=${(v) => set(m.key, v)} />
            ${m.managed ? html`<a class="small" href=${`#/s/${id}/settings`}>Change</a>` : null}
          </div>
        </div>`)}
      </div>
    </section>`)}
    ${!groups.length ? html`<div class="panel pad muted">No setting matches “${q}”.</div>` : null}
    ${dirty ? html`<div class="savebar">
      <span class="sq" style="background:var(--blossom)"></span>
      <div class="grow"><b>${dirty} unsaved ${dirty === 1 ? 'change' : 'changes'}</b><div class="small muted">${server.status === 'online' ? 'Most settings need a restart to apply.' : 'Applies next start.'}</div></div>
      <${Btn} kind="ghost" onClick=${() => setChanges({})}>Discard<//>
      <${Btn} kind="p" icon="save" loading=${saving} onClick=${save}>Save<//>
    </div>` : null}
  </div>`;
}

function Gamerules({ id, server }) {
  const [data, setData] = useState(null);
  const [q, setQ] = useState('');
  const [drafts, setDrafts] = useState({});
  const load = () => api.get(`/servers/${id}/gamerules`).then(setData).catch((e) => toast('error', 'Couldn\'t load gamerules', e.message));
  useEffect(() => { load(); }, [id, server.status]);
  if (!data) return html`<${Loading} />`;
  const setRule = async (key, value) => {
    setData((d) => ({ ...d, rules: d.rules.map((r) => (r.key === key ? { ...r, value: String(value), pending: !d.online } : r)) }));
    try {
      const r = await api.put(`/servers/${id}/gamerules`, { key, value: String(value) });
      if (r.pending) toast('info', 'Saved for next start', 'The server is off, so PandA will apply this when it starts.');
    } catch (e) { toast('error', 'Not changed', e.message); load(); }
  };
  const ql = q.trim().toLowerCase();
  const rules = data.rules.filter((r) => !ql || r.label.toLowerCase().includes(ql) || r.key.toLowerCase().includes(ql) || r.help.toLowerCase().includes(ql));
  const cats = [...new Set(rules.map((r) => r.cat))];
  const pending = data.rules.filter((r) => r.pending).length;
  return html`<div>
    <div class=${cls('alert mb-16', data.online ? 'ok' : 'info')}>
      <span class="ai"><${Icon} name=${data.online ? 'bolt' : 'clock'} /></span>
      <div class="grow"><div class="at">${data.online ? 'Changes apply instantly' : 'The server is off'}</div><div class="ab">${data.online ? 'Flip a switch and it changes in the game right away.' : `Changes are saved and applied when the server starts${pending ? ` (${pending} waiting)` : ''}.`}${!data.fromWorld ? ' Showing default values — start the server once to read your world\'s real values.' : ''}</div></div>
    </div>
    <div class="input-wrap mb-16" style="max-width:420px"><span class="ic-l"><${Icon} name="search" size=${15} /></span><input class="input" placeholder="Search gamerules… (try “inventory”)" value=${q} onInput=${(e) => setQ(e.currentTarget.value)} /></div>
    ${cats.map((c) => html`<div class="prop-group">
      <h3>${c}</h3>
      <div class="rule-grid">
        ${rules.filter((r) => r.cat === c).map((r) => html`<div class=${cls('rule', r.type === 'bool' && r.value === 'true' && 'on')}>
          <div class="grow" style="min-width:0">
            <div class="rt"><span class="ellipsis">${r.label}</span><${Tip} title=${r.label} text=${r.help} k=${r.key} />${r.pending ? html`<span class="stamp a">Next start</span>` : null}</div>
            <div class="rk">${r.key}</div>
          </div>
          ${r.type === 'bool'
            ? html`<${Toggle} checked=${r.value === 'true'} onChange=${(v) => setRule(r.key, v)} label=${r.label} />`
            : html`<input class="input" inputmode="numeric" value=${drafts[r.key] ?? r.value} onInput=${(e) => setDrafts((d) => ({ ...d, [r.key]: e.currentTarget.value.replace(/[^\d-]/g, '') }))}
                onBlur=${() => { const v = drafts[r.key]; if (v !== undefined && v !== '' && v !== r.value) setRule(r.key, v); }}
                onKeyDown=${(e) => e.key === 'Enter' && e.currentTarget.blur()} />`}
        </div>`)}
      </div>
    </div>`)}
  </div>`;
}

export function WorldTab({ id, server }) {
  const [sub, setSub] = useState('props');
  return html`<div>
    <${WorldCard} id=${id} server=${server} />
    <div class="tabs" style="margin-bottom:18px">
      <button class=${cls(sub === 'props' && 'on')} onClick=${() => setSub('props')}><${Icon} name="sliders" size=${16} />Server settings</button>
      <button class=${cls(sub === 'rules' && 'on')} onClick=${() => setSub('rules')}><${Icon} name="list" size=${16} />Gamerules</button>
    </div>
    ${sub === 'props' ? html`<${Properties} id=${id} server=${server} />` : html`<${Gamerules} id=${id} server=${server} />`}
  </div>`;
}
