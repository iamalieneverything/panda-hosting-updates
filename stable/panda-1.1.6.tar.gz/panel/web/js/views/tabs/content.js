// Mods / plugins: installed list, drag & drop, auto dependency resolver, updates, built-in browser.
import { html, useState, useEffect, useMemo } from '../../lib/h.js';
import { api, upload } from '../../lib/api.js';
import { toast, waitTask, useStore } from '../../lib/store.js';
import { cls, bytes, ago } from '../../lib/util.js';
import { Icon, Pixel } from '../../ui/icons.js';
import { Btn, Toggle, Dropzone, useWindowDrop, DropVeil, Loading, confirm, Bar, Img } from '../../ui/kit.js';
import { Browser } from '../browse.js';
import { AutoFixBanner } from './overview.js';

const SRC_LABEL = { modrinth: 'Modrinth', curseforge: 'CurseForge', upload: 'Uploaded', manual: 'Manual', modpack: 'Modpack', geysermc: 'GeyserMC' };

export function DepsResult({ result, onClose }) {
  if (!result) return null;
  const deps = result.dependencies || [];
  return html`<div class=${cls('mb-16', deps.length ? 'autofix' : 'alert ok')}>
    ${deps.length ? html`<span class="ico"><${Icon} name="chain" size=${18} /></span>` : html`<span class="ai"><${Icon} name="check" /></span>`}
    <div class="grow">
      <div style="font-weight:750">Installed ${(result.installed || []).map((i) => i.name).join(', ')}${deps.length ? html` <span class="stamp g" style="margin-left:6px">+${deps.length} auto</span>` : ''}</div>
      ${deps.length ? html`<div class="small dim mt-4">PandA also installed what it needs: ${deps.map((d, i) => html`${i ? ', ' : ''}<b>${d.name}</b>`)}</div>` : null}
      ${(result.warnings || []).length ? html`<div class="small amber mt-4">${result.warnings.join(' ')}</div>` : null}
      ${result.restartNeeded ? html`<div class="small muted mt-4">Restart the server to load it.</div>` : null}
    </div>
    <${Btn} kind="ghost" size="sm" icon="x" aria-label="Close" onClick=${onClose} />
  </div>`;
}

export function ContentTab({ id, server, detail, reload, kind }) {
  const [view, setView] = useState('installed');
  const [items, setItems] = useState(null);
  const [filter, setFilter] = useState('');
  const [updates, setUpdates] = useState(null);
  const [checking, setChecking] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [uploading, setUploading] = useState(null);
  const [result, setResult] = useState(null);
  const bump = useStore((s) => s.autofixBump[id] || 0);
  const word = kind === 'plugin' ? 'plugin' : 'mod';
  const load = () => api.get(`/servers/${id}/content/${kind}`).then((r) => setItems(r.items)).catch((e) => toast('error', 'Couldn\'t load', e.message));
  useEffect(() => { load(); }, [id, kind, bump]);

  const doUpload = async (files) => {
    setUploading(0);
    try {
      const r = await upload(`/servers/${id}/content/${kind}/upload`, files, setUploading);
      if (r.added.length) toast('success', `Added ${r.added.length} ${word}${r.added.length === 1 ? '' : 's'}`, r.added.join(', '));
      if (r.rejected.length) toast('error', 'Skipped some files', `Only .jar files go here: ${r.rejected.join(', ')}`);
      load();
      if (r.taskId) {
        setScanning(true);
        const res = await waitTask(r.taskId).catch(() => null);
        setScanning(false);
        if (res && res.fixed.length) { reload(); load(); }
      }
    } catch (e) { toast('error', 'Upload failed', e.message); }
    setUploading(null);
  };
  const over = useWindowDrop(doUpload, '.jar', view === 'installed');

  const install = async (p, versionId) => {
    try {
      const { taskId } = await api.post(`/servers/${id}/content/${kind}/install`, { source: p.source, projectId: p.id, versionId, name: p.name });
      const res = await waitTask(taskId);
      setResult(res);
      toast('success', `Installed ${p.name}`, res.dependencies.length ? `Plus ${res.dependencies.length} required: ${res.dependencies.map((d) => d.name).join(', ')}` : server.status === 'online' ? 'Restart to load it.' : '');
      load();
    } catch (e) { toast('error', `Couldn't install ${p.name}`, e.message); }
  };

  const scan = async () => {
    setScanning(true);
    try {
      const { taskId } = await api.post(`/servers/${id}/content/scan`);
      const r = await waitTask(taskId);
      if (r.fixed.length) { toast('success', `Fixed ${r.fixed.length} missing ${r.fixed.length === 1 ? 'library' : 'libraries'}`, r.fixed.map((f) => f.name).join(', ')); reload(); }
      else if (r.unresolved.length) toast('warn', 'Some libraries couldn\'t be found', r.unresolved.map((u) => `${u.display} (for ${u.requiredBy.slice(0, 2).join(', ')})`).join('; '));
      else toast('success', 'Nothing missing', `All ${word}s have what they need.`);
      if (r.clientOnly && r.clientOnly.length) toast('warn', 'Client-only mods found', `${r.clientOnly.map((c) => c.name).join(', ')} only work in the game, not on a server. Consider turning them off.`);
      load();
    } catch (e) { toast('error', 'Check failed', e.message); }
    setScanning(false);
  };

  const checkUpdates = async () => {
    setChecking(true);
    try { const r = await api.get(`/servers/${id}/content/${kind}/updates`); setUpdates(r.updates); if (!r.updates.length) toast('success', 'Everything is up to date'); } catch (e) { toast('error', 'Couldn\'t check', e.message); }
    setChecking(false);
  };

  const toggle = async (it) => {
    try { await api.post(`/servers/${id}/content/${kind}/toggle`, { file: it.file }); load(); } catch (e) { toast('error', 'Couldn\'t change it', e.message); }
  };
  const remove = async (it) => {
    if (!(await confirm({ title: `Remove ${it.name}?`, body: it.auto ? 'PandA added this because another mod needs it. Removing it may stop that mod from working.' : 'The file is deleted from the server.', ok: 'Remove', danger: true }))) return;
    try { await api.del(`/servers/${id}/content/${kind}?file=${encodeURIComponent(it.file)}`); load(); } catch (e) { toast('error', 'Couldn\'t remove', e.message); }
  };
  const update = async (u) => {
    try {
      const { taskId } = await api.post(`/servers/${id}/content/${kind}/install`, { source: u.source, projectId: u.projectId, versionId: u.versionId, name: u.name });
      await waitTask(taskId);
      setUpdates((list) => list.filter((x) => x !== u));
      toast('success', `Updated ${u.name}`, `${u.from} → ${u.to}`);
      load();
    } catch (e) { toast('error', 'Update failed', e.message); }
  };

  const list = useMemo(() => (items || []).filter((i) => !filter || i.name.toLowerCase().includes(filter.toLowerCase()) || i.file.toLowerCase().includes(filter.toLowerCase())), [items, filter]);
  const upFor = (it) => updates && updates.find((u) => u.file === it.file);
  const autoCount = (items || []).filter((i) => i.auto).length;

  return html`<div>
    ${over ? html`<${DropVeil} text=${`Drop ${word}s to add them`} />` : null}
    <div class="row between wrap mb-16">
      <div class="subtabs">
        <button class=${cls(view === 'installed' && 'on')} onClick=${() => setView('installed')}><${Icon} name="puzzle" size=${15} />Installed ${items ? html`<span class="chip sm mono">${items.length}</span>` : null}</button>
        <button class=${cls(view === 'browse' && 'on')} onClick=${() => setView('browse')}><${Icon} name="search" size=${15} />Find ${word}s</button>
      </div>
      ${view === 'installed' ? html`<div class="btn-row">
        <${Btn} size="sm" icon="chain" loading=${scanning} onClick=${scan}>Check for missing libraries<//>
        <${Btn} size="sm" icon="download" loading=${checking} onClick=${checkUpdates}>Check updates<//>
      </div>` : null}
    </div>

    <${DepsResult} result=${result} onClose=${() => setResult(null)} />
    <${AutoFixBanner} id=${id} autofix=${detail.autofix} onSeen=${reload} />

    ${view === 'browse' ? html`<${Browser} kind=${kind} serverId=${id} onInstall=${install} />` : html`
      ${uploading !== null ? html`<div class="panel pad mb-16"><div class="row between small mb-8"><span>Uploading…</span><span class="mono">${Math.round(uploading * 100)}%</span></div><${Bar} value=${uploading} pink /></div>` : null}
      ${scanning ? html`<div class="alert info mb-16"><span class="ai"><${Icon} name="chain" /></span><div><div class="at">Checking for missing libraries…</div><div class="ab">PandA reads every ${word} and installs anything they need.</div></div></div>` : null}
      ${updates && updates.length ? html`<div class="alert info mb-16"><span class="ai"><${Icon} name="download" /></span><div class="grow"><div class="at">${updates.length} update${updates.length === 1 ? '' : 's'} available</div><div class="ab">${updates.map((u) => u.name).join(', ')}</div></div><${Btn} size="sm" kind="p" onClick=${async () => { for (const u of [...updates]) await update(u); }}>Update all<//></div>` : null}
      <div class="grid g-side">
        <div class="panel">
          <div class="panel-h">
            <div class="input-wrap grow" style="max-width:360px"><span class="ic-l"><${Icon} name="search" size=${14} /></span><input class="input" style="height:34px" placeholder=${`Filter ${word}s…`} value=${filter} onInput=${(e) => setFilter(e.currentTarget.value)} /></div>
            ${autoCount ? html`<span class="chip g sm" title="Installed automatically as dependencies"><${Icon} name="chain" size=${12} />${autoCount} auto</span>` : null}
          </div>
          ${items === null ? html`<${Loading} />` : !list.length ? html`<div class="empty"><div class="art"><${Pixel} art="sleepy" size=${54} /></div><div class="et">${items.length ? 'No match' : `No ${word}s yet`}</div><div>${items.length ? 'Try another filter.' : html`Drag .jar files anywhere on this page, or <button class="linkish" onClick=${() => setView('browse')}>browse Modrinth & CurseForge</button>.`}</div></div>` : list.map((it) => {
            const up = upFor(it);
            return html`<div class=${cls('content-row', !it.enabled && 'off')} key=${it.file}>
              <div class="c-icon"><${Img} src=${it.icon} /></div>
              <div class="grow" style="min-width:0">
                <div class="c-name"><span class="ellipsis">${it.name}</span>
                  ${it.auto ? html`<span class="chip sm g" title=${it.requiredBy.length ? `Needed by ${it.requiredBy.join(', ')}` : 'Installed automatically'}><${Icon} name="chain" size=${11} />Auto-installed${it.requiredBy.length ? ` · for ${it.requiredBy[0]}` : ''}</span>` : null}
                  ${!it.enabled ? html`<span class="chip sm">Off</span>` : null}
                </div>
                <div class="c-sub"><span class="mono">${it.file}</span>${it.version ? ` · ${it.version}` : ''} · ${SRC_LABEL[it.source] || it.source}${it.size ? ` · ${bytes(it.size)}` : ''} · ${ago(it.installedAt)}</div>
              </div>
              ${up ? html`<${Btn} size="xs" kind="p" icon="download" onClick=${() => update(up)}>${up.to}<//>` : null}
              <${Toggle} checked=${it.enabled} onChange=${() => toggle(it)} label=${`Turn ${it.name} ${it.enabled ? 'off' : 'on'}`} />
              <${Btn} kind="ghost" size="xs" icon="trash" aria-label=${`Remove ${it.name}`} onClick=${() => remove(it)} />
            </div>`;
          })}
        </div>
        <div class="col gap-18">
          <${Dropzone} accept=".jar" title=${`Drop ${word} files`} sub="or click to pick .jar files. PandA checks what they need and installs it." onFiles=${doUpload} />
          <div class="panel pad">
            <div class="kicker g">Auto dependencies</div>
            <p class="small dim mt-8">When a ${word} needs a library (like Fabric API or Cloth Config), PandA finds and installs it for you — when you install, when you upload, and if the server crashes because something is missing.</p>
            <div class="small mt-12">Items marked <span class="chip sm g"><${Icon} name="chain" size=${11} />Auto-installed</span> were added this way.</div>
          </div>
          ${server.status === 'online' ? html`<div class="alert warn"><span class="ai"><${Icon} name="restart" /></span><div><div class="at">Changes need a restart</div><div class="ab">${kind === 'plugin' ? 'Plugins' : 'Mods'} load when the server starts.</div></div></div>` : null}
        </div>
      </div>
    `}
  </div>`;
}
