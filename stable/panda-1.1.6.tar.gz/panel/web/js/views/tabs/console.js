// Live console: colored output, error/warning highlighting, collapsible stack traces.
// Lines are appended straight to the DOM so even huge modpack boots stay smooth.
import { html, useState, useEffect, useRef } from '../../lib/h.js';
import { api } from '../../lib/api.js';
import { onLog, toast } from '../../lib/store.js';
import { cls, clock, debounce } from '../../lib/util.js';
import { Icon } from '../../ui/icons.js';
import { Btn } from '../../ui/kit.js';
import { Findings } from './overview.js';

const MAX_NODES = 2500;
const CONT = /^\s+at |^\s*\.\.\. \d+ more|^\s*Caused by:|^\s+Suppressed:|^\t|^\s{4,}\S/;
const HEAD = /^((?:\[[^\]]*\]\s?)+):?\s?(.*)$/;
const PURE_TIME = /^\[(?:\d{1,2}[A-Za-z]{3}\d{4} )?\d{2}:\d{2}:\d{2}(?:[.,]\d+)?(?: (?:INFO|WARN|WARNING|ERROR|FATAL|DEBUG|TRACE))?\]:?\s?/;
const URL_RE = /(https?:\/\/[^\s"'<>)\]]+)/g;

function span(cl, text) { const s = document.createElement('span'); if (cl) s.className = cl; s.textContent = text; return s; }

function appendRich(parent, text) {
  let last = 0;
  for (const m of text.matchAll(URL_RE)) {
    if (m.index > last) parent.appendChild(document.createTextNode(text.slice(last, m.index)));
    const a = document.createElement('a');
    a.className = 'url'; a.href = m[0]; a.target = '_blank'; a.rel = 'noopener noreferrer'; a.textContent = m[0];
    parent.appendChild(a);
    last = m.index + m[0].length;
  }
  if (last < text.length) parent.appendChild(document.createTextNode(text.slice(last)));
}

function lineNode(l) {
  const div = document.createElement('div');
  const lv = l.src === 'panda' ? 'p' : l.src === 'input' ? 'in' : l.level === 'error' ? 'e' : l.level === 'warn' ? 'w' : l.level === 'debug' ? 'd' : '';
  div.className = `ln ${lv}`;
  div.appendChild(span('ts', clock(l.t)));
  if (l.src === 'panda') div.appendChild(span('lv', 'PANDA'));
  else if (l.src === 'geyser') div.appendChild(span('lv', 'BEDROCK'));
  else if (lv === 'e') div.appendChild(span('lv', 'ERROR'));
  else if (lv === 'w') div.appendChild(span('lv', 'WARN'));

  let text = l.text;
  if (l.src === 'server' || l.src === 'geyser') {
    text = text.replace(PURE_TIME, '');
    const m = text.match(HEAD);
    let msg = text;
    if (m && m[1].length < 120) {
      div.appendChild(span('tag', `${m[1].trim()} `));
      msg = m[2];
    }
    let c;
    if ((c = msg.match(/^(\[Not Secure\] )?<([^>]+)> (.*)$/))) {
      div.classList.add('c');
      div.appendChild(document.createTextNode('<'));
      div.appendChild(span('pl', c[2]));
      div.appendChild(document.createTextNode('> '));
      const cm = span('cm', '');
      appendRich(cm, c[3]);
      div.appendChild(cm);
    } else if ((c = msg.match(/^(\S+) (joined|left) the game$/))) {
      div.classList.add('c');
      div.appendChild(span('pl', c[1]));
      div.appendChild(span(c[2] === 'joined' ? 'join' : 'muted', ` ${c[2]} the game`));
    } else {
      if (/^Done \([\d.,]+s\)! For help/.test(msg)) div.classList.add('ready');
      if (/^\[(Server|Rcon)\] /.test(msg)) div.classList.add('c');
      appendRich(div, msg);
    }
  } else {
    appendRich(div, text);
  }
  return div;
}

export function ConsoleTab({ id, server, detail }) {
  const box = useRef();
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [wrap, setWrap] = useState(true);
  const [stuck, setStuck] = useState(true);
  const [counts, setCounts] = useState({ w: 0, e: 0 });
  const [cmd, setCmd] = useState('');
  const [empty, setEmpty] = useState(true);
  const hist = useRef([]);
  const hIdx = useRef(-1);
  const stuckRef = useRef(true);
  const searchRef = useRef('');
  const all = useRef([]);

  useEffect(() => {
    const el = box.current;
    let lastNode = null;
    let lastSeq = 0;
    let ready = false;
    const early = [];
    const c = { w: 0, e: 0 };

    const matches = (node) => !searchRef.current || node.textContent.toLowerCase().includes(searchRef.current);

    const append = (lines) => {
      const frag = document.createDocumentFragment();
      for (const l of lines) {
        if (l.n <= lastSeq) continue;
        lastSeq = l.n;
        all.current.push(l);
        if (all.current.length > 5000) all.current.splice(0, 1000);
        const node = lineNode(l);
        const prevLv = lastNode && (lastNode.classList.contains('e') || lastNode.classList.contains('w') || (lastNode.parentElement && lastNode.parentElement.classList && lastNode.parentElement.classList.contains('more')));
        if (lastNode && prevLv && CONT.test(l.text) && l.src === 'server') {
          // Fold stack traces under the line that started them.
          let grp = lastNode.closest ? lastNode.closest('.grp') : null;
          if (!grp) {
            grp = document.createElement('div');
            grp.className = 'grp';
            const host = lastNode.parentNode;
            host.insertBefore(grp, lastNode);
            grp.appendChild(lastNode);
            const more = document.createElement('div');
            more.className = 'more';
            grp.appendChild(more);
            const t = document.createElement('button');
            t.className = 'tgl';
            t.type = 'button';
            t.dataset.n = '0';
            t.onclick = () => { grp.classList.toggle('open'); t.textContent = grp.classList.contains('open') ? 'HIDE' : `+${t.dataset.n} LINES`; };
            lastNode.appendChild(t);
            if (lastNode.classList.contains('e')) grp.classList.add('has-e'); else grp.classList.add('has-w', 'w-grp');
          }
          node.classList.add(grp.classList.contains('has-e') ? 'e' : 'w');
          grp.querySelector(':scope > .more').appendChild(node);
          const t = grp.querySelector(':scope > .ln .tgl');
          if (t) { t.dataset.n = String(Number(t.dataset.n) + 1); if (!grp.classList.contains('open')) t.textContent = `+${t.dataset.n} LINES`; }
          if (searchRef.current && matches(node)) grp.classList.add('hit');
          continue;
        }
        if (node.classList.contains('e')) c.e++;
        else if (node.classList.contains('w')) c.w++;
        if (searchRef.current && matches(node)) node.classList.add('hit');
        frag.appendChild(node);
        lastNode = node;
      }
      el.appendChild(frag);
      while (el.childElementCount > MAX_NODES) el.firstElementChild.remove();
      if (stuckRef.current) el.scrollTop = el.scrollHeight;
      setCounts({ ...c });
      setEmpty(el.childElementCount === 0);
    };

    const off = onLog(id, (lines) => { if (ready) append(lines); else early.push(...lines); });
    api.get(`/servers/${id}/console`).then(({ lines }) => {
      append(lines);
      ready = true;
      append(early);
      requestAnimationFrame(() => { el.scrollTop = el.scrollHeight; });
    }).catch(() => { ready = true; });

    const onScroll = () => {
      const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 30;
      stuckRef.current = atBottom;
      setStuck(atBottom);
    };
    el.addEventListener('scroll', onScroll, { passive: true });
    return () => { off(); el.removeEventListener('scroll', onScroll); };
  }, [id]);

  const applySearch = useRef(debounce((term) => {
    const el = box.current;
    searchRef.current = term.toLowerCase();
    if (!el) return;
    el.classList.toggle('searching', !!term);
    for (const node of el.children) node.classList.toggle('hit', !!term && node.textContent.toLowerCase().includes(searchRef.current));
  }, 160)).current;

  const send = async (e) => {
    e && e.preventDefault();
    const c = cmd.trim();
    if (!c) return;
    hist.current = [c, ...hist.current.filter((x) => x !== c)].slice(0, 50);
    hIdx.current = -1;
    setCmd('');
    stuckRef.current = true;
    try { await api.post(`/servers/${id}/command`, { command: c }); } catch (x) { toast('error', 'Not sent', x.message); }
  };

  const download = () => {
    const text = all.current.map((l) => `${new Date(l.t).toISOString()} ${l.src === 'panda' ? '[PandA] ' : ''}${l.text}`).join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type: 'text/plain' }));
    a.download = `${server.name.replace(/[^a-z0-9]+/gi, '-')}-console.log`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  };

  const clear = () => { box.current.innerHTML = ''; setCounts({ w: 0, e: 0 }); setEmpty(true); };
  const running = ['online', 'starting'].includes(server.status);

  return html`<div>
    <${Findings} id=${id} findings=${detail.findings} />
    <div class="console-wrap" style="position:relative">
      <div class="console-bar">
        <div class="filt" role="group" aria-label="Filter">
          <button class=${cls(filter === 'all' && 'on')} onClick=${() => setFilter('all')}>All</button>
          <button class=${cls(filter === 'warn' && 'on')} onClick=${() => setFilter('warn')}>Warnings <span class="n w">${counts.w}</span></button>
          <button class=${cls(filter === 'error' && 'on')} onClick=${() => setFilter('error')}>Errors <span class="n e">${counts.e}</span></button>
          <button class=${cls(filter === 'chat' && 'on')} onClick=${() => setFilter('chat')}>Chat</button>
          <button class=${cls(filter === 'panda' && 'on')} onClick=${() => setFilter('panda')}>PandA</button>
        </div>
        <div class="input-wrap grow" style="min-width:160px;max-width:320px">
          <span class="ic-l"><${Icon} name="search" size=${14} /></span>
          <input class="input" placeholder="Search the log…" value=${search} onInput=${(e) => { setSearch(e.currentTarget.value); applySearch(e.currentTarget.value); }} />
        </div>
        <span class="grow"></span>
        <${Btn} kind="ghost" size="sm" icon=${wrap ? 'menu' : 'chevR'} title="Wrap long lines" onClick=${() => setWrap(!wrap)}>${wrap ? 'Wrap' : 'No wrap'}<//>
        <${Btn} kind="ghost" size="sm" icon="download" title="Download log" aria-label="Download log" onClick=${download} />
        <${Btn} kind="ghost" size="sm" icon="trash" title="Clear view" aria-label="Clear view" onClick=${clear} />
      </div>
      <div ref=${box} class=${cls('console', !wrap && 'nowrap', filter !== 'all' && `f-${filter}`)} role="log" aria-live="off"></div>
      ${empty ? html`<div class="console-empty" style="position:absolute;inset:60px 0 70px;display:grid;place-items:center;pointer-events:none">${running ? 'Waiting for output…' : 'The server is offline. Press Start and its output appears here — errors in red, warnings in yellow.'}</div>` : null}
      ${!stuck ? html`<div class="jump"><${Btn} kind="p" size="sm" icon="chevD" onClick=${() => { const el = box.current; el.scrollTop = el.scrollHeight; stuckRef.current = true; setStuck(true); }}>Jump to latest<//></div>` : null}
      <form class="console-input" onSubmit=${send}>
        <span class="prompt">/</span>
        <input class="input" placeholder=${running ? 'Type a command (optional — the buttons in other tabs do this for you)' : 'Start the server to send commands'} disabled=${!running} value=${cmd}
          onInput=${(e) => setCmd(e.currentTarget.value)}
          onKeyDown=${(e) => {
            if (e.key === 'ArrowUp' && hist.current.length) { e.preventDefault(); hIdx.current = Math.min(hIdx.current + 1, hist.current.length - 1); setCmd(hist.current[hIdx.current]); }
            if (e.key === 'ArrowDown') { e.preventDefault(); hIdx.current = Math.max(hIdx.current - 1, -1); setCmd(hIdx.current < 0 ? '' : hist.current[hIdx.current]); }
          }} />
        <${Btn} kind="g" type="submit" icon="chevR" disabled=${!running || !cmd.trim()}>Send<//>
      </form>
    </div>
  </div>`;
}
