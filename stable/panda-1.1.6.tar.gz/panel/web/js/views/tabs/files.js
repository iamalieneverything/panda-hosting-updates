// File manager with drag & drop upload and a built-in text editor.
import { html, useState, useEffect, useRef } from '../../lib/h.js';
import { api, upload } from '../../lib/api.js';
import { toast } from '../../lib/store.js';
import { bytes, date } from '../../lib/util.js';
import { Icon } from '../../ui/icons.js';
import { Btn, Modal, Loading, confirm, prompt, useWindowDrop, DropVeil, Bar } from '../../ui/kit.js';

const TEXT = /\.(txt|properties|json|json5|yml|yaml|toml|cfg|conf|ini|log|md|mcmeta|mcfunction|js|zs|sh|bat|csv|xml|lang|snbt|secret|list|options)$/i;

function Editor({ id, path, onClose }) {
  const [text, setText] = useState(null);
  const [orig, setOrig] = useState('');
  const [saving, setSaving] = useState(false);
  const area = useRef();
  useEffect(() => {
    api.get(`/servers/${id}/files/read?path=${encodeURIComponent(path)}`).then((r) => { setText(r.content); setOrig(r.content); }).catch((e) => { toast('error', 'Can\'t open', e.message); onClose(); });
  }, [path]);
  const save = async () => {
    setSaving(true);
    try { await api.put(`/servers/${id}/files/write`, { path, content: text }); setOrig(text); toast('success', 'Saved', path); } catch (e) { toast('error', 'Not saved', e.message); }
    setSaving(false);
  };
  const close = async () => { if (text !== orig && !(await confirm({ title: 'Close without saving?', ok: 'Discard changes', danger: true }))) return; onClose(); };
  return html`<${Modal} title=${path.split('/').pop()} size="xwide" icon="edit" onClose=${close}
    footer=${html`<span class="small muted mono grow">${path}</span><${Btn} kind="ghost" onClick=${close}>Close<//><${Btn} kind="g" icon="save" loading=${saving} disabled=${text === orig} onClick=${save}>Save<//>`}>
    ${text === null ? html`<${Loading} />` : html`<textarea ref=${area} class="editor" spellcheck="false" value=${text}
      onInput=${(e) => setText(e.currentTarget.value)}
      onKeyDown=${(e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); save(); }
        if (e.key === 'Tab') { e.preventDefault(); const el = e.currentTarget; const s = el.selectionStart; const v = el.value; el.value = `${v.slice(0, s)}  ${v.slice(el.selectionEnd)}`; el.selectionStart = el.selectionEnd = s + 2; setText(el.value); }
      }}></textarea>`}
  <//>`;
}

export function FilesTab({ id }) {
  const [path, setPath] = useState('');
  const [data, setData] = useState(null);
  const [editing, setEditing] = useState(null);
  const [uploading, setUploading] = useState(null);
  const input = useRef();
  const load = (p = path) => api.get(`/servers/${id}/files?path=${encodeURIComponent(p)}`).then((d) => { setData(d); setPath(d.path); }).catch((e) => toast('error', 'Can\'t open folder', e.message));
  useEffect(() => { load(''); }, [id]);
  const join = (name) => (path ? `${path}/${name}` : name);
  const doUpload = async (files) => {
    setUploading(0);
    try { const r = await upload(`/servers/${id}/files/upload?path=${encodeURIComponent(path)}`, files, setUploading); toast('success', `Uploaded ${r.added.length} file${r.added.length === 1 ? '' : 's'}`); load(); } catch (e) { toast('error', 'Upload failed', e.message); }
    setUploading(null);
  };
  const over = useWindowDrop(doUpload, null, true);
  const mkdir = async () => { const n = await prompt({ title: 'New folder', placeholder: 'folder name', ok: 'Create', icon: 'folder' }); if (n) { try { await api.post(`/servers/${id}/files/mkdir`, { path: join(n) }); load(); } catch (e) { toast('error', 'Couldn\'t create', e.message); } } };
  const newFile = async () => { const n = await prompt({ title: 'New text file', placeholder: 'notes.txt', ok: 'Create', icon: 'file' }); if (n) { try { await api.put(`/servers/${id}/files/write`, { path: join(n), content: '' }); load(); setEditing(join(n)); } catch (e) { toast('error', 'Couldn\'t create', e.message); } } };
  const rename = async (e) => { const n = await prompt({ title: `Rename ${e.name}`, value: e.name, ok: 'Rename', icon: 'edit' }); if (n && n !== e.name) { try { await api.post(`/servers/${id}/files/rename`, { from: join(e.name), to: join(n) }); load(); } catch (x) { toast('error', 'Couldn\'t rename', x.message); } } };
  const del = async (e) => {
    if (!(await confirm({ title: `Delete ${e.name}?`, body: e.dir ? 'The whole folder and everything in it is deleted. This can\'t be undone (unless you have a backup).' : 'This can\'t be undone (unless you have a backup).', ok: 'Delete', danger: true }))) return;
    try { await api.post(`/servers/${id}/files/delete`, { paths: [join(e.name)] }); load(); } catch (x) { toast('error', 'Couldn\'t delete', x.message); }
  };
  const open = (e) => {
    if (e.dir) return load(join(e.name));
    if (TEXT.test(e.name) || (e.size !== null && e.size < 200000 && !/\.(jar|zip|dat|mca|png|jpg|gz|exe|dll|so)$/i.test(e.name))) setEditing(join(e.name));
    else window.open(`/api/servers/${id}/files/download?path=${encodeURIComponent(join(e.name))}`, '_blank');
  };
  const parts = path ? path.split('/') : [];
  return html`<div>
    ${over ? html`<${DropVeil} text=${`Upload to /${path}`} />` : null}
    <div class="panel">
      <div class="fm-bar">
        <div class="crumbs-path grow">
          <button onClick=${() => load('')}><${Icon} name="server" size=${14} /></button>
          ${parts.map((p, i) => html`<span class="muted">/</span><button onClick=${() => load(parts.slice(0, i + 1).join('/'))}>${p}</button>`)}
        </div>
        <${Btn} size="sm" icon="upload" onClick=${() => input.current.click()}>Upload<//>
        <input ref=${input} type="file" multiple class="hide" onChange=${(e) => { doUpload([...e.currentTarget.files]); e.currentTarget.value = ''; }} />
        <${Btn} size="sm" icon="folder" onClick=${mkdir}>New folder<//>
        <${Btn} size="sm" icon="file" onClick=${newFile}>New file<//>
        <${Btn} size="sm" kind="ghost" icon="restart" aria-label="Refresh" onClick=${() => load()} />
      </div>
      ${uploading !== null ? html`<div style="padding:10px 14px"><${Bar} value=${uploading} pink thin /></div>` : null}
      ${!data ? html`<${Loading} />` : html`
        ${path ? html`<div class="frow" onClick=${() => load(parts.slice(0, -1).join('/'))} style="cursor:pointer"><span class="fic dir"><${Icon} name="chevU" size=${16} /></span><span class="fname">..</span></div>` : null}
        ${data.entries.map((e) => html`<div class="frow" key=${e.name}>
          <span class=${`fic ${e.dir ? 'dir' : ''}`}><${Icon} name=${e.dir ? 'folder' : 'file'} size=${16} /></span>
          <span class="fname" onClick=${() => open(e)} title=${e.name}>${e.name}</span>
          <span class="fsize">${e.dir ? '' : bytes(e.size)}</span>
          <span class="fdate">${e.mtime ? date(e.mtime) : ''}</span>
          <span class="facts">
            ${!e.dir ? html`<a class="btn ghost xs icon" title="Download" aria-label="Download" href=${`/api/servers/${id}/files/download?path=${encodeURIComponent(join(e.name))}`}><${Icon} name="download" size=${13} /></a>` : null}
            <${Btn} kind="ghost" size="xs" icon="edit" title="Rename" aria-label="Rename" onClick=${() => rename(e)} />
            <${Btn} kind="ghost" size="xs" icon="trash" title="Delete" aria-label="Delete" onClick=${() => del(e)} />
          </span>
        </div>`)}
        ${!data.entries.length ? html`<div class="small muted" style="padding:20px 16px">This folder is empty. Drop files here to upload.</div>` : null}
      `}
    </div>
    <p class="small muted mt-12">Tip: you rarely need this — mods, packs, settings and backups all have their own tabs.</p>
    ${editing ? html`<${Editor} id=${id} path=${editing} onClose=${() => setEditing(null)} />` : null}
  </div>`;
}
