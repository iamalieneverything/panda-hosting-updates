// Backups: one-click snapshots, schedules, restore.
import { html, useState, useEffect } from '../../lib/h.js';
import { api, upload } from '../../lib/api.js';
import { toast, waitTask, useStore } from '../../lib/store.js';
import { bytes, date, ago } from '../../lib/util.js';
import { Icon } from '../../ui/icons.js';
import { Btn, Loading, confirm, Bar, Field, Seg } from '../../ui/kit.js';

const REASON = { manual: 'Manual', auto: 'Scheduled', 'pre-update': 'Before update', uploaded: 'Uploaded', 'pre-reset': 'Before new world' };

export function BackupsTab({ id, server, detail, reload }) {
  const [list, setList] = useState(null);
  const [note, setNote] = useState('');
  const [taskId, setTaskId] = useState(null);
  const [sched, setSched] = useState(detail.meta.schedule || {});
  const [up, setUp] = useState(null);
  const sendFile = async (file) => {
    if (!file) return;
    if (!/\.zip$/i.test(file.name)) { toast('error', 'That\'s not a backup', 'PandA backups are .zip files.'); return; }
    setUp(0);
    try {
      await upload(`/servers/${id}/backups/upload`, [file], setUp);
      toast('success', 'Backup added', 'Press Restore next to it to bring it back.');
      load();
    } catch (e) { toast('error', 'Upload failed', e.message); }
    setUp(null);
  };
  const task = useStore((s) => (taskId ? s.tasks[taskId] : null));
  const load = () => api.get(`/servers/${id}/backups`).then((r) => setList(r.backups)).catch((e) => toast('error', 'Couldn\'t load backups', e.message));
  useEffect(() => { load(); }, [id]);

  const make = async () => {
    try {
      const r = await api.post(`/servers/${id}/backups`, { note });
      setTaskId(r.taskId);
      await waitTask(r.taskId);
      toast('success', 'Backup saved');
      setNote('');
      load();
    } catch (e) { toast('error', 'Backup failed', e.message); }
    setTaskId(null);
  };
  const restore = async (b) => {
    if (!['offline', 'crashed'].includes(server.status)) { toast('error', 'Stop the server first', 'Restoring while it runs would break the world.'); return; }
    if (!(await confirm({ title: 'Restore this backup?', body: `Your world and settings go back to ${date(b.createdAt)}. Everything since then is replaced. Tip: make a backup of the current state first.`, ok: 'Restore', danger: true }))) return;
    try { const r = await api.post(`/servers/${id}/backups/restore`, { file: b.file }); setTaskId(r.taskId); await waitTask(r.taskId); toast('success', 'Backup restored'); reload(); } catch (e) { toast('error', 'Restore failed', e.message); }
    setTaskId(null);
  };
  const del = async (b) => {
    if (!(await confirm({ title: 'Delete this backup?', ok: 'Delete', danger: true }))) return;
    try { await api.del(`/servers/${id}/backups?file=${encodeURIComponent(b.file)}`); load(); } catch (e) { toast('error', 'Couldn\'t delete', e.message); }
  };
  const saveSched = async (patch) => {
    const next = { ...sched, ...patch };
    setSched(next);
    try { await api.patch(`/servers/${id}`, { schedule: next }); toast('success', 'Schedule saved'); } catch (e) { toast('error', 'Not saved', e.message); }
  };
  const total = (list || []).reduce((n, b) => n + b.size, 0);

  return html`<div class="grid g-side">
    <div class="panel">
      <div class="panel-h"><h3><${Icon} name="archive" size=${16} />Backups ${list ? html`<span class="chip sm mono">${list.length} · ${bytes(total)}</span>` : null}</h3></div>
      ${taskId ? html`<div class="panel-b" style="border-bottom:1px solid var(--line)"><div class="row between small mb-8"><span>${task ? task.stage : 'Working…'}</span><span class="mono">${task && task.progress ? `${Math.round(task.progress * 100)}%` : ''}</span></div><${Bar} value=${task ? task.progress : 0} busy=${!task || !task.progress} /></div>` : null}
      ${list === null ? html`<${Loading} />` : !list.length ? html`<div class="small muted" style="padding:22px 16px">No backups yet. Make one now — it only takes a moment.</div>` : html`<table class="table">
        <thead><tr><th>When</th><th>Type</th><th>Size</th><th style="text-align:right">Actions</th></tr></thead>
        <tbody>${list.map((b) => html`<tr>
          <td><b>${date(b.createdAt)}</b><div class="tiny muted">${ago(b.createdAt)}${b.note ? ` · ${b.note}` : ''}</div></td>
          <td><span class=${`chip sm ${b.reason === 'auto' ? 'g' : b.reason === 'pre-update' || b.reason === 'uploaded' || b.reason === 'pre-reset' ? 'a' : 'p'}`}>${REASON[b.reason] || b.reason}</span></td>
          <td class="mono small">${bytes(b.size)}</td>
          <td><div class="row gap-4" style="justify-content:flex-end">
            <${Btn} size="xs" icon="restart" disabled=${!!taskId} onClick=${() => restore(b)}>Restore<//>
            <a class="btn xs icon" title="Download" aria-label="Download" href=${`/api/servers/${id}/backups/download?file=${encodeURIComponent(b.file)}`}><${Icon} name="download" size=${13} /></a>
            <${Btn} kind="ghost" size="xs" icon="trash" aria-label="Delete" onClick=${() => del(b)} />
          </div></td>
        </tr>`)}</tbody>
      </table>`}
    </div>
    <div class="col gap-18">
      <div class="panel pad corners">
        <div class="kicker">Back up now</div>
        <p class="small dim mt-8">Saves the world, settings, mods and plugins into one file. Safe to do while people are playing.</p>
        <${Field} label="Note (optional)" class="mt-12"><input class="input" maxlength="80" placeholder="Before the big build" value=${note} onInput=${(e) => setNote(e.currentTarget.value)} /><//>
        <${Btn} kind="p" size="lg" class="block mt-12" icon="save" loading=${!!taskId} onClick=${make}>Make a backup<//>
      </div>
      <div class="panel pad">
        <div class="kicker">Bring a backup back</div>
        <p class="small dim mt-8">Got a backup .zip you downloaded earlier (before reinstalling, or from another PandA)? Upload it, then press Restore. Works best on a server with the same type and Minecraft version.</p>
        <label class="btn block mt-12" style=${up !== null ? 'pointer-events:none;opacity:.7' : ''}><${Icon} name="upload" size=${16} />${up !== null ? `Uploading… ${Math.round(up * 100)}%` : 'Upload a backup (.zip)'}<input type="file" accept=".zip" style="display:none" onChange=${(e) => { sendFile(e.currentTarget.files[0]); e.currentTarget.value = ''; }} /></label>
        ${up !== null ? html`<div class="mt-8"><${Bar} value=${up} /></div>` : null}
      </div>
      <div class="panel pad">
        <div class="kicker g">Automatic backups</div>
        <${Field} label="How often" class="mt-12"><${Seg} block value=${sched.backupHours || 0} onChange=${(v) => saveSched({ backupHours: v })} options=${[{ value: 0, label: 'Off' }, { value: 6, label: '6h' }, { value: 12, label: '12h' }, { value: 24, label: 'Daily' }]} /><//>
        <${Field} label="Keep the newest" class="mt-12" hint="Older automatic backups are deleted to save space."><${Seg} block pink value=${sched.backupKeep || 5} onChange=${(v) => saveSched({ backupKeep: v })} options=${[3, 5, 10, 20].map((n) => ({ value: n, label: String(n) }))} /><//>
      </div>
    </div>
  </div>`;
}
