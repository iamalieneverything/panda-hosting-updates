// Per-server settings: memory, startup, network/Bedrock, Java, version changes, delete.
import { html, useState, useEffect, useMemo } from '../../lib/h.js';
import { api } from '../../lib/api.js';
import { toast, waitTask, refreshServers } from '../../lib/store.js';
import { cls, gb, TYPE_LABEL } from '../../lib/util.js';
import { Icon } from '../../ui/icons.js';
import { Btn, Field, Toggle, Range, Seg, Tip, Picker, confirm, Check } from '../../ui/kit.js';
import { go } from '../../ui/brand.js';

async function resizeIcon(file) {
  const img = await new Promise((resolve, reject) => { const i = new Image(); i.onload = () => resolve(i); i.onerror = reject; i.src = URL.createObjectURL(file); });
  const c = document.createElement('canvas'); c.width = 64; c.height = 64;
  const s = Math.min(img.width, img.height);
  c.getContext('2d').drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, 64, 64);
  return c.toDataURL('image/png');
}

function Section({ title, icon, children, kicker }) {
  return html`<section class="panel">
    <div class="panel-h"><h3><${Icon} name=${icon} size=${16} />${title}</h3>${kicker || null}</div>
    <div class="panel-b">${children}</div>
  </section>`;
}

export function ServerSettingsTab({ id, server: s, detail, reload }) {
  const m = detail.meta;
  const [name, setName] = useState(s.name);
  const [mem, setMem] = useState(s.memoryMb);
  const [port, setPort] = useState(String(s.port));
  const [bport, setBport] = useState(String((s.bedrock && s.bedrock.port) || 19132));
  const [custom, setCustom] = useState(m.customJvmArgs || '');
  const [versions, setVersions] = useState([]);
  const [newVer, setNewVer] = useState(s.mcVersion);
  const [busy, setBusy] = useState(null);
  const [delBackups, setDelBackups] = useState(false);
  const offline = ['offline', 'crashed'].includes(s.status);

  useEffect(() => {
    if (s.modpack || !s.type || s.type === 'pending') return;
    api.get(`/versions/${s.type}`).then(({ versions: v }) => setVersions(v.filter((x) => x.stable).slice(0, 120))).catch(() => {});
  }, [s.type]);

  const patch = async (body, msg = 'Saved') => {
    try {
      const r = await api.patch(`/servers/${id}`, body);
      toast('success', msg, r.restartNeeded && s.status === 'online' ? 'Restart the server to apply.' : '');
      reload(); refreshServers();
      return true;
    } catch (e) { toast('error', 'Not saved', e.message); return false; }
  };
  const setIcon = async (file) => {
    try { await api.post(`/servers/${id}/icon`, { dataUrl: await resizeIcon(file) }); toast('success', 'Icon updated'); refreshServers(); reload(); } catch (e) { toast('error', 'Icon not saved', e.message); }
  };
  const bedrock = async (on) => {
    setBusy('bedrock');
    try { const { taskId } = await api.post(`/servers/${id}/bedrock`, { enabled: on }); const r = await waitTask(taskId); toast('success', on ? 'Bedrock support added' : 'Bedrock support removed', (r && r.warning) || (s.status === 'online' ? 'Restart the server to apply.' : '')); reload(); refreshServers(); } catch (e) { toast('error', 'Couldn\'t change Bedrock support', e.message); }
    setBusy(null);
  };
  const reinstall = async (mcVersion) => {
    const changing = mcVersion && mcVersion !== s.mcVersion;
    if (!(await confirm({ title: changing ? `Switch to Minecraft ${mcVersion}?` : 'Reinstall server software?', body: changing ? 'PandA makes a backup first. Going to a newer version is usually fine; going back to an older one can break your world. Mods and plugins may need updates too.' : 'Downloads the server software again. Your world, mods and settings are kept. A backup is made first.', ok: changing ? 'Switch version' : 'Reinstall', danger: changing })) ) return;
    setBusy('reinstall');
    try { const { taskId } = await api.post(`/servers/${id}/reinstall`, { mcVersion: changing ? mcVersion : undefined }); await waitTask(taskId); toast('success', changing ? `Now on ${mcVersion}` : 'Reinstalled'); reload(); refreshServers(); } catch (e) { toast('error', 'That didn\'t work', e.message); }
    setBusy(null);
  };
  const remove = async () => {
    if (!(await confirm({ title: `Delete ${s.name}?`, body: `The world, mods and settings are deleted forever${delBackups ? ', including all backups' : ' (backups are kept)'}.`, ok: 'Delete forever', danger: true, typeToConfirm: s.name }))) return;
    try { await api.del(`/servers/${id}?backups=${delBackups ? '1' : '0'}`); toast('success', `${s.name} deleted`); refreshServers(); go('/'); } catch (e) { toast('error', 'Couldn\'t delete', e.message); }
  };
  const total = detail.totalMemMb;
  const vItems = useMemo(() => versions.map((v) => ({ id: v.id, label: v.id, tag: v.id === s.mcVersion ? 'current' : null })), [versions]);

  return html`<div class="grid g2" style="align-items:start">
    <div class="col gap-18">
      <${Section} title="General" icon="edit">
        <${Field} label="Server name"><div class="row"><input class="input" maxlength="48" value=${name} onInput=${(e) => setName(e.currentTarget.value)} /><${Btn} kind="g" disabled=${!name.trim() || name === s.name} onClick=${() => patch({ name })}>Save<//></div><//>
        <div class="grid g2 mt-16">
          <${Field} label="Card color"><${Seg} value=${s.accent || 'green'} onChange=${(v) => patch({ accent: v }, 'Color changed')} options=${[{ value: 'green', label: 'Bamboo' }, { value: 'pink', label: 'Blossom' }]} /><//>
          <${Field} label="Server icon" hint="Shown in the Minecraft server list."><label class="btn sm"><${Icon} name="upload" size=${15} />Choose image<input type="file" accept="image/*" class="hide" onChange=${(e) => e.currentTarget.files[0] && setIcon(e.currentTarget.files[0])} /></label><//>
        </div>
      <//>

      <${Section} title="Memory" icon="ram" kicker=${html`<span class="mono pink">${gb(mem)}</span>`}>
        <${Range} pink value=${mem} min=${1024} max=${Math.max(2048, Math.floor((total * 0.9) / 512) * 512)} step=${512} onInput=${setMem} />
        <div class="ticks"><span>1 GB</span><span>${gb(Math.floor(total / 2 / 512) * 512)}</span><span>${gb(total)}</span></div>
        <div class="row between mt-12"><span class="small muted">Vanilla/Paper 2–4 GB · mods 4–6 GB · huge packs 8–10 GB</span><${Btn} kind="g" size="sm" disabled=${mem === s.memoryMb} onClick=${() => patch({ memoryMb: mem }, 'Memory changed')}>Save<//></div>
        <div class="switch-row mt-8"><div class="txt"><div class="t">Reserve all memory at start <${Tip} text="Grabs the full amount right away. Slightly smoother for big modpacks, but the memory is taken even when the server is quiet." /></div></div><${Toggle} checked=${m.reserveMemory} onChange=${(v) => patch({ reserveMemory: v })} label="Reserve memory" /></div>
      <//>

      <${Section} title="Startup & recovery" icon="power">
        <div class="switch-row" style="padding-top:0"><div class="txt"><div class="t">Start with PandA</div><div class="d">Starts on its own when this machine turns on.</div></div><${Toggle} checked=${m.autoStart} onChange=${(v) => patch({ autoStart: v })} label="Auto start" /></div>
        <div class="switch-row"><div class="txt"><div class="t">Restart after a crash</div><div class="d">Tries up to 3 times in 10 minutes.</div></div><${Toggle} checked=${m.autoRestart} onChange=${(v) => patch({ autoRestart: v })} label="Auto restart" /></div>
        <div class="switch-row"><div class="txt"><div class="t">Fix missing libraries automatically</div><div class="d">Installs missing mod/plugin dependencies before start and after crashes.</div></div><${Toggle} checked=${m.autoFixDeps} onChange=${(v) => patch({ autoFixDeps: v })} label="Auto fix dependencies" /></div>
        <${Field} label="Scheduled restart" class="mt-12" hint="Players get a 60-second warning. Keeps long-running modded servers fresh.">
          <${Seg} value=${(m.schedule && m.schedule.restartHours) || 0} onChange=${(v) => patch({ schedule: { ...m.schedule, restartHours: v } })} options=${[{ value: 0, label: 'Never' }, { value: 6, label: 'Every 6h' }, { value: 12, label: '12h' }, { value: 24, label: 'Daily' }]} />
        <//>
      <//>
    </div>

    <div class="col gap-18">
      <${Section} title="Network" icon="network">
        <${Field} label="Java port" tip="The port Java players connect to. 25565 is the default — then friends don't need to type it." hint=${s.port === 25565 ? 'Default port — friends don\'t need to type it.' : 'Friends add :' + s.port + ' after the address.'}>
          <div class="row"><input class="input mono" style="max-width:140px" inputmode="numeric" value=${port} onInput=${(e) => setPort(e.currentTarget.value.replace(/\D/g, ''))} /><${Btn} kind="g" disabled=${Number(port) === s.port} onClick=${() => patch({ port: Number(port) }, 'Port changed')}>Save<//></div>
        <//>
        <div class="switch-row mt-12"><div class="txt"><div class="t">Reachable through the tunnel</div><div class="d">Give this server a public address when the PandA Tunnel or router forwarding is on.</div></div><${Toggle} checked=${m.publicAccess} onChange=${(v) => patch({ publicAccess: v })} label="Public access" /></div>
        <div class="switch-row"><div class="txt"><div class="t"><${Icon} name="gamepad" size=${15} />Bedrock players</div><div class="d">Geyser lets phones, tablets and consoles join. ${s.type === 'vanilla' || s.type === 'forge' ? 'On this flavour they need a Java account.' : ''}</div></div>${busy === 'bedrock' ? html`<${Icon} name="restart" class="spin" />` : html`<${Toggle} pink checked=${s.bedrock && s.bedrock.enabled} onChange=${bedrock} label="Bedrock" />`}</div>
        ${s.bedrock && s.bedrock.enabled ? html`<${Field} label="Bedrock port (UDP)" class="mt-12"><div class="row"><input class="input mono" style="max-width:140px" inputmode="numeric" value=${bport} onInput=${(e) => setBport(e.currentTarget.value.replace(/\D/g, ''))} /><${Btn} kind="g" disabled=${Number(bport) === s.bedrock.port} onClick=${() => patch({ bedrockPort: Number(bport) }, 'Bedrock port changed')}>Save<//></div><//>` : null}
      <//>

      <${Section} title="Software" icon="box">
        <dl class="kv"><dt>Type</dt><dd>${s.modpack ? `${s.modpack.name} (${TYPE_LABEL[s.type]})` : TYPE_LABEL[s.type]}</dd><dt>Minecraft</dt><dd>${s.mcVersion}</dd>${s.loaderVersion ? html`<dt>Loader</dt><dd>${s.loaderVersion}</dd>` : null}${m.build ? html`<dt>Build</dt><dd>${m.build}</dd>` : null}</dl>
        ${!s.modpack && vItems.length ? html`<${Field} label="Change Minecraft version" class="mt-16" hint=${offline ? 'A backup is made first.' : 'Stop the server first.'}>
          <div class="row"><div class="grow"><${Picker} items=${vItems} value=${newVer} onChange=${setNewVer} /></div><${Btn} kind="p" disabled=${!offline || newVer === s.mcVersion} loading=${busy === 'reinstall'} onClick=${() => reinstall(newVer)}>Switch<//></div>
        <//>` : null}
        <div class="row mt-16"><${Btn} icon="restart" disabled=${!offline} loading=${busy === 'reinstall'} onClick=${() => reinstall(null)}>Reinstall server software<//><${Tip} text="Fixes a broken or damaged server. Keeps your world, mods and settings." /></div>
      <//>

      <${Section} title="Advanced" icon="coffee">
        <${Field} label="Java version" tip="PandA picks the right Java for your Minecraft version automatically. Only change this if a mod asks for a different one.">
          <${Seg} value=${m.javaOverride || 0} onChange=${(v) => patch({ javaOverride: v || null }, 'Java changed')} options=${[{ value: 0, label: `Auto (${m.javaMajor || '?'})` }, { value: 8, label: '8' }, { value: 17, label: '17' }, { value: 21, label: '21' }, { value: 25, label: '25' }]} />
        <//>
        <${Field} label="Performance flags" class="mt-16" tip="“Optimized” uses Aikar's flags — the well-known garbage collector tuning almost every host uses.">
          <${Seg} pink value=${m.jvmFlags} onChange=${(v) => patch({ jvmFlags: v })} options=${[{ value: 'aikar', label: 'Optimized' }, { value: 'none', label: 'Plain' }]} />
        <//>
        <${Field} label="Extra Java arguments" class="mt-16" hint="For experts. Leave empty if you're not sure.">
          <div class="row"><input class="input mono" placeholder="-Dsome.flag=true" value=${custom} onInput=${(e) => setCustom(e.currentTarget.value)} /><${Btn} disabled=${custom === (m.customJvmArgs || '')} onClick=${() => patch({ customJvmArgs: custom })}>Save<//></div>
        <//>
      <//>

      <section class="panel" style="border-color:rgba(255,77,99,.4)">
        <div class="panel-h"><h3 class="red"><${Icon} name="warn" size=${16} />Danger zone</h3></div>
        <div class="panel-b">
          <p class="small dim">Deleting removes the world and everything in it. Make a backup first if you might want it back.</p>
          <div class="mt-12"><${Check} checked=${delBackups} onChange=${setDelBackups}>Also delete this server's backups<//></div>
          <${Btn} kind="danger solid" icon="trash" class="mt-16" onClick=${remove}>Delete server<//>
        </div>
      </section>
    </div>
  </div>`;
}

export { cls };
