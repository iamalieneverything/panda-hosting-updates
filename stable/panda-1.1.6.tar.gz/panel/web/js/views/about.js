// About PandA — and the two people behind the P and the A.
import { html } from '../lib/h.js';
import { useStore } from '../lib/store.js';
import { Icon, Pixel } from '../ui/icons.js';

export function AboutPage() {
  const info = useStore((s) => s.info);
  return html`<div class="page">
    <div class="panel corners" style="padding:44px 38px">
      <div class="row top gap-24 wrap">
        <div class="big-panda" style="margin:0"><${Pixel} art="panda" size=${92} /></div>
        <div class="grow" style="min-width:280px">
          <div class="kicker">The Minecraft hosting OS</div>
          <div class="hello mt-12"><span class="p">P</span>and<span class="a">A</span> Hosting</div>
          <p class="dim mt-16" style="max-width:600px;font-size:15.5px">Turn any computer into a Minecraft server box. Make servers, add mods and modpacks, invite friends from anywhere — all with buttons, never commands.</p>
          <p class="mt-12" style="font-size:15.5px"><span class="pink" style="font-weight:800">P</span>atrko <span class="muted">and</span> <span class="green" style="font-weight:800">A</span>lien — that's where the name comes from.</p>
          <div class="row wrap gap-14 mt-24">
            <div class="panel pad" style="min-width:200px;border-color:var(--blossom)"><div class="pixel tiny pink">The P</div><div style="font-family:var(--f-display);font-weight:700;font-size:22px;margin-top:6px" class="pink">Patrko</div><div class="small muted">Co-founder</div></div>
            <div class="panel pad" style="min-width:200px;border-color:var(--bamboo)"><div class="pixel tiny green">The A</div><div style="font-family:var(--f-display);font-weight:700;font-size:22px;margin-top:6px" class="green">Alien</div><div class="small muted">Co-founder</div></div>
          </div>
          <div class="small muted mt-24">Version ${info ? info.version : '…'} · Bamboo green, blossom pink, panda black.</div>
        </div>
      </div>
    </div>
    <div class="grid g3 mt-24">
      <div class="panel pad"><div class="row gap-6"><${Icon} name="heart" class="pink" /><h3>Built on great projects</h3></div><p class="small dim mt-8">Minecraft by Mojang, Paper & Purpur, Fabric, Forge & NeoForge, Geyser & Floodgate, Modrinth & CurseForge, playit.gg, Eclipse Temurin Java.</p></div>
      <div class="panel pad"><div class="row gap-6"><${Icon} name="lock" class="green" /><h3>Your stuff stays home</h3></div><p class="small dim mt-8">Worlds, backups and settings live on this machine. PandA only talks to the internet to download things and run the tunnel you choose.</p></div>
      <div class="panel pad"><div class="row gap-6"><${Icon} name="info" /><h3>Not affiliated with Mojang</h3></div><p class="small dim mt-8">PandA Hosting is not an official Minecraft product and isn't approved by or associated with Mojang or Microsoft.</p></div>
    </div>
  </div>`;
}
