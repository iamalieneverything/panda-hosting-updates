// Home = Control Panel.
import { html, useState } from '../lib/h.js';
import { api } from '../lib/api.js';
import { useStore, toast } from '../lib/store.js';
import { cls, bytes, gb, ago, TYPE_LABEL, duration } from '../lib/util.js';
import { Icon, Pixel } from '../ui/icons.js';
import { Btn, Status, ServerAvatar, AreaChart, Spark, Bar, Head, TypeIcon } from '../ui/kit.js';
import { JoinTicket } from '../ui/join.js';
import { go } from '../ui/brand.js';

export async function power(id, action) {
  try { await api.post(`/servers/${id}/power`, { action }); } catch (e) { toast('error', 'Couldn\'t do that', e.message); }
}

function ServerCard({ s }) {
  const stats = useStore((st) => st.sstats[s.id] || []);
  const [busy, setBusy] = useState(false);
  const accent = s.accent === 'pink' ? 'var(--blossom)' : 'var(--bamboo)';
  const running = ['online', 'starting', 'stopping'].includes(s.status);
  const act = async (e, a) => { e.stopPropagation(); setBusy(true); await power(s.id, a); setBusy(false); };
  const players = s.players || [];
  return html`<article class="panel srv-card" style=${`--accent:${accent}`} onClick=${() => go(`/s/${s.id}`)} tabindex="0" onKeyDown=${(e) => e.key === 'Enter' && go(`/s/${s.id}`)}>
    <div class="stripe"></div>
    <div class="body">
      <${ServerAvatar} server=${s} />
      <div class="grow">
        <div class="row between top"><div class="name ellipsis">${s.name}</div><${Status} status=${s.status} /></div>
        <div class="meta">
          <span class="chip sm"><${TypeIcon} type=${s.modpack ? 'modpack' : s.type} size=${12} />${s.modpack ? s.modpack.name : TYPE_LABEL[s.type] || s.type}</span>
          <span class="chip sm mono">${s.mcVersion || '…'}</span>
          ${s.bedrock && s.bedrock.enabled ? html`<span class="chip sm p" title="Bedrock players can join"><${Icon} name="gamepad" size=${12} />Bedrock</span>` : null}
        </div>
        ${s.installError ? html`<div class="small red mt-8">${s.installError}</div>` : null}
      </div>
    </div>
    ${s.status === 'online' ? html`<div style="padding:0 16px 12px" class="row gap-14">
      <div class="grow"><div class="row between tiny muted mono mb-8"><span>CPU ${Math.round(s.cpu || 0)}%</span><span>RAM ${bytes(s.mem || 0, 1)}</span></div><${Spark} data=${stats.map((p) => p.cpu)} w=${200} h=${20} n=${50} color=${accent} /></div>
    </div>` : null}
    <div class="foot">
      <div class="players row gap-6">
        ${players.slice(0, 4).map((p) => html`<${Head} name=${p.name} size=${20} class="sm" />`)}
        <span>${s.status === 'online' ? `${players.length}/${s.maxPlayers || 20} online` : s.status === 'offline' ? 'Sleeping' : s.status === 'crashed' ? 'Needs attention' : '…'}</span>
      </div>
      <span class="grow"></span>
      ${s.status === 'installing' ? html`<span class="chip a sm">Installing…</span>` : running
        ? html`<${Btn} size="sm" icon="stop" loading=${busy || s.status === 'stopping'} disabled=${s.status === 'stopping'} onClick=${(e) => act(e, 'stop')}>Stop<//>`
        : html`<${Btn} kind="g" size="sm" icon="play" loading=${busy} disabled=${!!s.installError} onClick=${(e) => act(e, 'start')}>Start<//>`}
    </div>
  </article>`;
}

function SysCard({ kind }) {
  const sys = useStore((s) => s.sys);
  const last = sys[sys.length - 1];
  const isCpu = kind === 'cpu';
  const data = sys.map((p) => (isCpu ? p.cpu : (p.mem / p.memTotal) * 100));
  return html`<div class="panel stat">
    <div class="sk"><span class=${cls('kicker', isCpu && 'g')}>${isCpu ? 'Processor' : 'Memory'}</span><${Icon} name=${isCpu ? 'cpu' : 'ram'} size=${18} class="muted" /></div>
    <div class="sv">${last ? (isCpu ? html`${Math.round(last.cpu)}<small>% busy</small>` : html`${(last.mem / 1073741824).toFixed(1)}<small>of ${Math.round(last.memTotal / 1073741824)} GB</small>`) : '—'}</div>
    <div class="chart"><${AreaChart} series=${[{ data, color: isCpu ? '#8df35b' : '#ff6fae' }]} h=${54} labels=${false} /></div>
  </div>`;
}

function PlayersCard() {
  const servers = useStore((s) => Object.values(s.servers));
  const online = servers.flatMap((s) => (s.status === 'online' ? (s.players || []).map((p) => ({ ...p, server: s.name, sid: s.id })) : []));
  return html`<div class="panel stat">
    <div class="sk"><span class="kicker">Players online</span><${Icon} name="users" size=${18} class="muted" /></div>
    <div class="sv">${online.length}<small>${online.length === 1 ? 'player' : 'players'}</small></div>
    <div class="chart row wrap gap-6">
      ${online.length ? online.slice(0, 10).map((p) => html`<a href=${`#/s/${p.sid}/players`} title=${`${p.name} · ${p.server}`}><${Head} name=${p.name} size=${26} class="sm" /></a>`) : html`<span class="small muted">Nobody's on right now.</span>`}
    </div>
  </div>`;
}

function DiskCard() {
  const info = useStore((s) => s.info);
  const d = info && info.info.disk;
  const used = d ? d.total - d.free : 0;
  return html`<div class="panel stat">
    <div class="sk"><span class="kicker g">Storage</span><${Icon} name="disk" size=${18} class="muted" /></div>
    <div class="sv">${d ? html`${bytes(d.free, 0)}<small>free</small>` : '—'}</div>
    <div class="chart">${d ? html`<${Bar} value=${used / d.total} thin warn=${used / d.total > 0.85} /><div class="row between tiny muted mono mt-4"><span>${bytes(used, 0)} used</span><span>${bytes(d.total, 0)}</span></div>` : null}</div>
  </div>`;
}

const FEED_ICON = { join: 'user', leave: 'logout', crash: 'warn', online: 'play', offline: 'stop', autofix: 'wrench', success: 'check', error: 'warn', info: 'info' };

function Feed() {
  const feed = useStore((s) => s.feed);
  return html`<div class="panel">
    <div class="panel-h"><h3><${Icon} name="clock" size=${16} />Activity</h3><span class="tiny muted">since you opened this page</span></div>
    <div class="panel-b" style="padding-top:4px;padding-bottom:4px">
      ${feed.length ? html`<div class="feed">${feed.slice(0, 12).map((f) => html`<div class="fi">
        <span class=${cls(f.kind === 'crash' || f.kind === 'error' ? 'red' : f.kind === 'autofix' || f.kind === 'online' || f.kind === 'join' ? 'green' : 'muted')}><${Icon} name=${FEED_ICON[f.kind] || 'info'} size=${16} /></span>
        <div class="grow"><div>${f.serverId ? html`<a href=${`#/s/${f.serverId}`} style="color:inherit">${f.text}</a>` : f.text}</div>${f.body ? html`<div class="tiny muted">${f.body}</div>` : null}</div>
        <span class="when">${ago(f.at)}</span>
      </div>`)}</div>` : html`<div class="small muted" style="padding:14px 0">Joins, crashes and auto-fixes will appear here.</div>`}
    </div>
  </div>`;
}

function TunnelTip() {
  const t = useStore((s) => s.tunnel);
  if (t && t.provider !== 'none') return null;
  return html`<div class="panel pad" style="border-color:rgba(255,111,174,.35)">
    <div class="row top gap-14">
      <div class="c-icon" style="background:var(--blossom);color:var(--blossom-ink);border:0"><${Icon} name="tunnel" size=${22} /></div>
      <div class="grow">
        <h3>Let friends join from anywhere</h3>
        <p class="small dim mt-4">Right now only people on your Wi-Fi can join. The free PandA Tunnel gives every server a public address — no router settings, works with any internet provider.</p>
        <div class="mt-12"><${Btn} kind="p" size="sm" iconR="chevR" onClick=${() => go('/network')}>Set it up (1 minute)<//></div>
      </div>
    </div>
  </div>`;
}

function FirstRun() {
  const flavors = [
    { t: 'paper', l: 'Paper', d: 'Plugins, fast', art: 'paper' },
    { t: 'fabric', l: 'Fabric', d: 'Light mods', art: 'fabric' },
    { t: 'neoforge', l: 'NeoForge', d: 'Big mods', art: 'neoforge' },
    { t: 'modpack', l: 'Modpack', d: 'ATM, Cobblemon…', art: 'modpack' },
  ];
  return html`<div class="panel corners" style="padding:44px 34px">
    <div class="row top gap-24 wrap">
      <div class="big-panda" style="margin:0;width:110px;height:110px"><${Pixel} art="panda" size=${76} /></div>
      <div class="grow" style="min-width:260px">
        <div class="kicker">Nothing here yet</div>
        <div class="hello mt-12" style="font-size:clamp(28px,4vw,42px)">Make your first<br /><span class="pink">server</span>.</div>
        <p class="dim mt-12" style="max-width:520px">Pick a flavour. PandA downloads Minecraft, the right Java, and sets everything up. You never have to touch a command.</p>
        <div class="row wrap gap-14 mt-24">
          ${flavors.map((f) => html`<button class="flavor" style="min-width:160px;padding:14px" onClick=${() => go(`/new?type=${f.t}`)}>
            <${Pixel} art=${f.art} size=${34} /><span class="fl-t" style="font-size:15px">${f.l}</span><span class="fl-d">${f.d}</span>
          </button>`)}
        </div>
      </div>
    </div>
  </div>`;
}

export function Dashboard() {
  const servers = useStore((s) => Object.values(s.servers).sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0)));
  const info = useStore((s) => s.info);
  const [featured, setFeatured] = useState(null);
  const online = servers.filter((s) => s.status === 'online');
  const players = online.reduce((n, s) => n + (s.players || []).length, 0);
  const feat = servers.find((s) => s.id === featured) || online[0] || servers[0];
  const hour = new Date().getHours();
  const greet = hour < 5 ? 'Late night' : hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';

  return html`<div class="page">
    <div class="page-head">
      <div>
        <div class="kicker">${greet}${info ? ` · ${info.settings.deviceName}` : ''}</div>
        <h1>Control Panel</h1>
        <div class="dim mt-8">${servers.length} ${servers.length === 1 ? 'server' : 'servers'} · <span class=${online.length ? 'green' : ''}>${online.length} online</span> · ${players} ${players === 1 ? 'player' : 'players'}${info ? html` · up ${duration(info.info.uptime * 1000)}` : ''}</div>
      </div>
      <div class="btn-row">
        <${Btn} icon="network" onClick=${() => go('/network')}>Network<//>
        <${Btn} kind="p" icon="plus" onClick=${() => go('/new')}>New server<//>
      </div>
    </div>

    ${info && info.info.live ? html`<div class="alert warn mb-16"><span class="ai"><${Icon} name="warn" /></span><div class="grow"><div class="at">You're running PandA from the USB stick</div><div class="ab">Try it out freely — but nothing is saved after a restart. To keep your servers, restart and choose “Install PandA Hosting” from the boot menu.</div></div></div>` : null}
    ${!servers.length ? html`<${FirstRun} />` : html`
      <div class="hero-strip">
        <div class="col gap-14">
          <${JoinTicket} server=${feat} pink=${feat && feat.accent !== 'green'} title=${feat ? `JOIN ${feat.name.toUpperCase()}` : 'JOIN ADDRESS'} />
          ${servers.length > 1 ? html`<div class="row wrap gap-6"><span class="tiny muted pixel">Show:</span>${servers.map((s) => html`<button class=${cls('chip', feat && feat.id === s.id && 'p')} style="cursor:pointer" onClick=${() => setFeatured(s.id)}><span class=${cls('sq', s.status)}></span>${s.name}</button>`)}</div>` : null}
        </div>
        <div class="statcards">
          <${SysCard} kind="cpu" />
          <${SysCard} kind="ram" />
          <${PlayersCard} />
          <${DiskCard} />
        </div>
      </div>

      <div class="row between mt-24 mb-12"><h2>Your servers</h2><span class="small muted">${gb(servers.reduce((n, s) => n + (s.status !== 'offline' ? s.memoryMb || 0 : 0), 0))} RAM in use by running servers</span></div>
      <div class="srv-grid">
        ${servers.map((s) => html`<${ServerCard} key=${s.id} s=${s} />`)}
        <a class="new-tile" href="#/new"><span class="plus"><${Icon} name="plus" size=${24} /></span>New server<span class="small muted" style="font-weight:500">Vanilla, plugins, mods or a modpack</span></a>
      </div>

      <div class="grid g-side mt-24">
        <${Feed} />
        <div class="col gap-18">
          <${TunnelTip} />
          <div class="panel pad">
            <div class="kicker g">Tip</div>
            <p class="mt-8 small dim">Open this panel on your phone: scan the code, or go to <b class="mono">${info ? info.panelUrl.replace('http://', '') : '…'}</b> while on the same Wi-Fi.</p>
            ${info ? html`<div class="row mt-12"><div class="qr" style="width:110px;height:110px"><img src=${`/api/system/qr?text=${encodeURIComponent(info.panelUrl)}`} alt="QR code" /></div></div>` : null}
          </div>
        </div>
      </div>
    `}
  </div>`;
}
