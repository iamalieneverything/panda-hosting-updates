// One server: header with power controls + tabs.
import { html, useState, useEffect, useCallback } from '../lib/h.js';
import { api } from '../lib/api.js';
import { useStore, toast } from '../lib/store.js';
import { cls, TYPE_LABEL, duration } from '../lib/util.js';
import { Icon } from '../ui/icons.js';
import { Btn, Status, ServerAvatar, Loading, ErrorBox, confirm, TypeIcon } from '../ui/kit.js';
import { OverviewTab } from './tabs/overview.js';
import { ConsoleTab } from './tabs/console.js';
import { PlayersTab } from './tabs/players.js';
import { ContentTab } from './tabs/content.js';
import { PacksTab } from './tabs/packs.js';
import { WorldTab } from './tabs/world.js';
import { RolesTab } from './tabs/roles.js';
import { FilesTab } from './tabs/files.js';
import { BackupsTab } from './tabs/backups.js';
import { ServerSettingsTab } from './tabs/settings.js';

export function ServerPage({ id, tab }) {
  const live = useStore((s) => s.servers[id]);
  const bump = useStore((s) => s.autofixBump[id] || 0);
  const [detail, setDetail] = useState(null);
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(null);

  const reload = useCallback(async () => {
    try { setDetail(await api.get(`/servers/${id}`)); setError(null); } catch (e) { setError(e); }
  }, [id]);
  useEffect(() => { reload(); }, [reload, bump]);
  // Refresh details when the status changes (ports, stats, findings…).
  useEffect(() => { if (live && detail && live.status !== detail.server.status) reload(); }, [live && live.status]);

  if (error && error.status === 404) return html`<div class="page"><h1>Server not found</h1><p class="mt-8"><a href="#/">Back to the Control Panel</a></p></div>`;
  if (!detail) return html`<div class="page">${error ? html`<${ErrorBox} error=${error} retry=${reload} />` : html`<${Loading} />`}</div>`;

  const s = { ...detail.server, ...(live || {}), join: (live && live.join) || detail.join };
  const kind = detail.contentKind;
  const running = ['online', 'starting', 'stopping'].includes(s.status);

  const act = async (action) => {
    if (action === 'kill' && !(await confirm({ title: 'Force stop?', body: 'This kills the server right away. Anything since the last autosave may be lost. Use it only if the server is frozen.', ok: 'Force stop', danger: true }))) return;
    setBusy(action);
    try { await api.post(`/servers/${id}/power`, { action }); } catch (e) { toast('error', 'Couldn\'t do that', e.message); }
    setBusy(null);
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'grid' },
    { id: 'console', label: 'Console', icon: 'terminal', badge: s.status === 'crashed' ? '!' : null },
    { id: 'players', label: 'Players & chat', icon: 'users', badge: s.status === 'online' && (s.players || []).length ? (s.players || []).length : null },
    kind ? { id: 'content', label: kind === 'plugin' ? 'Plugins' : 'Mods', icon: 'puzzle', badge: detail.autofix.unseen ? detail.autofix.unseen : null } : null,
    { id: 'packs', label: 'Packs', icon: 'box' },
    { id: 'world', label: 'World & rules', icon: 'sliders' },
    { id: 'roles', label: 'Roles', icon: 'crown' },
    { id: 'files', label: 'Files', icon: 'folder' },
    { id: 'backups', label: 'Backups', icon: 'archive' },
    { id: 'settings', label: 'Settings', icon: 'gear' },
  ].filter(Boolean);
  const cur = tabs.find((t) => t.id === tab) ? tab : 'overview';
  const props = { id, server: s, detail, reload };

  return html`<div class="page">
    <div class="srv-head">
      <${ServerAvatar} server=${s} size=${72} lg />
      <div class="title">
        <h1><span class="ellipsis">${s.name}</span><${Status} status=${s.status} /></h1>
        <div class="meta">
          <span class="chip"><${TypeIcon} type=${s.modpack ? 'modpack' : s.type} size=${14} />${s.modpack ? s.modpack.name : TYPE_LABEL[s.type] || s.type}</span>
          ${s.modpack && s.modpack.version ? html`<span class="chip mono" title="Players need this same modpack version">Pack ${s.modpack.version}</span>` : null}
          <span class="chip mono">MC ${s.mcVersion || '…'}</span>
          ${s.loaderVersion ? html`<span class="chip mono">${TYPE_LABEL[s.type]} ${s.loaderVersion}</span>` : null}
          ${s.bedrock && s.bedrock.enabled ? html`<span class="chip p"><${Icon} name="gamepad" size=${13} />Bedrock on</span>` : null}
          ${s.status === 'online' && s.readyAt ? html`<span class="chip"><${Icon} name="clock" size=${13} />up ${duration(Date.now() - s.readyAt)}</span>` : null}
        </div>
      </div>
      <div class="power">
        ${s.status === 'installing' ? html`<span class="chip a">Installing — see Background jobs</span>` : null}
        ${!running && s.status !== 'installing' ? html`<${Btn} kind="g" size="lg" icon="play" loading=${busy === 'start'} disabled=${!!s.installError} onClick=${() => act('start')}>Start<//>` : null}
        ${running ? html`<${Btn} size="lg" icon="restart" loading=${busy === 'restart'} disabled=${s.status !== 'online'} onClick=${() => act('restart')}>Restart<//>` : null}
        ${running ? html`<${Btn} kind="p" size="lg" icon="stop" loading=${busy === 'stop' || s.status === 'stopping'} disabled=${s.status === 'stopping'} onClick=${() => act('stop')}>Stop<//>` : null}
        ${running ? html`<${Btn} kind="danger" size="lg" icon="power" title="Force stop" aria-label="Force stop" onClick=${() => act('kill')} />` : null}
      </div>
    </div>
    ${s.installError ? html`<div class="alert error mb-16"><span class="ai"><${Icon} name="warn" /></span><div class="grow"><div class="at">Setup didn't finish</div><div class="ab">${s.installError}</div></div><a class="btn sm" href=${`#/s/${id}/settings`}>Fix in settings</a></div>` : null}

    <nav class="tabs" aria-label="Server sections">
      ${tabs.map((t) => html`<a href=${`#/s/${id}/${t.id}`} class=${cls(cur === t.id && 'on')}><${Icon} name=${t.icon} size=${16} />${t.label}${t.badge ? html`<span class="badge">${t.badge}</span>` : null}</a>`)}
    </nav>

    ${cur === 'overview' ? html`<${OverviewTab} ...${props} />` : null}
    ${cur === 'console' ? html`<${ConsoleTab} ...${props} />` : null}
    ${cur === 'players' ? html`<${PlayersTab} ...${props} />` : null}
    ${cur === 'content' ? html`<${ContentTab} ...${props} kind=${kind} />` : null}
    ${cur === 'packs' ? html`<${PacksTab} ...${props} />` : null}
    ${cur === 'world' ? html`<${WorldTab} ...${props} />` : null}
    ${cur === 'roles' ? html`<${RolesTab} ...${props} />` : null}
    ${cur === 'files' ? html`<${FilesTab} ...${props} />` : null}
    ${cur === 'backups' ? html`<${BackupsTab} ...${props} />` : null}
    ${cur === 'settings' ? html`<${ServerSettingsTab} ...${props} />` : null}
  </div>`;
}
