// Built-in Modrinth + CurseForge browser (mods, plugins, modpacks, datapacks, resource packs).
import { html, useState, useEffect, useRef } from '../lib/h.js';
import { api, q } from '../lib/api.js';
import { toast } from '../lib/store.js';
import { cls, compact, ago, date } from '../lib/util.js';
import { Icon, Pixel } from '../ui/icons.js';
import { Btn, Modal, Toggle, Loading, Seg } from '../ui/kit.js';

const KIND_WORD = { mod: 'mods', plugin: 'plugins', modpack: 'modpacks', datapack: 'datapacks', resourcepack: 'resource packs' };

export function CurseForgeKey({ onSaved, note }) {
  const [key, setKey] = useState('');
  const [busy, setBusy] = useState(false);
  const [fail, setFail] = useState(null);
  const save = async (force) => {
    setBusy(true);
    try {
      const t = await api.post('/settings/curseforge/test', { key, save: true, force: !!force });
      if (t.saved) {
        setFail(null);
        toast('success', t.ok ? 'CurseForge connected' : 'Key saved', t.ok ? null : 'PandA will use it as soon as CurseForge answers.');
        onSaved && onSaved();
      } else setFail(t);
    } catch (e) { setFail({ message: e.message }); }
    setBusy(false);
  };
  return html`<div class="panel pad" style="border-color:rgba(255,111,174,.35)">
    <div class="row top gap-14 wrap">
      <div class="c-icon lg" style="background:var(--blossom-wash);color:var(--blossom)"><${Icon} name="key" size=${26} /></div>
      <div class="grow" style="min-width:260px">
        <h3>Connect CurseForge (free, one time)</h3>
        <p class="small dim mt-4">CurseForge asks every app for its own key. It's free and takes a minute:</p>
        <ol class="small dim" style="margin:8px 0 0;padding-left:18px;line-height:1.7">
          <li>Open <a href="https://console.curseforge.com/" target="_blank" rel="noopener">console.curseforge.com</a> and sign in.</li>
          <li>Click <b>API keys</b> and copy your key.</li>
          <li>Paste it here and press Connect.</li>
        </ol>
        ${note ? html`<p class="small mt-8" style="color:var(--amber)">${note}</p>` : null}
        <p class="small dim mt-8">Easiest from your phone or PC: open the panel there, then copy and paste — no typing a 60-character key.</p>
        <div class="row mt-12 wrap"><input class="input mono grow" style="min-width:220px" placeholder="$2a$10$…" spellcheck="false" autocomplete="off" autocapitalize="off" value=${key} onInput=${(e) => { setKey(e.currentTarget.value.trim()); setFail(null); }} onKeyDown=${(e) => e.key === 'Enter' && key && save()} /><${Btn} kind="p" loading=${busy} disabled=${!key} onClick=${() => save()}>Connect<//></div>
        ${fail ? html`<div class="alert ${fail.reason === 'rejected' || !fail.reason ? 'error' : 'warn'} mt-12">
          <span class="ai"><${Icon} name="warn" /></span>
          <div class="grow">
            <div class="at">${fail.reason === 'rejected' ? 'CurseForge said no to this key' : fail.reason ? 'Couldn\'t check the key' : 'Key not saved'}</div>
            <div class="ab">${fail.message}</div>
            ${fail.seen ? html`<div class="ab mt-4">PandA received <span class="mono">${fail.seen.preview}</span> (${fail.seen.length} characters). Compare it with the start and end of your key.</div>` : null}
          </div>
          ${fail.reason && fail.reason !== 'rejected' ? html`<${Btn} size="sm" loading=${busy} onClick=${() => save(true)}>Save anyway<//>` : null}
        </div>` : null}
      </div>
    </div>
  </div>`;
}

function ProjectCard({ p, onOpen, onInstall, installLabel, installing }) {
  return html`<div class=${cls('pcard', p.source === 'curseforge' && 'cf')} onClick=${() => onOpen(p)} tabindex="0" onKeyDown=${(e) => e.key === 'Enter' && onOpen(p)}>
    <div class="top-row">
      <div class="c-icon lg">${p.icon ? html`<img src=${p.icon} alt="" loading="lazy" />` : html`<${Pixel} art="modpack" size=${36} />`}</div>
      <div class="grow">
        <div class="pt">${p.name}</div>
        <div class="pa">${p.author ? `by ${p.author}` : ''}</div>
        <div class="row wrap gap-4 mt-4">${(p.categories || []).slice(0, 3).map((c) => html`<span class="chip sm">${c}</span>`)}</div>
      </div>
    </div>
    <div class="pd">${p.summary}</div>
    <div class="pf">
      <span title="Downloads"><${Icon} name="download" size=${13} /> ${compact(p.downloads)}</span>
      ${p.updated ? html`<span title="Updated">${ago(new Date(p.updated).getTime())}</span>` : null}
      ${onInstall ? html`<${Btn} kind=${p.source === 'curseforge' ? 'p' : 'g'} size="xs" icon="download" loading=${installing} onClick=${(e) => { e.stopPropagation(); onInstall(p); }}>${installLabel || 'Install'}<//>` : null}
    </div>
  </div>`;
}

/**
 * Search grid. `onInstall(project, versionId?)` installs; `onPick(project)` for selection-only (modpacks).
 */
export function Browser({ kind = 'mod', serverId, onInstall, onPick, pickLabel = 'Choose', installLabel, initialSource = 'modrinth', compact: small }) {
  const [source, setSource] = useState(initialSource);
  const [query, setQuery] = useState('');
  const [sort, setSort] = useState(kind === 'modpack' ? 'downloads' : 'relevance');
  const [compatible, setCompatible] = useState(true);
  const [res, setRes] = useState({ hits: [], total: 0 });
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState(null);
  const [offset, setOffset] = useState(0);
  const [open, setOpen] = useState(null);
  const [installing, setInstalling] = useState({});
  const seq = useRef(0);

  const load = async (off = 0) => {
    const my = ++seq.current;
    setLoading(true); setErr(null);
    try {
      const r = await api.get(`/browse/${source}/search?${q({ q: query, kind, sort, offset: off, limit: 24, serverId, compatible: compatible ? '1' : '0' })}`);
      if (my !== seq.current) return;
      setRes((prev) => (off ? { ...r, hits: [...prev.hits, ...r.hits] } : r));
      setOffset(off);
    } catch (e) { if (my === seq.current) setErr(e); }
    if (my === seq.current) setLoading(false);
  };
  useEffect(() => { const t = setTimeout(() => load(0), query ? 320 : 0); return () => clearTimeout(t); }, [source, query, sort, compatible, kind, serverId]);

  const doInstall = async (p, versionId) => {
    if (onPick) { onPick(p, versionId); setOpen(null); return; }
    setInstalling((s) => ({ ...s, [p.id]: true }));
    try { await onInstall(p, versionId); } finally { setInstalling((s) => ({ ...s, [p.id]: false })); }
  };

  return html`<div>
    <div class="row wrap gap-14 mb-16">
      <div class="subtabs">
        <button class=${cls(source === 'modrinth' && 'on')} onClick=${() => setSource('modrinth')}><span class="sq online"></span>Modrinth</button>
        <button class=${cls(source === 'curseforge' && 'on')} onClick=${() => setSource('curseforge')}><span class="sq" style="background:var(--blossom)"></span>CurseForge</button>
      </div>
      <div class="input-wrap grow" style="min-width:220px">
        <span class="ic-l"><${Icon} name="search" size=${15} /></span>
        <input class="input" placeholder=${`Search ${KIND_WORD[kind] || kind}… (try “${kind === 'modpack' ? 'All the Mods' : kind === 'plugin' ? 'EssentialsX' : kind === 'datapack' ? 'trees' : kind === 'resourcepack' ? 'faithful' : 'create'}”)`} value=${query} onInput=${(e) => setQuery(e.currentTarget.value)} />
      </div>
      <select class="select" style="width:auto" value=${sort} onChange=${(e) => setSort(e.currentTarget.value)}>
        <option value="relevance">Best match</option>
        <option value="downloads">Most downloaded</option>
        <option value="follows">Most loved</option>
        <option value="updated">Recently updated</option>
        <option value="newest">Newest</option>
      </select>
      ${serverId ? html`<label class="row gap-6 small dim" title="Only show things that work with this server's Minecraft version and loader"><${Toggle} checked=${compatible} onChange=${setCompatible} label="Compatible only" />Compatible only</label>` : null}
    </div>

    ${err && err.code === 'NO_CF_KEY' ? html`<${CurseForgeKey} note=${/stopped/.test(err.message) ? err.message : null} onSaved=${() => load(0)} />` : null}
    ${err && err.code !== 'NO_CF_KEY' ? html`<div class="alert error"><span class="ai"><${Icon} name="warn" /></span><div class="grow"><div class="at">Couldn't search ${source === 'modrinth' ? 'Modrinth' : 'CurseForge'}</div><div class="ab">${err.message}</div></div><${Btn} size="sm" onClick=${() => load(0)}>Retry<//></div>` : null}

    ${!err ? html`
      <div class="small muted mb-12">${loading && !res.hits.length ? 'Searching…' : `${compact(res.total)} results`}</div>
      <div class="cards" style=${small ? 'grid-template-columns:repeat(auto-fill,minmax(250px,1fr))' : ''}>
        ${res.hits.map((p) => html`<${ProjectCard} key=${p.source + p.id} p=${p} onOpen=${setOpen} installing=${installing[p.id]}
          onInstall=${onInstall || onPick ? (x) => doInstall(x) : null} installLabel=${onPick ? pickLabel : installLabel} />`)}
      </div>
      ${loading && !res.hits.length ? html`<div class="cards">${Array.from({ length: 6 }).map(() => html`<div class="pcard skeleton" style="height:170px"></div>`)}</div>` : null}
      ${!loading && !res.hits.length ? html`<div class="empty"><div class="art"><${Pixel} art="sleepy" size=${54} /></div><div class="et">Nothing found</div><div>${compatible && serverId ? 'Try turning off “Compatible only”, or search for something else.' : 'Try another search.'}</div></div>` : null}
      ${res.hits.length < res.total ? html`<div class="center mt-16"><${Btn} loading=${loading} onClick=${() => load(offset + 24)}>Load more<//></div>` : null}
    ` : null}

    ${open ? html`<${ProjectModal} p=${open} kind=${kind} serverId=${serverId} onClose=${() => setOpen(null)} onInstall=${(vid) => doInstall(open, vid)} actionLabel=${onPick ? pickLabel : installLabel || 'Install'} />` : null}
  </div>`;
}

export function ProjectModal({ p, kind, serverId, onClose, onInstall, actionLabel = 'Install' }) {
  const [detail, setDetail] = useState(null);
  const [versions, setVersions] = useState(null);
  const [all, setAll] = useState(false);
  const [busy, setBusy] = useState(null);
  useEffect(() => {
    api.get(`/browse/${p.source}/project/${p.id}`).then((r) => setDetail(r.project)).catch(() => setDetail(p));
  }, [p.id]);
  useEffect(() => {
    setVersions(null);
    api.get(`/browse/${p.source}/project/${p.id}/versions?${q({ serverId, kind, all: all ? '1' : '' })}`).then((r) => setVersions(r.versions)).catch(() => setVersions([]));
  }, [p.id, all]);
  const d = detail || p;
  const run = async (vid) => { setBusy(vid || 'latest'); try { await onInstall(vid); onClose(); } catch {} setBusy(null); };
  return html`<${Modal} title=${d.name} size="wide" onClose=${onClose} footer=${html`<a class="btn ghost" href=${d.url} target="_blank" rel="noopener"><${Icon} name="external" size=${15} />Open on ${p.source === 'modrinth' ? 'Modrinth' : 'CurseForge'}</a><${Btn} kind=${p.source === 'curseforge' ? 'p' : 'g'} icon="download" loading=${busy === 'latest'} onClick=${() => run(null)}>${actionLabel} latest<//>`}>
    <div class="row top gap-18 wrap">
      <div class="c-icon lg" style="width:86px;height:86px">${d.icon ? html`<img src=${d.icon} alt="" />` : html`<${Pixel} art="modpack" size=${50} />`}</div>
      <div class="grow" style="min-width:240px">
        <div class="dim">${d.summary}</div>
        <div class="row wrap gap-6 mt-12">
          ${d.author ? html`<span class="chip"><${Icon} name="user" size=${13} />${d.author}</span>` : null}
          <span class="chip"><${Icon} name="download" size=${13} />${compact(d.downloads)}</span>
          ${(d.categories || []).slice(0, 5).map((c) => html`<span class="chip">${c}</span>`)}
          ${d.serverSide === 'unsupported' ? html`<span class="chip r">Client-only — won't run on a server</span>` : null}
        </div>
      </div>
    </div>
    ${d.gallery && d.gallery.length ? html`<div class="gallery mt-16">${d.gallery.slice(0, 3).map((g) => html`<img src=${g} alt="" loading="lazy" />`)}</div>` : null}
    <div class="row between mt-24 mb-8"><h3>Versions</h3>${serverId ? html`<label class="row gap-6 small dim"><${Toggle} checked=${all} onChange=${setAll} label="Show all versions" />Show all</label>` : null}</div>
    <div class="panel" style="max-height:300px;overflow-y:auto">
      ${versions === null ? html`<${Loading} />` : !versions.length ? html`<div class="small muted" style="padding:16px">${serverId ? 'No version works with this server. Try “Show all”.' : 'No versions found.'}</div>` : versions.slice(0, 40).map((v) => html`<div class="content-row">
        <div class="grow">
          <div class="c-name">${v.name || v.number}<span class=${cls('chip sm', v.type === 'release' ? 'g' : 'a')}>${v.type}</span></div>
          <div class="c-sub mono">${(v.mcVersions || []).slice(0, 6).join(', ')}${(v.mcVersions || []).length > 6 ? '…' : ''} · ${(v.loaders || []).join(', ')} · ${v.date ? date(new Date(v.date).getTime()) : ''}</div>
        </div>
        <${Btn} size="xs" icon="download" loading=${busy === v.id} onClick=${() => run(v.id)}>${actionLabel}<//>
      </div>`)}
    </div>
  <//>`;
}

export { Seg };
