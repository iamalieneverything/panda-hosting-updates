// Sign-in for phones / other computers.
import { html, useState } from '../lib/h.js';
import { api } from '../lib/api.js';
import { Pixel } from '../ui/icons.js';
import { Btn } from '../ui/kit.js';
import { Wordmark } from '../ui/brand.js';

export function Login({ state, onDone }) {
  const [pw, setPw] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e && e.preventDefault();
    setBusy(true); setErr('');
    try { await api.post('/login', { password: pw }); onDone(); } catch (x) { setErr(x.message); }
    setBusy(false);
  };
  return html`<div class="gate">
    <form class="gate-card panel pad corners" style="max-width:440px" onSubmit=${submit}>
      <div class="center">
        <div class="big-panda" style="width:96px;height:96px;margin-bottom:20px"><${Pixel} art="panda" size=${66} /></div>
        <${Wordmark} size=${30} />
        <div class="muted mt-8">${state.deviceName}</div>
      </div>
      <div class="field mt-24">
        <label class="lbl" for="pw">Panel password</label>
        <input id="pw" class="input big" type="password" autocomplete="current-password" autofocus value=${pw} onInput=${(e) => setPw(e.currentTarget.value)} />
      </div>
      ${err ? html`<div class="err-text mt-12">${err}</div>` : null}
      <${Btn} kind="g" size="lg" class="block mt-16" loading=${busy} type="submit">Sign in<//>
      <p class="small muted center mt-16">Forgot it? On the PandA screen itself, open Settings → Password.</p>
    </form>
  </div>`;
}
