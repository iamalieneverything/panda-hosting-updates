// PandA Hosting — web panel entry point.
import { html, render, useState, useEffect } from './lib/h.js';
import { api } from './lib/api.js';
import { useStore, startLive, state, update } from './lib/store.js';
import { cls, bytes } from './lib/util.js';
import { Icon } from './ui/icons.js';
import { Btn, Toasts, DialogHost, Spark, AreaChart, Bar } from './ui/kit.js';
import { BrandTile, Wordmark } from './ui/brand.js';
import { Dashboard } from './views/dashboard.js';
import { CreateServer } from './views/create.js';
import { ServerPage } from './views/server.js';
import { NetworkPage } from './views/network.js';
import { SettingsPage } from './views/settings.js';
import { AboutPage } from './views/about.js';
import { Setup } from './views/setup.js';
import { Login } from './views/login.js';

// ---------------------------------------------------------------- router

function parseHash() {
  const raw = location.hash.replace(/^#\/?/, '');
  const [path, query = ''] = raw.split('?');
  return { parts: path.split('/').filter(Boolean).map(decodeURIComponent), query: Object.fromEntries(new URLSearchParams(query)) };
}

function useRoute() {
  const [r, setR] = useState(parseHash());
  useEffect(() => {
    const on = () => { setR(parseHash()); window.scrollTo(0, 0); };
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  return r;
}

// ---------------------------------------------------------------- sidebar

function Sidebar({ route, open, onClose }) {
  const servers = useStore((s) => Object.values(s.servers).sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0)).map((x) => `${x.id}|${x.name}|${x.status}|${(x.players || []).length}`).join(','));
  const info = useStore((s) => s.info);
  const updateReady = useStore((s) => !!(s.updates && s.updates.supported && s.updates.available));
  const list = servers ? servers.split(',').map((x) => { const [id, name, status, n] = x.split('|'); return { id, name, status, n: Number(n) }; }) : [];
  const top = route.parts[0] || '';
  const sel = route.parts[0] === 's' ? route.parts[1] : null;
  const link = (href, icon, label, on, extra) => html`<a href=${href} class=${cls(on && 'on')} onClick=${onClose}><span class="ic"><${Icon} name=${icon} /></span>${label}${extra || null}</a>`;
  return html`<aside class=${cls('side', open && 'open')}>
    <a class="brand" href="#/" onClick=${onClose}>
      <${BrandTile} />
      <div><${Wordmark} /><div class="brand-sub">HOSTING OS</div></div>
    </a>
    <nav class="nav">
      ${link('#/', 'grid', 'Control Panel', top === '')}
      <div class="nav-sec">Servers</div>
      ${list.map((s) => html`<a href=${`#/s/${s.id}`} class=${cls('srv-link', sel === s.id && 'on')} onClick=${onClose}>
        <span class=${cls('sq', s.status)}></span><span class="ellipsis">${s.name}</span>${s.status === 'online' ? html`<span class="count">${s.n}</span>` : null}
      </a>`)}
      <div class="side-new"><a href="#/new" class=${cls(top === 'new' && 'on')} onClick=${onClose} style="color:var(--blossom)"><span class="ic" style="color:var(--blossom)"><${Icon} name="plus" /></span>New server</a></div>
      <div class="nav-sec">System</div>
      ${link('#/network', 'network', 'Network & friends', top === 'network')}
      ${link('#/settings', 'gear', 'Settings', top === 'settings', updateReady ? html`<span class="chip sm p" style="margin-left:auto" title="A PandA update is ready">NEW</span>` : null)}
      ${link('#/about', 'heart', 'About PandA', top === 'about')}
    </nav>
    <div class="side-foot">
      <div class="device-chip">
        <${Icon} name=${info && info.info.mode === 'os' ? 'server' : 'cpu'} size=${18} />
        <div class="grow">
          <div class="name ellipsis">${(info && info.settings.deviceName) || 'PandA'}</div>
          <div class="ip">${info ? `${info.info.primaryIp}:${info.settings.panelPort}` : '…'}</div>
        </div>
      </div>
      <div class="pa-stamp" title="PandA = Patrko and Alien"><span><span class="pk">P</span><b>and</b><span class="gr">A</span></span><span><span class="pk">PATRKO</span> · <span class="gr">ALIEN</span></span></div>
    </div>
  </aside>`;
}

// ---------------------------------------------------------------- top bar

function Meter({ kind }) {
  const [hover, setHover] = useState(false);
  const sys = useStore((s) => s.sys);
  const last = sys[sys.length - 1];
  const isCpu = kind === 'cpu';
  const color = isCpu ? 'var(--bamboo)' : 'var(--blossom)';
  const data = sys.map((p) => (isCpu ? p.cpu : (p.mem / p.memTotal) * 100));
  const value = last ? (isCpu ? last.cpu : (last.mem / last.memTotal) * 100) : 0;
  return html`<div class=${cls('meter', kind)} onMouseEnter=${() => setHover(true)} onMouseLeave=${() => setHover(false)}>
    <div class="ml">
      <span class="mk">${isCpu ? 'CPU' : 'RAM'}</span>
      <span class="mv">${isCpu ? `${Math.round(value)}%` : last ? html`${(last.mem / 1073741824).toFixed(1)}<small> / ${Math.round(last.memTotal / 1073741824)} GB</small>` : '—'}</span>
    </div>
    <${Spark} data=${data} color=${color} />
    ${hover ? html`<div class="meter-pop">
      <div class="row between mb-8"><span class="kicker ${isCpu ? 'g' : ''}">${isCpu ? 'Processor · last 5 min' : 'Memory · last 5 min'}</span><span class="mono small">${Math.round(value)}%</span></div>
      <${AreaChart} series=${[{ data, color: isCpu ? '#8df35b' : '#ff6fae' }]} h=${110} />
      ${!isCpu && last ? html`<div class="mt-8"><${Bar} value=${last.mem / last.memTotal} pink thin /></div><div class="row between small muted mt-4"><span>${bytes(last.mem)} used</span><span>${bytes(last.memTotal - last.mem)} free</span></div>` : null}
    </div>` : null}
  </div>`;
}

function TunnelPill() {
  const t = useStore((s) => s.tunnel);
  let label = 'Local only'; let sq = 'offline';
  if (t && t.provider !== 'none') {
    if (t.status === 'online') { label = t.provider === 'playit' ? 'Tunnel online' : 'Router open'; sq = 'online'; }
    else if (t.status === 'needs-claim' || t.status === 'claiming') { label = 'Link needed'; sq = 'starting'; }
    else if (t.status === 'error') { label = 'Tunnel problem'; sq = 'crashed'; }
    else { label = 'Connecting'; sq = 'starting'; }
  }
  return html`<a class="tunnel-pill" href="#/network" title="Friends outside your home"><span class=${cls('sq', sq)}></span><span class="lbl-txt">${label}</span></a>`;
}

// Only shows on laptops.
function BatteryPill() {
  const b = useStore((s) => { const p = s.sys[s.sys.length - 1]; return p && p.battery ? p.battery : null; });
  if (!b) return null;
  const low = !b.charging && b.pct <= 20;
  return html`<div class="tunnel-pill" title=${`Battery ${b.pct}% · ${b.status}`} style=${low ? 'border-color:var(--red);color:#ff8a99' : ''}>
    <span style="display:inline-flex;align-items:center;gap:2px"><span style="width:20px;height:11px;border:1.5px solid currentColor;padding:1px;display:inline-block"><i style=${`display:block;height:100%;width:${Math.max(8, b.pct)}%;background:${low ? 'var(--red)' : b.charging ? 'var(--bamboo)' : 'currentColor'}`}></i></span><span style="width:2px;height:5px;background:currentColor;display:inline-block"></span></span>
    <span class="mono">${b.pct}%</span>${b.charging ? html`<${Icon} name="bolt" size=${13} />` : null}
  </div>`;
}

function TasksButton() {
  const running = useStore((s) => Object.values(s.tasks).filter((t) => t.state === 'running').length);
  return html`<button class="top-btn" title="Background jobs" aria-label="Background jobs" onClick=${() => update((s) => { s.drawer = s.drawer === 'tasks' ? null : 'tasks'; })}>
    <${Icon} name=${running ? 'restart' : 'list'} class=${running ? 'spin' : ''} />
    ${running ? html`<span class="dotc">${running}</span>` : null}
  </button>`;
}

function Crumbs({ route }) {
  const name = useStore((s) => (route.parts[0] === 's' && s.servers[route.parts[1]] ? s.servers[route.parts[1]].name : null));
  const p = route.parts[0] || '';
  const titles = { '': 'Control Panel', new: 'New server', network: 'Network & friends', settings: 'Settings', about: 'About PandA' };
  if (p === 's') return html`<div class="crumbs"><a href="#/" class="dim">Servers</a><${Icon} name="chevR" size=${14} /><b class="ellipsis">${name || '…'}</b></div>`;
  return html`<div class="crumbs"><b>${titles[p] || 'PandA'}</b></div>`;
}

function Topbar({ route, onMenu }) {
  const connected = useStore((s) => s.connected);
  return html`<header class="topbar">
    <button class="top-btn menu-btn" aria-label="Menu" onClick=${onMenu}><${Icon} name="menu" /></button>
    <${Crumbs} route=${route} />
    ${!connected ? html`<span class="chip a sm"><span class="sq starting"></span>Reconnecting</span>` : null}
    <div class="meters">
      <${Meter} kind="cpu" />
      <${Meter} kind="ram" />
      <${BatteryPill} />
      <${TunnelPill} />
      <${TasksButton} />
    </div>
  </header>`;
}

// ---------------------------------------------------------------- tasks drawer

function TasksDrawer() {
  const open = useStore((s) => s.drawer === 'tasks');
  const tasks = useStore((s) => Object.values(s.tasks).sort((a, b) => b.startedAt - a.startedAt).slice(0, 30));
  if (!open) return null;
  const close = () => update((s) => { s.drawer = null; });
  return html`<div class="scrim" onClick=${close}></div>
  <aside class="drawer" aria-label="Background jobs">
    <div class="drawer-h"><h2>Background jobs</h2><${Btn} kind="ghost" size="sm" icon="x" aria-label="Close" onClick=${close} /></div>
    <div class="drawer-b">
      ${!tasks.length ? html`<div class="muted center" style="padding:30px 0">Nothing running. Installs, backups and modpacks show up here.</div>` : null}
      ${tasks.map((t) => html`<div class="task" key=${t.id}>
        <div class="tt">
          ${t.state === 'running' ? html`<${Icon} name="restart" class="spin" size=${15} />` : t.state === 'done' ? html`<span class="green"><${Icon} name="check" size=${15} /></span>` : html`<span class="red"><${Icon} name="warn" size=${15} /></span>`}
          <span class="grow ellipsis">${t.title}</span>
          ${t.serverId && state.servers[t.serverId] ? html`<a class="small" href=${`#/s/${t.serverId}`} onClick=${close}>Open</a>` : null}
        </div>
        <div class="ts">${t.state === 'failed' ? html`<span class="red">${t.error}</span>` : t.stage}${t.bytes ? ` · ${bytes(t.bytes.got)} / ${bytes(t.bytes.total)}` : ''}</div>
        ${t.state === 'running' ? html`<${Bar} value=${t.progress} busy=${t.progress == null} />` : null}
      </div>`)}
    </div>
  </aside>`;
}

// ---------------------------------------------------------------- shell

// While PandA installs an update it restarts; this covers the screen until it's back
// (the page then reloads itself with the new version).
function UpdatingOverlay() {
  const u = useStore((s) => (s.updates && s.updates.status === 'installing' ? `${s.updates.latest}|${s.updates.message}` : ''));
  const [version, message] = u.split('|');
  // A permanent host element (see UpdatesCard: null → element can be left out of the page).
  return html`<div class="updating-host" style="display:contents">${u ? html`<div class="overlay" style="z-index:90">
    <div class="center" style="max-width:420px;text-align:center;padding:24px">
      <${BrandTile} size=${72} />
      <h2 class="mt-16">Updating to PandA ${version}</h2>
      <p class="dim mt-8">${message || 'This takes about a minute.'}</p>
      <div class="mt-16"><${Bar} busy /></div>
      <p class="small muted mt-12">Your worlds and settings are safe. Servers that were running start again by themselves.</p>
    </div>
  </div>` : null}</div>`;
}

function Shell() {
  const route = useRoute();
  const [menu, setMenu] = useState(false);
  useEffect(() => { startLive(); }, []);
  const p = route.parts[0] || '';
  let view;
  if (p === '') view = html`<${Dashboard} />`;
  else if (p === 'new') view = html`<${CreateServer} query=${route.query} />`;
  else if (p === 's') view = html`<${ServerPage} id=${route.parts[1]} tab=${route.parts[2] || 'overview'} key=${route.parts[1]} />`;
  else if (p === 'network') view = html`<${NetworkPage} />`;
  else if (p === 'settings') view = html`<${SettingsPage} />`;
  else if (p === 'about') view = html`<${AboutPage} />`;
  else view = html`<div class="page"><h1>Not found</h1><p class="mt-8"><a href="#/">Back to the Control Panel</a></p></div>`;
  return html`<div class="app">
    <${Sidebar} route=${route} open=${menu} onClose=${() => setMenu(false)} />
    ${menu ? html`<div class="scrim" style="z-index:29" onClick=${() => setMenu(false)}></div>` : null}
    <div class="main">
      <${Topbar} route=${route} onMenu=${() => setMenu(true)} />
      ${view}
    </div>
    <${TasksDrawer} />
    <${UpdatingOverlay} />
  </div>`;
}

function Root() {
  const [st, setSt] = useState(null);
  const load = () => api.get('/state').then((x) => {
    update((s) => { s.me = { local: x.local, remote: x.remote }; });
    setSt(x);
    // Phones and PCs know the owner's time zone (night-time updates); the box's screen is UTC.
    if (x.authed && !x.local) { try { api.put('/updates/settings', { tz: Intl.DateTimeFormat().resolvedOptions().timeZone }).catch(() => {}); } catch {} }
  }).catch(() => setTimeout(load, 2000));
  useEffect(() => {
    load();
    const onAuth = () => setSt((s) => (s ? { ...s, authed: false } : s));
    window.addEventListener('panda:auth', onAuth);
    return () => window.removeEventListener('panda:auth', onAuth);
  }, []);
  let body;
  if (!st) body = html`<div class="gate"><div class="center"><${BrandTile} size=${64} /><div class="mt-16 muted pixel tiny">Starting PandA…</div></div></div>`;
  else if (!st.setupDone) body = html`<${Setup} state=${st} onDone=${load} />`;
  else if (!st.authed) body = html`<${Login} state=${st} onDone=${load} />`;
  else body = html`<${Shell} />`;
  return html`${body}<${Toasts} /><${DialogHost} />`;
}

render(html`<${Root} />`, document.getElementById('root'));
